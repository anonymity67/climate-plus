from rwh_model import *
import json

TIERS = {
 "T1": dict(name="Household",             persons=6,   lpcd=5, demand=30,   areas=[12,20,30]),
 "T2": dict(name="Cluster (10 HH)",       persons=60,  lpcd=5, demand=300,  areas=[80,120,160]),
 "T3": dict(name="Institution (400 users)",persons=400,lpcd=5, demand=2000, areas=[250,400,600]),
}
def rd(z): return [r*DESIGN_FACTOR for r in ZONES[z]["m"]]

print("="*104); print("A. MAX ACHIEVABLE RELIABILITY (infinite storage) = supply/demand -- is RWH feasible at all?"); print("="*104)
print(f"{'Tier':26s}{'Area':>7s}"+"".join(f"{'Z-'+z:>11s}" for z in ZONES))
for t,d in TIERS.items():
    for a in d["areas"]:
        print(f"{t+' '+d['name']:26s}{a:>7d}"+"".join(f"{max_reliability(rd(z),a,d['demand'])*100:>10.0f}%" for z in ZONES))

print(); print("="*104); print("B. TANK SIZE (litres) FOR 90% ANNUAL RELIABILITY"); print("="*104)
print(f"{'Tier':26s}{'Area':>7s}"+"".join(f"{'Z-'+z:>11s}" for z in ZONES))
B={}
for t,d in TIERS.items():
    for a in d["areas"]:
        row=[]
        for z in ZONES:
            v=size_tank(rd(z),a,d["demand"],0.90)
            row.append(v); B[(t,a,z)]=v
        print(f"{t+' '+d['name']:26s}{a:>7d}"+"".join(f"{(str(v) if v else 'infeas'):>11s}" for v in row))

print(); print("="*104); print("C. CANDIDATE STANDARD TANKS -> annual % / dry-season(Nov-May) % / dry days covered of 243")
print("="*104)
CAND={"T1":[(3000,20),(4000,20),(5000,20)],
      "T2":[(10000,120),(15000,120),(20000,120),(25000,120)],
      "T3":[(30000,400),(50000,400),(60000,600),(80000,600)]}
for t,lst in CAND.items():
  print(f"\n-- {t} {TIERS[t]['name']} --")
  print(f"{'tank L':>8s}{'area m2':>9s}"+"".join(f"{'Z-'+z:>13s}" for z in ZONES))
  for v,a in lst:
    cells=[]
    for z in ZONES:
        s=simulate(rd(z),a,v,TIERS[t]['demand'])
        cells.append(f"{s['rel']*100:3.0f}/{s['dry_rel']*100:3.0f}/{s['dry_days_covered']:3.0f}")
    print(f"{v:>8d}{a:>9d}"+"".join(f"{c:>13s}" for c in cells))

print(); print("="*104); print("D. HYDRAULICS: gutters, downpipes, first flush  (180 mm/h design intensity, 1:25yr)")
print("="*104)
for name,a,npipes in [("T1 HH 20 m2",20,1),("T2 120 m2",120,4),("T3 400 m2",400,8)]:
    D,q,cap=gutter_size(a); dp,qd=downpipe_size(a,pipes=npipes)
    print(f"{name:14s} peak flow {q:6.2f} L/s | gutter {D:3d} mm half-round @1:200 (cap {cap:5.2f} L/s) | {npipes}x downpipe {dp:3d} mm | first-flush {first_flush_volume(a):6.0f} L")

print(); print("="*104); print("E. FERROCEMENT / RCC SHELL CHECK"); print("="*104)
print(f"{'V L':>7s}{'D m':>6s}{'wall mm':>9s}{'depth m':>9s}{'hoop MPa':>10s}{'selfwt kN':>11s}   verdict")
for V,D,tw in [(3000,1.40,25),(4000,1.60,25),(5000,1.80,25),(10000,2.40,30),(20000,3.30,35),(50000,5.20,50)]:
    f=ferro_hoop(V,D,tw); w=selfweight(V,D,tw)
    ok = "ferrocement OK (allow 3.0 MPa at 8x FoS)" if f['hoop']<3.0 else "-> use RCC"
    print(f"{V:>7d}{D:>6.2f}{tw:>9d}{f['depth']:>9.2f}{f['hoop']:>10.2f}{w:>11.1f}   {ok}")

print(); print("="*104); print("F. CYCLONE WIND OVERTURNING (free-standing tank, 72 m/s gust = Amphan/Sidr class)")
print("="*104)
for V,D,H in [(3000,1.40,2.3),(5000,1.80,2.4),(10000,2.40,2.8),(20000,3.30,3.2)]:
    r=wind_overturning(V,D,H)
    print(f"V={V:>6d} D={D}m H={H}m  wind {r['F_kN']:5.1f} kN  M_over {r['M_overturn']:6.1f} kNm  M_rest {r['M_restore']:6.1f} kNm  FoS {r['FoS']:5.2f}  {'OK' if r['FoS']>1.5 else 'ANCHOR REQUIRED'}")

print(); print("="*104); print("G. BUOYANCY if tank sits in floodwater (empty tank) - reason we elevate, not bury, in flood zones")
print("="*104)
for V,D in [(10000,2.40),(20000,3.30),(50000,5.20)]:
    for fd in [0.6,1.2]:
        U=uplift(D,fd); W=selfweight(V,D,30,120)
        print(f"V={V:>6d} flood {fd} m -> uplift {U:6.1f} kN vs selfwt {W:6.1f} kN  FoS {W/U:4.2f}  {'OK' if W/U>1.3 else 'MUST ANCHOR / keep dry on plinth'}")

json.dump({f"{k[0]}|{k[1]}|{k[2]}":v for k,v in B.items()}, open("sizing_results.json","w"), indent=1)
