from svgkit import *
def draw(path):
    d=DWG(1500,980,100,title="D-07  OVERFLOW, MAR RECHARGE & ACCESS",no="BB-D-07")
    d.text(40,50,"INTEGRATED OVERFLOW, MANAGED AQUIFER RECHARGE & O&M ACCESS",20,INK,bold=True)
    d.text(40,72,"What happens to the water the tank cannot hold — and how a person safely gets inside the tank to clean it.",11,HID)

    # ---------- A. overflow hierarchy ----------
    d.text(40,112,"A — OVERFLOW MANAGEMENT HIERARCHY",12,RED,bold=True)
    steps=[("1. TANK","store it","highest value"),
           ("2. GARDEN","irrigate","second use"),
           ("3. RECHARGE","put it back in the ground","protects the dry-season source"),
           ("4. DRAIN","to a safe vegetated channel","never to a neighbour's land or a latrine")]
    x=40
    for i,(a,b,c) in enumerate(steps):
        fill=["#e8f1f8","#eef7ee","#dcece2","#f2f2f2"][i]
        d.rect(x,130,330,80,fill=fill,c=INK,sw=1.5,rx=3)
        d.text(x+16,154,a,11,INK,bold=True)
        d.text(x+16,174,b,9.2,HID)
        d.text(x+16,194,c,8.5,GREEN if i<3 else ACC)
        if i<3: arrow(d,x+334,170,x+352,170,sw=1.8)
        x+=360
    d.text(40,232,"Surplus is large: a T2 cluster spills 60–240 m³ a year and a T3 institution 290–970 m³. Discarding that as 'waste' is the single biggest design omission in most Bangladeshi RWH programmes.",9,GREEN)
    d.text(40,248,"In the coastal belt that surplus is what holds the freshwater lens above the saline interface. In the Barind it keeps the shallow aquifer, and the tubewells in it, alive through the dry season.",9,GREEN)

    # ---------- B. soak pit ----------
    d.text(40,300,"B — RECHARGE SOAK PIT, SECTION   (1:25)",12,RED,bold=True)
    cx,gl=170,700
    d.hatch(40,gl,300,26,"soil"); d.line(40,gl,340,gl,1.4)
    d.rect(cx-60,gl-260,120,260,fill="#ffffff",c=INK,sw=1.8)
    d.hatch(cx-60,gl-260,16,260,"brick"); d.hatch(cx+44,gl-260,16,260,"brick")
    d.hatch(cx-44,gl-56,88,56,"gravel")
    d.hatch(cx-44,gl-176,88,120,"gravel")
    d.hatch(cx-44,gl-260,88,84,"sand")
    d.rect(cx-70,gl-276,140,16,fill="url(#hconc)",c=INK,sw=1.4)
    d.rect(cx-14,gl-296,28,22,fill="#cfd8dc",c=INK,sw=1.3)
    arrow(d,cx,gl-292,cx,gl-256,sw=1.4)
    d.text(cx,gl-306,"overflow in, from tank",8.5,DIM,"middle")
    d.dimh(cx-60,cx+60,gl+40,"1.50 m")
    d.dimv(gl-260,gl,72,"2.20 m",9)
    d.leader(cx+60,gl-230,258,gl-250,"brick ring, 230 mm, open joints",8.5,INK)
    d.leader(cx+60,gl-140,258,gl-160,"graded gravel 20–40 mm",8.5,INK)
    d.leader(cx+60,gl-30,258,gl-50,"washed sand, geotextile wrap",8.5,INK)
    d.text(40,gl+64,"One pit per ~70 m³ of annual spill. RCC cap with a removable grating so it can be de-silted.",8.4,INK)
    d.text(40,gl+80,"A silted pit stops recharging and starts breeding mosquitoes. De-silting takes an hour.",8.4,ACC)

    # ---------- C. recharge well ----------
    d.text(560,300,"C — RECHARGE WELL   (where the aquifer is shallower than 10 m)",12,RED,bold=True)
    wx,wgl=700,700
    d.hatch(540,wgl,340,26,"soil"); d.line(540,wgl,880,wgl,1.4)
    d.rect(wx-12,wgl-300,24,300,fill="#ffffff",c=INK,sw=1.6)
    for k in range(14):
        d.line(wx-12,wgl-60-k*16,wx+12,wgl-60-k*16,1.6,INK)
    d.hatch(wx-30,wgl-300,18,240,"gravel"); d.hatch(wx+12,wgl-300,18,240,"gravel")
    d.rect(wx-40,wgl-316,80,16,fill="url(#hconc)",c=INK,sw=1.4)
    d.rect(wx-12,wgl-336,24,22,fill="#cfd8dc",c=INK,sw=1.3)
    arrow(d,wx,wgl-332,wx,wgl-300,sw=1.4)
    d.line(540,wgl-190,880,wgl-190,1.2,"#5b8fc0",dash="6 3")
    d.text(886,wgl-186,"standing water table",8,"#5b8fc0")
    d.leader(wx+12,wgl-200,880,wgl-240,"75 mm slotted uPVC screen",8.5,INK)
    d.dimv(wgl-300,wgl,905,"to 8 m",9)
    d.text(560,wgl+64,"Fit only where the water table is shallower than 10 m and the soil is permeable.",8.4,INK)
    d.text(560,wgl+80,"Test first: 300 mm of water in a 1 m trial hole should drain in under 6 hours.",8.4,INK)

    # ---------- D. access & safety ----------
    d.text(1000,300,"D — TANK ACCESS & CONFINED-SPACE SAFETY",12,RED,bold=True)
    d.rect(1000,316,444,300,fill="#fdf2f0",c=RED,sw=1.6,rx=4)
    d.text(1016,342,"NOBODY ENTERS A TANK ALONE. EVER.",10.5,RED,bold=True)
    for i,t in enumerate(["People die in Bangladeshi water tanks every year — not from",
                          "drowning, but from oxygen displacement and hydrogen sulphide",
                          "in a space nobody thought of as dangerous.","",
                          "The rule, with no exceptions:",
                          "   •  two people outside, one on the rope",
                          "   •  the rope tied to the person's chest, never the waist",
                          "   •  a ladder in place and lashed at the top",
                          "   •  lid open and vented for 15 minutes before entry",
                          "   •  no naked flame, no phone torch, no cigarette",
                          "   •  stop immediately if anyone feels dizzy or headachy","",
                          "If the tank needs a person inside, it is easier, safer and",
                          "cheaper to drain it, clean it from the top with a long-",
                          "handled brush, and refill."]):
        d.text(1016,364+i*15,t,8.4,INK)

    d.text(1000,650,"O&M ACCESS REQUIREMENTS AT DESIGN STAGE",10,RED,bold=True)
    rows=[["Manhole","Ø600 minimum, hinged, lockable, insect screen"],
          ["Ladder","SS or GI, fixed, to 300 mm above base"],
          ["Drain valve","75 mm, outside the tank, lockable"],
          ["Vent","Ø75 with 1 mm mesh, goose-neck"],
          ["Access apron","1.0 m clear hardstanding for a bucket and a person"],
          ["Lighting","no permanent light; use a torch held by the outside person"]]
    x0,y0=1000,664; cw=[110,334]
    x=x0
    for i,h in enumerate(["Item","Requirement"]):
        d.rect(x,y0,cw[i],20,fill=NAVY,c=INK,sw=0.8)
        d.text(x+6,y0+14,h,8.5,"#ffffff",bold=True); x+=cw[i]
    for r,row in enumerate(rows):
        x=x0
        for i,v in enumerate(row):
            d.rect(x,y0+20+r*22,cw[i],22,fill="#ffffff" if r%2 else "#f2f6f9",c=INK,sw=0.8)
            d.text(x+6,y0+35+r*22,v,8,INK); x+=cw[i]
    return d.save(path)
if __name__=="__main__": print(draw("/home/user/borsha_bandhu/drawings/D-07_overflow_mar_access.svg"))
