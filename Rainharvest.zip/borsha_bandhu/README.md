# Borsha-Bandhu — Integrated Rainwater Harvesting System

**বর্ষাবন্ধু** · Deployment package for marginalised and disaster-prone communities in Bangladesh
Revision A · 20 November 2026

A three-tier, five-zone rainwater harvesting system: engineering design, costed bills of materials, construction
procedure, water safety plan and programme implementation guide.

---

## The four findings this design is built on

1. **The sector-standard 2,000 L tank fails in the dry season.** On a 20 m² roof in the coastal belt it meets 79.9% of a
   household's potable demand annually but only **65.4% in the dry season** — 139 of 243 days. At **5,000 L** the same roof
   meets **100%** in all five zones. The extra cost is ≈13,000 BDT for four months of safe water per year.
2. **Households are storage-limited; institutions are catchment-limited.** A household roof yields ~1.8× annual demand,
   so money must go into tank volume. A 400-user institution on 600 m² is supply-limited and cannot exceed 73–82% even
   with unlimited storage, so money must go into catchment and a guaranteed second source.
3. **The overflow is the most wasted asset in the sector.** 7.6–31 m³/yr per household, 58–238 m³ per cluster,
   290–970 m³ per institution. Routed to managed aquifer recharge it sustains the freshwater lens on the coast and the
   shallow aquifer in the Barind. This is the "integrated" part.
4. **Institutions deliver water at a fifth of the unit cost** — 2,106 vs 11,339 BDT per person — and are also the building
   people shelter in during a cyclone.

**Design position:** size to 5 L/person/day of drinking and cooking water across 243 dry-season days at P80 dry-year
rainfall; route the overflow to recharge; never build an uncovered tank; build institutions first.

---

## Files

| File | What it is |
|---|---|
| `index.html` | One-page visual overview — start here |
| `01_Technical_Design_Manual.docx` | Design basis, hydraulic + structural calculations, treatment design, zone adaptations, tier specs, limitations |
| `02_Construction_OM_and_Water_Safety_Plan.docx` | Site readiness, 12-step build sequence with 4 QC hold points, ferrocement technique, commissioning, 18-task O&M calendar, water safety plan, disaster protocols, troubleshooting |
| `03_Programme_Implementation_and_DRR_Guide.docx` | Targeting and scoring, delivery modalities, training, early-warning integration, M&E, whole-life finance, scale-up costing, risk register, exit |
| `BorshaBandhu_Costing_and_Sizing_Model.xlsx` | 12 sheets: editable rate library, **live mass-balance calculator**, four itemised BoMs, whole-life cost, procurement, M&E |
| `drawings/D-01…D-07 (.svg)` | 7 engineering drawings, dimensioned, with title blocks |
| `engine/` | The Python model that generated every number in the package |

### Drawing register
| No. | Title |
|---|---|
| D-01 | Integrated RWH — process schematic |
| D-02 | T1 household tank — plan, section, armature detail |
| D-03 | Catchment, first-flush diverter and pre-filter |
| D-04 | T2 cluster unit — plan and section |
| D-05 | T3 institutional unit — treatment train and shelter mode |
| D-06 | Zone adaptations — coastal / flood / drought |
| D-07 | Overflow, MAR recharge and O&M access |

---

## The three tiers

| | T1 Household | T2 Cluster (10 HH) | T3 Institution |
|---|---|---|---|
| Storage | 5,000 L | 30,000 L | 60,000 L |
| Catchment | 20 m² | 160 m² | 600 m² |
| Serves | 6 people | 60 people | 400 people |
| Reliability | 100% year-round | 82–92% annual | 73–82% + 20-day reserve |
| Material | Ferrocement | Ferrocement | Ferrocement or RCC |
| **Core cost** | **68,032 BDT** | **273,449 BDT** | **842,427 / 1,137,520 BDT** |
| **Per person** | **11,339 BDT** | **4,557 BDT** | **2,106 / 2,844 BDT** |
| Per litre of storage | 13.6 BDT/L | 9.1 BDT/L | 14.0 / 19.0 BDT/L |

A mixed 100-unit programme (60 T1 + 30 T2 + 10 T3) reaches **5,560 people for ≈16.7 million BDT** in core capital —
about 3,000 BDT per person.

---

## Climate zones

| Zone | Region | Mean | P80 design | Design driver |
|---|---|---|---|---|
| A | Southwest coastal | 1,628 mm | 1,221 mm | Cyclone, surge, salinity |
| B | Southeast coastal | 3,525 mm | 2,644 mm | Cyclone landfall, wind |
| C | Flood plain & haor | 2,903 mm | 2,177 mm | Monsoon inundation |
| D | Barind & char | 1,543 mm | 1,157 mm | Drought, arsenic |
| E | Central plain | 2,147 mm | 1,610 mm | Urban flooding, arsenic |

P80 = 0.75 × BMD 30-year monthly normal.

---

## How the numbers were produced

Every figure in the package traces to `engine/`:

- `rwh_model.py` — BMD monthly rainfall by zone, cyclic monthly mass balance, Rational-Method gutter sizing (Manning),
  ferrocement hoop stress, uplift, wind overturning.
- `quantities.py` — geometry → material take-off at 2026 Bangladesh rates.
- `model.py` — itemised bills of materials, core/optional/alternative scope.
- `build_xlsx.py`, `d0*.py`, `doc1–3.py` — the deliverables. **The documents read from the same `bom.json`,** so a
  rate change propagates through the manual, the spreadsheet and the drawings together.

Re-generate everything:

```bash
cd engine
python3 model.py          # rebuilds bom.json
python3 build_xlsx.py     # rebuilds the workbook
python3 doc1.py && python3 doc2.py && python3 doc3.py
python3 d01.py && python3 d02.py && python3 d03.py && python3 d04.py && python3 d05.py && python3 d06.py && python3 d07.py
```

---

## Before you deploy — verify per site

These are stated in Design Manual §11 and are not optional:

- Soil bearing capacity ≥ 50 kN/m² at the tank location.
- Flood level from the **local BWDB gauge** for the specific union.
- Actual measured roof area, material and structural condition; and that the household controls the roof.
- Local material prices — re-quote before tender; cement and steel move.
- A named local supplier of calcium hypochlorite, with a price. A chlorination system with no consumable supply chain
  is worse than none.
- **The secondary source exists and is tested.** This is the most frequently skipped step in RWH programming.
- Aquifer depth and permeability before specifying a recharge well.
- A ferrocement-trained mason within the upazila, or use the bought-in HDPE alternative priced in the model.

## Limitations

The design supplies drinking and cooking water at 5 L/person/day — **not total domestic demand**. It excludes roofs used
for drying fish or grain and roofs downwind of brick kilns. Institutional RWH is not self-sufficient in the driest zones;
it is one source in a package, and the manual says so explicitly.

---

*Rates are indicative 2026 Bangladesh market prices delivered to upazila. Design values to be verified per site before
construction.*
