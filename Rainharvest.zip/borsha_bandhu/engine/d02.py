from svgkit import *
S=150  # px per metre for plan/section

def draw(path):
    d=DWG(1500,1150,S,title="D-02  T1 HOUSEHOLD TANK — GA",no="BB-D-02")
    d.text(40,50,"T1 HOUSEHOLD UNIT  —  5,000 L FERROCEMENT TANK",20,INK,bold=True)
    d.text(40,72,"Plan, section and reinforcement detail.  Scale 1:50 unless noted.",11,HID)

    # ================= PLAN =================
    d.text(60,110,"PLAN  (1:50)",12,RED,bold=True)
    cx,cy=250,340
    d.circle(cx,cy,150,fill="#f7f3ea",c=INK,sw=1.6)        # plinth outer
    d.circle(cx,cy,139,fill=FILL_W,c=INK,sw=2)             # tank outer
    d.circle(cx,cy,135,fill="none",c=INK,sw=1)             # wall inner
    d.circle(cx,cy,45,fill="#ffffff",c=INK,sw=1.4,dash="5 3")  # manhole
    d.text(cx,cy-3,"Ø600 manhole",8.5,HID,"middle")
    d.text(cx,cy+12,"(sealed, lockable)",8,HID,"middle")
    d.line(cx-170,cy,cx+170,cy,0.7,HID,"14 4 3 4")
    d.line(cx,cy-180,cx,cy+180,0.7,HID,"14 4 3 4")
    # inlet
    d.rect(cx-14,cy-186,28,40,fill="#cfd8dc",c=INK,sw=1.3)
    d.text(cx+22,cy-160,"inlet Ø50",9,DIM)
    # overflow
    d.rect(cx+128,cy+30,50,20,fill="#cfd8dc",c=INK,sw=1.3)
    d.text(cx+150,cy+66,"overflow",9,DIM,"middle")
    # draw-off to tapstand
    d.rect(cx-30,cy+130,22,52,fill="#cfd8dc",c=INK,sw=1.3)
    d.text(cx-36,cy+196,"draw-off to tapstand",9,DIM,"middle")
    # dims
    d.dimh(cx-139,cx+139,cy+232,"Ø1.80 m tank")
    d.dimh(cx-150,cx+150,cy+262,"Ø2.00 m plinth")
    d.text(cx,cy+296,"SECTION A-A BELOW",9,HID,"middle")

    # ================= SECTION A-A =================
    d.text(700,110,"SECTION A-A  (1:50)",12,RED,bold=True)
    cx=900; gl=640
    pt=gl-0.60*S          # 550 plinth top
    bt=pt-0.10*S          # 535 base top
    wt=bt-1.96*S          # 241 wall top
    cv=wt-0.065*S         # 231 cover top
    ro,ri=139,135
    # soil
    d.hatch(700,gl,420,46,"soil")
    d.line(700,gl,1120,gl,1.6)
    # plinth
    d.hatch(cx-150,pt,300,gl-pt,"brick")
    # base slab
    d.hatch(cx-145,bt,290,pt-bt,"conc")
    # walls
    d.hatch(cx-ro,wt,ro-ri,bt-wt,"conc"); d.hatch(cx+ri,wt,ro-ri,bt-wt,"conc")
    # cover
    d.hatch(cx-139,cv,278,wt-cv,"conc")
    d.rect(cx-30,cv,60,wt-cv,fill="#ffffff",c=INK,sw=1.2)
    # water
    wl=wt+22
    d.rect(cx-ri,wl,2*ri,bt-wl-15,fill="url(#hwater)",c="none",sw=0)
    d.line(cx-ri,wl,cx+ri,wl,1.4,"#5b8fc0")
    # sediment
    d.hatch(cx-ri,bt-15,2*ri,15,"sand")
    # inlet / draw-off / overflow / sump drain
    d.rect(cx-14,cv-26,28,36,fill="#cfd8dc",c=INK,sw=1.3)
    d.poly([(cx+ri,wl+10),(cx+ri+44,wl+10)],c=INK,sw=2.4); d.text(cx+ri+50,wl+14,"overflow",9,DIM)
    d.poly([(cx-ri,bt-26),(cx-ri-46,bt-26)],c=INK,sw=2.4); d.text(cx-ri-52,bt-22,"draw-off",9,DIM,"end")
    d.rect(cx-8,bt-8,16,16,fill="#ffffff",c=RED,sw=1.3)  # sump drain
    d.leader(cx+8,bt,cx+70,bt+34,"sump drain valve",8.5,RED)
    # levels
    d.line(cx-ri,wl,cx+ri,wl,1.2,"#5b8fc0")
    d.leader(cx-ri-10,wl-4,cx-250,wl-30,"water level, freeboard 150 mm",9,"#5b8fc0")
    # dims
    d.dimv(cv,gl,1096,"2.875 m overall")
    d.dimv(wl,bt-15,1062,"1.96 m internal depth")
    d.dimv(pt,gl,1028,"0.60 m")
    d.dimh(cx-139,cx+139,gl+108,"Ø1.80 m internal")
    d.dimh(cx-150,cx+150,gl+140,"Ø2.00 m plinth")
    for x in (1028,1062,1096): d.line(x,gl,x,gl+50,0.6,HID)

    # ================= DETAILS =================
    d.line(40,776,1460,776,0.8,HID)
    d.text(60,806,"DETAIL 1 — WALL ARMATURE, UNROLLED  (1:5)",12,RED,bold=True)
    x0,y0,w,h=70,826,340,168
    d.rect(x0,y0,w,h,fill="#ffffff",c=INK,sw=1.2)
    # chicken wire 25mm -> 14.2px at 1:5 (1m=568px)
    k=14.2
    x=x0
    while x<x0+w+1: d.line(x,y0,x,y0+h,0.5,"#b0b0b0"); x+=k
    y=y0
    while y<y0+h+1: d.line(x0,y,x0+w,y,0.5,"#b0b0b0"); y+=k
    # weld mesh 25x25 slightly darker, offset
    x=x0+k/2
    while x<x0+w+1: d.line(x,y0,x,y0+h,0.9,"#8a8a8a"); x+=k
    y=y0+k/2
    while y<y0+h+1: d.line(x0,y,x0+w,y,0.9,"#8a8a8a"); y+=k
    # MS rods @150 = 85px
    r=85.2
    for i in range(1,5):
        X=x0+i*r-20
        if x0<X<x0+w: d.line(X,y0,X,y0+h,3.2,RED)
    for j in range(1,3):
        Y=y0+j*r-18
        if y0<Y<y0+h: d.line(x0,Y,x0+w,Y,3.2,RED)
    d.dimh(x0+65,x0+65+r,y0+h+34,"150")
    d.text(x0+w/2,y0+h+58,"rod spacing 150 c/c both ways",9,HID,"middle")
    d.leader(x0+150,y0+70,x0+380,y0+30,"Ø8 mm MS rod",9,RED)
    d.leader(x0+105,y0+120,x0+380,y0+70,"weld mesh 25×25×3 mm",9,RED)
    d.leader(x0+20,y0+150,x0+380,y0+110,"2 layers chicken wire 20G @25 mm,",9,"#555555")
    d.text(x0+380,y0+124,"50% overlap, tied at 150",9,"#555555")
    d.text(60,1052,"Hoop stress at base of full tank 0.69 MPa  |  allowable 3.0 MPa  |  factor of safety 4.3",9,GREEN,bold=True)
    d.text(60,1070,"Armature is the structure. Mortar is only the matrix — do not reduce the wire layers to save cost.",9,GREEN)

    d.text(700,806,"DETAIL 2 — BASE / WALL JUNCTION  (1:4)",12,RED,bold=True)
    bx,by=640,930
    d.rect(bx,by,300,34,fill="url(#hconc)",c=INK,sw=1.4)          # base slab
    d.rect(bx+120,by-130,26,130,fill="url(#hconc)",c=INK,sw=1.4) # wall
    d.path(f"M {bx+120} {by} L {bx+120} {by-22} Q {bx+150} {by-16} {bx+152} {by} Z",fill="#cfcfcf",c=RED,sw=1.6)
    d.line(bx+133,by-130,bx+133,by+26,2.6,RED)                   # rod into base
    d.leader(bx+150,by-12,bx+250,by-52,"25 mm haunch: no sharp internal corner",8.5,RED)
    d.leader(bx+133,by-96,bx+235,by-104,"Ø8 rod continues into base and turns 90°",8.5,RED)
    d.leader(bx+300,by+34,bx+300,by+72,"base slab 100 mm, 1:2:4, weld mesh both ways",8.5,INK,"end")
    d.text(bx-6,by+96,"Curing: keep damp for 7 days. A tank cured dry cracks, and a cracked tank leaks.",9,GREEN,bold=True)

    # notes
    d.text(1150,806,"NOTES",12,RED,bold=True)
    notes=["1. All dimensions in millimetres unless shown in metres.",
     "2. Ferrocement to be built on a level, firm base; never on",
     "    filled or organic ground.",
     "3. Cover cast separately, cured, then sealed with 1:2 mortar",
     "    and a flexible food-grade sealant.",
     "4. Tank must be sited ≥ 900 mm from the house wall.",
     "5. Anchor the cover to the wall with 4 no. M8 stainless",
     "    bolts — this is a cyclone-country requirement.",
     "6. Test: fill, hold 24 h, top up, hold 24 h. Loss must be",
     "    < 1% of capacity or the shell is re-rendered.",
     "7. Do not site under a tree: leaf load blocks the gutter and",
     "    bird droppings contaminate the supply.",
     "8. Ground must be firm and level: bearing capacity ≥ 50 kN/m².",
     "    Never build on filled, organic or seasonally flooded ground."]
    for i,t in enumerate(notes): d.text(1150,826+i*15,t,8,INK)
    return d.save(path)

if __name__=="__main__":
    print(draw("/home/user/borsha_bandhu/drawings/D-02_T1_household_tank.svg"))
