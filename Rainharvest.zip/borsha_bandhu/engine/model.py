"""Master model: geometry -> quantities -> itemised BoM -> cost. Single source of truth.
   Items marked optional=True are programme add-ons; both core and full totals are reported."""
import math, json
from quantities import RATES, ferro_tank, rcc_tank
from rwh_model import ZONES, DESIGN_FACTOR, simulate, gutter_size, downpipe_size, first_flush_volume

R=RATES
def I(cat,item,spec,unit,qty,rate,optional=False,alt=False):
    return dict(cat=cat,item=item,spec=spec,unit=unit,qty=round(qty,2),rate=rate,
                amount=round(qty*rate),optional=optional,alt=alt)

def plinth_brick(dia,h):
    circ=math.pi*dia; vol=circ*0.23*h
    return [I("Site & foundation","Bricks, 1st class","plinth ring + capping, 230mm, 1:6","no",vol*500*1.05,R["brick_piece"]),
            I("Site & foundation","Cement for plinth","1:6 mortar","bag",vol*1.6,R["cement_bag_50kg"]),
            I("Site & foundation","Sand for plinth","local river sand","m3",vol*0.35,R["sand_m3"])]

def catchment(area,gutter_m,n_dp,dp_len):
    D,q,cap=gutter_size(area); dp,qd=downpipe_size(area,pipes=n_dp); ff=first_flush_volume(area)
    return dict(gutter_D=D,peak_q=q,dp_D=dp,first_flush_L=ff),[
      I("Catchment","GI gutter, 0.45mm, 600mm girth","fabricated, 1:200 fall, stop-ends","m",gutter_m,R["GIgutter06_m"]),
      I("Catchment","Gutter brackets","MS epoxy-coated @600 c/c","no",math.ceil(gutter_m/0.6),R["gutter_bracket_no"]),
      I("Catchment","Leaf screen / gutter guard","SS304 mesh, hinged for cleaning","no",max(2,n_dp),R["leafscreen_no"]),
      I("Catchment",f"uPVC downpipe {dp} mm","Class-5, UV stabilised","m",n_dp*dp_len,R["pvc110_m"]),
      I("Catchment","Downpipe clamps, shoes, bends","uPVC","ls",n_dp,360),
      I("Catchment","First-flush diverter, self-emptying",f"{dp}mm uPVC, {ff:.0f} L chamber, float-ball auto-reset","no",n_dp,950 if n_dp<=1 else 1250)]

def prefilter(size):
    if size=="small": return [I("Pre-treatment","Pre-filter, 60 L","HDPE drum, gravel/coarse-sand/charcoal, removable mesh","no",1,1800),
                              I("Pre-treatment","Filter media charge","washed gravel + graded sand + charcoal","ls",1,900),
                              I("Pre-treatment","Cascade aerator at tank inlet","uPVC; raises DO, strips volatiles","no",1,650)]
    if size=="medium": return [I("Pre-treatment","3-stage pre-filter battery, 200 L","gravel -> coarse sand -> charcoal, backwash valve","no",1,5200),
                               I("Pre-treatment","Filter media charge","gravel 0.15 m3 + sand 0.12 m3 + charcoal 12 kg","ls",1,3600),
                               I("Pre-treatment","Cascade aerator","SS304, tank inlet","no",1,1400)]
    return [I("Pre-treatment","Up-flow roughing filter, 1.2 m2","gravel 3 grades, air-scour backwash","no",1,34000),
            I("Pre-treatment","Slow sand filter, 2.0 m2","0.7 m graded sand + underdrain, 0.15 m/h","no",1,48000),
            I("Pre-treatment","Filter media charge","sand 2.1 m3, gravel 0.9 m3, charcoal 40 kg","ls",1,15000)]

def disinfection(size):
    b=[I("Disinfection","Calcium hypochlorite 65%","HTH, 1 kg sealed HDPE jars","kg",2 if size=="small" else 6,R["calhypo_kg"])]
    if size=="small": b+=[I("Disinfection","Household dosing kit","1 L opaque dropper + 5 mL measure + dosing card","no",1,450),
                          I("Disinfection","Residual Cl + pH test kit","DPD tablet, 100 tests","no",1,R["chlorine_testkit"])]
    elif size=="medium": b+=[I("Disinfection","Constant-head chlorinator, 20 L","0.2-0.5 mg/L residual, lockable","no",1,4200),
                             I("Disinfection","Residual Cl + pH + turbidity field kit","200 tests","no",1,R["testkit_pH_Cl"])]
    else: b+=[I("Disinfection","Flow-proportional hypochlorinator, 50 L","lockable, dosing pump option","no",1,14500),
              I("Disinfection","Water quality field laboratory","H2S vial, DPD, pH, turbidity, EC/TDS","ls",1,26000)]
    return b

def mar(spill_m3,scale):
    if scale=="small":
        return [I("Integrated / MAR","Roof-runoff recharge pit","1.0 m dia x 1.5 m, brick ring, graded gravel, geotextile","no",1,2600),
                I("Integrated / MAR","Garden / livestock overflow","75mm PVC + 200 L drum","ls",1,900)]
    n=max(1,math.ceil(spill_m3/70))
    return [I("Integrated / MAR","Recharge soak pit",f"1.5 m dia x 2.2 m, brick ring, gravel, geotextile. {n} no.","no",n,620*8+2100),
            I("Integrated / MAR","Recharge well to aquifer","75mm slotted uPVC to 8 m, gravel pack","no",0 if spill_m3<50 else 1,9800),
            I("Integrated / MAR","Kitchen-garden / livestock overflow","110mm PVC + 200 L drum","ls",1,1600)]

def fence(size):
    if size=="small": return [I("Protection","Lockable hatch + mosquito-proof vent","SS hinge, 1 mm mesh","no",2,R["hatch_lid_RCC"]*0.5),
                              I("Protection","O&M signage","Bengali pictogram: dosing, cleaning, contacts","no",1,R["signage_no"])]
    L={"medium":16,"large":55}[size]
    return [I("Protection","Perimeter safety fence","GI post + welded mesh","m",L,620),
            I("Protection","Lockable hatches + insect-proof vents","SS hinge, 1mm mesh","no",2,R["manhole_cover"]),
            I("Protection","O&M / water safety signage","Bengali pictogram board","no",1,R["signage_no"])]

def labour(mason,helper,plumber=0,welder=0):
    o=[]
    if mason:  o.append(I("Labour","Mason / ferrocement-trained builder","","man-day",mason,R["mason_day"]))
    if helper: o.append(I("Labour","Helper (community labour may substitute)","","man-day",helper,R["helper_day"]))
    if plumber:o.append(I("Labour","Plumber","","man-day",plumber,R["plumber_day"]))
    if welder: o.append(I("Labour","Welder","","man-day",welder,R["welder_day"]))
    return o

def shell_ferro(V,D,tw,label):
    q=ferro_tank(V,D,tw)
    return q,[I("Storage",f"Ferrocement tank, {V:,} L",f"ID {D} m x {q['h']} m, {tw}mm wall, 2-layer chicken wire + weld-mesh armature","no",1,0),
        I("Storage","Cement","1:2 mortar shell, 1:2:4 base","bag",q["cement_bag"],R["cement_bag_50kg"]),
        I("Storage","Sand","washed, graded","m3",q["sand_m3"],R["sand_m3"]),
        I("Storage","Aggregate / brick chips","12 mm downgraded","m3",q["aggregate_m3"],R["brick_chips_m3"]),
        I("Storage","MS rod 8 mm","armature @150 c/c both ways","kg",q["steel8_kg"],R["steel_8mm_kg"]),
        I("Storage","Chicken wire 20G, 25 mm","2 layers + 50% overlap","m2",q["mesh_m2"],R["chickenwire_m2"]),
        I("Storage","GI binding wire","tying","kg",q["GIwire_kg"],R["GIwire_kg"]),
        I("Storage","Integral waterproofing compound","1% of cement mass","kg",q["additive_kg"],R["waterproof_additive_kg"]),
        I("Storage","Formwork / reusable mould","","m2",q["formwork_m2"],R["formwork_m2"]),
        I("Storage","Food-grade epoxy lining","2 coats, potable contact","l",round(q["wall_area"]*0.12,1),R["paint_epoxy_l"])]

def build(tier, construct="ferro"):
    if tier=="T1":
        V,D=5000,1.80
        q,shell=shell_ferro(V,D,25,"T1")
        hyd,catch=catchment(20,12,1,5.5)
        sp=simulate([r*DESIGN_FACTOR for r in ZONES["A"]["m"]],20,V,30)["spill"]/1000
        items=[I("Site & foundation","Survey, setting out, excavation","0.5 m3, levelling","ls",1,1500)]
        items+=plinth_brick(2.0,0.60); items+=catch; items+=prefilter("small"); items+=shell
        items+=[I("Storage","Precast RCC cover + sealed manhole",f"{q['cover_area']} m2, 65 mm, lockable","no",1,R["hatch_lid_RCC"])]
        items+=[I("Distribution","Tapstand, single bibcock","GI frame, concrete apron, soakaway","no",1,R["tapstand_set"]),
                I("Distribution","Potable draw-off, ceramic candle filter","gravity, 2 candles, treated water only","no",1,R["candle_filter_set"])]
        items+=disinfection("small"); items+=mar(sp,"small"); items+=fence("small")
        items+=labour(4,8,1)
        items+=[I("Logistics & QA","Transport, last mile","","ls",1,1800),
                I("Logistics & QA","Curing, bacteriological test, handover","7-day moist cure; DPHE lab test","no",1,1800),
                I("Logistics & QA","Household training, 2 sessions","use, dosing, first-flush reset, cleaning","hh",1,600),
                I("Optional","Roof catchment extension, +10 m2","where existing roof < 20 m2 (Zone D)","ls",1,7400,True),
                I("Alternative","HDPE 5,000 L tank in lieu of ferrocement","bought-in; where no trained mason exists","no",1,R["HDPE_tank_5000"]-6200,False,True)]
        meta=dict(code="T1",name="Household Unit",volume=V,dia=D,height=q["h"],catchment_m2=20,
                  users=6,demand_lpd=30,hyd=hyd,spill_m3=round(sp,1))
    elif tier=="T2":
        V,D=30000,3.90
        q,shell=shell_ferro(V,D,32,"T2")
        hyd,catch=catchment(160,60,4,6.0)
        sp=simulate([r*DESIGN_FACTOR for r in ZONES["A"]["m"]],160,V,300)["spill"]/1000
        items=[I("Site & foundation","Survey, setting out, excavation","4 m3","ls",1,3800),
               I("Site & foundation","RCC ring-beam foundation","1:2:4, 300x400, 2x12mm continuous","ls",1,17200)]
        items+=catch; items+=prefilter("medium"); items+=shell
        items+=[I("Storage","Precast RCC cover, 2 sealed manholes","vented, insect screen, lockable","no",1,9800)]
        items+=[I("Distribution","Communal tapstand, 3 taps","concrete apron, washing slab, 5 m drainage","no",2,3840),
                I("Distribution","Potable draw-off + candle filter bank","4 candles, locked, caretaker-operated","no",1,5400)]
        items+=disinfection("medium"); items+=mar(sp,"medium"); items+=fence("medium")
        items+=labour(18,40,3)
        items+=[I("Logistics & QA","Transport","","ls",1,8200),
                I("Logistics & QA","Water quality testing, 3 rounds","DPHE/ICDDR,B: TTC, pH, turbidity, As, Fe, Cl","ls",1,7200),
                I("Logistics & QA","Community training + WASH committee","2 caretakers, bookkeeping, tariff setting","ls",1,13500),
                I("Optional","Recharge well to shallow aquifer","where aquifer < 10 m and MAR justified","no",1,9800,True),
                I("Optional","Solar pump + 2,000 L overhead tank","where gravity head is insufficient","ls",1,62000,True)]
        meta=dict(code="T2",name="Cluster Unit (10 households)",volume=V,dia=D,height=q["h"],catchment_m2=160,
                  users=60,demand_lpd=300,hyd=hyd,spill_m3=round(sp,1))
    else:
        V,D=60000,5.60
        hyd,catch=catchment(600,100,8,7.0)
        sp=simulate([r*DESIGN_FACTOR for r in ZONES["A"]["m"]],600,V,1000)["spill"]/1000
        items=[I("Site & foundation","Survey, geotechnical check, setting out","SPT where soft ground","ls",1,11000),
               I("Site & foundation","Excavation & disposal","18 m3","m3",18,520),
               I("Site & foundation","RCC raft foundation","250 mm, 2 layers 12 mm @150, waterbar","ls",1,92000)]
        items+=catch; items+=prefilter("large")
        if construct=="rcc":
            q=rcc_tank(V,D)
            items+=[I("Storage",f"RCC tank, {V:,} L",f"ID {D} m x {q['h']} m, 200 mm wall, 250 mm base, water-retaining mix","no",1,0),
                    I("Storage","Cement","","bag",q["cement_bag"],R["cement_bag_50kg"]),
                    I("Storage","Sand","","m3",q["sand_m3"],R["sand_m3"]),
                    I("Storage","Aggregate 20+12 mm","graded","m3",q["aggregate_m3"],R["aggregate_m3"]),
                    I("Storage","Reinforcement 10-12 mm","95 kg/m3, water-retaining + seismic","kg",q["steel_kg"],R["steel_10mm_kg"]),
                    I("Storage","Steel formwork","2 uses","m2",q["formwork_m2"],R["formwork_m2"]),
                    I("Storage","Crystalline waterproofing + food-grade epoxy","internal face","ls",1,44000),
                    I("Storage","RCC roof slab + 2 sealed manholes","vented, insect screen","no",1,24000)]
        else:
            q,shell=shell_ferro(V,D,42,"T3"); items+=shell
            items+=[I("Storage","Precast RCC cover, 3 sealed manholes","vented, insect screen, lockable","no",1,16000)]
        items+=[I("Distribution","Tapstand bank, 4 units","stainless bibcocks, aprons, drainage","no",4,4320),
                I("Distribution","Hand-pump backup draw-off","suction lift, no power required","no",1,16500),
                I("Distribution","2,000 L overhead day tank","HDPE, gravity feed to taps","no",1,26000)]
        items+=disinfection("large"); items+=mar(sp,"large"); items+=fence("large")
        items+=[I("Protection","Cyclone anchorage set","M16 SS anchors + 4 tie-down straps","ls",1,14500)]
        items+=labour(45,90,10,6)
        items+=[I("Logistics & QA","Transport & lifting","boom lift for cover slab","ls",1,38000),
                I("Logistics & QA","Commissioning: pressure test, 72 h hold, disinfection","","ls",1,12000),
                I("Logistics & QA","Water quality lab testing, 4 rounds","full ECR'97 suite","ls",1,24000),
                I("Logistics & QA","Institutional training + Water Safety Plan","caretaker, head teacher, SMC, drill","ls",1,36000),
                I("Optional","Solar pump, 400 W + 0.5 hp DC","where grid absent (most shelters)","ls",1,78000,True),
                I("Optional","Emergency reserve valve + 14-day sealed reserve kit","cyclone shelter mode","ls",1,18500,True)]
        meta=dict(code="T3",name="Institutional Unit (school / cyclone shelter)",volume=V,dia=D,height=q["h"],
                  catchment_m2=600,users=400,demand_lpd=1000,hyd=hyd,spill_m3=round(sp,1),
                  construct=construct)
    items=[i for i in items if not (i["unit"]=="no" and i["qty"]==0)]
    core=[i for i in items if not i["optional"] and not i.get("alt")]
    opt=[i for i in items if i["optional"] and not i.get("alt")]
    cats={}
    for i in core: cats[i["cat"]]=cats.get(i["cat"],0)+i["amount"]
    return dict(meta=meta,items=items,core_total=sum(i["amount"] for i in core),
                optional_total=sum(i["amount"] for i in opt),
                full_total=sum(i["amount"] for i in core)+sum(i["amount"] for i in opt),by_category=cats)

if __name__=="__main__":
    out={}
    for t,c in [("T1","ferro"),("T2","ferro"),("T3","ferro"),("T3","rcc")]:
        k=t if not(c=="rcc") else "T3rcc"
        d=build(t,c); out[k]=d
        m=d["meta"]
        print(f"\n=== {m['code']} {m['name']} [{c.upper()}] {m['volume']:,} L  D={m['dia']}m h={m['height']}m ===")
        print(f"    CORE {d['core_total']:>9,} | optional {d['optional_total']:>8,} | FULL {d['full_total']:>9,} BDT")
        print(f"    cost/beneficiary core {d['core_total']/m['users']:>7,.0f} | per litre {d['core_total']/m['volume']:>5.1f} BDT/L")
        for cat,v in sorted(d["by_category"].items(),key=lambda x:-x[1])[:5]:
            print(f"      {cat:22s}{v:>9,}")
    json.dump(out,open("bom.json","w"),indent=1)
    print("\nwritten bom.json")
