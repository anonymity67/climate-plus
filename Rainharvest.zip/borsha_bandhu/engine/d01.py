from svgkit import *

def draw(path):
    d=DWG(1500,880,160,title="D-01  INTEGRATED RWH — PROCESS SCHEMATIC",no="BB-D-01")
    d.text(40,50,"INTEGRATED RAINWATER HARVESTING — SYSTEM PROCESS SCHEMATIC",20,INK,bold=True)
    d.text(40,72,"One process train serves all three tiers. Capacities change; the treatment logic does not.",11,HID)

    def box(x,y,w,h,fill,title,sub,notes=(),c=INK):
        d.rect(x,y,w,h,fill=fill,c=c,sw=1.4,rx=4)
        d.text(x+w/2,y+20,title,11,INK,"middle",bold=True)
        d.text(x+w/2,y+37,sub,9.5,HID,"middle")
        for i,n in enumerate(notes):
            d.text(x,y+h+16+i*13,n,9,HID)

    # ① catchment ------------------------------------------------------
    d.text(40,104,"①  CATCHMENT & CONVEYANCE",12,RED,bold=True)
    y=112
    box(40,y,200,50,FILL_B,"ROOF CATCHMENT","GI / tile / asbestos",("T1 20 m² · T2 160 m² · T3 600 m²","Runoff coefficient 0.80"))
    box(266,y,196,50,FILL_B,"GUTTER + LEAF SCREEN","half-round, 1:200 fall",("T1 Ø75 · T2 Ø150 · T3 Ø250",))
    box(488,y,190,50,FILL_B,"DOWNPIPE","uPVC Class 5",("T1 Ø50 · T2 4×Ø50 · T3 8×Ø63",))
    box(704,y,250,50,"#fde7e4","FIRST-FLUSH DIVERTER","self-emptying, float-ball reset",("Discards first 1.5 mm of rain:","T1 30 L · T2 180 L · T3 600 L"))
    for x1,x2 in [(240,266),(462,488),(678,704)]: arrow(d,x1,y+25,x2-4,y+25)

    # ② pre-treatment --------------------------------------------------
    d.text(40,232,"②  PRE-TREATMENT",12,RED,bold=True)
    y2=240
    box(430,y2,235,54,FILL_G,"PRE-FILTER","gravel → coarse sand → charcoal",("removes leaves, grit, colour and","organics; backwashable",))
    box(690,y2,205,54,FILL_G,"CASCADE AERATOR","at the tank inlet",("adds oxygen, strips volatiles",))
    d.poly([(829,162),(829,212),(547,212)],c=DIM,sw=1.5)
    d.add(f'<polygon points="547,212 555,208 555,216" fill="{DIM}"/>')
    arrow(d,665,y2+27,686,y2+27)

    # ③ storage --------------------------------------------------------
    d.text(40,364,"③  STORAGE  —  sealed, covered, mosquito-proof, drawn from a floating or calmed inlet",12,RED,bold=True)
    d.poly([(792,294),(792,340),(1118,340)],c=DIM,sw=1.5)
    d.add(f'<polygon points="1118,340 1110,336 1110,344" fill="{DIM}"/>')
    tx,ty,tw,th=1120,352,190,150
    d.rect(tx,ty,tw,th,fill=FILL_W,c=INK,sw=2,rx=2)
    d.rect(tx+8,ty+22,tw-16,th-30,fill="url(#hwater)",c="none",sw=0)
    d.line(tx+8,ty+22,tx+tw-8,ty+22,1.3,"#5b8fc0")
    d.rect(tx+34,ty-8,12,30,fill="#cfd8dc",c=INK,sw=1.2)   # inlet
    d.text(tx+tw/2,ty+th+18,"STORAGE TANK",11,INK,"middle",bold=True)
    d.text(tx+tw/2,ty+th+33,"T1 5,000 L  ·  T2 30,000 L  ·  T3 60,000 L",9.5,HID,"middle")
    d.leader(tx+3,ty+th-18,tx-190,ty+th+88,"sump / sediment trap — base falls 1% to a drain valve, cleaned annually",9,GREEN)
    d.leader(tx+8,ty+30,tx-120,ty-14,"calmed inlet: no turbulence to re-suspend sediment",9,GREEN)

    # ④ disinfection & distribution ------------------------------------
    d.text(40,596,"④  DISINFECTION & DISTRIBUTION",12,RED,bold=True)
    y4=604
    d.poly([(tx+tw-30,ty+th),(tx+tw-30,578),(360,578),(360,600)],c=DIM,sw=1.5)
    d.add(f'<polygon points="360,604 356,596 364,596" fill="{DIM}"/>')
    box(360,y4,208,58,"#e8eef7","CHLORINATION","Ca-hypochlorite 65% · 0.2–0.5 mg/L",("T1 dropper bottle · T2 constant-head","T3 flow-proportional hypochlorinator"))
    box(592,y4,190,58,"#e8eef7","TAPSTAND","2–4 taps, apron, drainage",("sited with women's agreement",))
    box(806,y4,210,58,"#e8eef7","POTABLE POINT","ceramic candle filter",("drinking water only; candles","renewed every 12–18 months"))
    arrow(d,568,y4+29,588,y4+29)
    arrow(d,782,y4+29,802,y4+29)

    # ⑤ integrated overflow --------------------------------------------
    d.text(40,696,"⑤  INTEGRATED OVERFLOW  —  the surplus is an asset, not waste",12,GREEN,bold=True)
    d.poly([(tx+tw-12,ty+th),(tx+tw-12,734),(1010,734)],c=GREEN,sw=1.5)
    d.add(f'<polygon points="1006,734 1014,730 1014,738" fill="{GREEN}"/>')
    d.text(tx+tw+4,ty+th+52,"overflow",9,GREEN,rot=-90)
    d.rect(40,706,966,58,"#dcece2",c=GREEN,sw=1.5,rx=4)
    cols=[("MAR RECHARGE PIT","soak pit 1.0–1.5 m Ø × 2.2 m deep"),
          ("RECHARGE WELL","75 mm slotted uPVC to 8 m, where aquifer < 10 m"),
          ("KITCHEN GARDEN","irrigation + livestock, year-round vegetables")]
    for i,(t,s) in enumerate(cols):
        cx=40+322*i
        if i: d.line(cx,710,cx,760,0.8,GREEN)
        d.text(cx+161,731,t,10.5,GREEN,"middle",bold=True)
        d.text(cx+161,749,s,9,HID,"middle")
    d.text(40,792,"Why integrated:  the same structure delivers drinking water, recharges the shallow aquifer households fall back on in the dry season, and produces garden water.",10,GREEN)
    d.text(40,812,"No RWH tank in coastal Bangladesh covers twelve months from roof capture alone. The recharge pit is what turns the overflow into that second source.",10,GREEN,bold=True)
    return d.save(path)

if __name__=="__main__":
    import os; os.makedirs("/home/user/borsha_bandhu/drawings",exist_ok=True)
    print(draw("/home/user/borsha_bandhu/drawings/D-01_system_schematic.svg"))
