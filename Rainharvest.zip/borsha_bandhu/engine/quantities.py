"""Quantity take-off from geometry. Every BoM line is derived, not typed."""
import math, json

# ---------------- 2026 Bangladesh market rates (BDT) — EDIT THESE ----------------
RATES = {
 "cement_bag_50kg":      545,   # PCC, delivered remote district
 "sand_m3":             1950,   # ~55 BDT/cft
 "aggregate_m3":        2400,
 "brick_chips_m3":      2600,
 "steel_8mm_kg":          98,   # MS rod @ ~98,000/t
 "steel_10mm_kg":         96,
 "steel_12mm_kg":         95,
 "weldmesh_m2":          135,
 "chickenwire_m2":        48,
 "GIwire_kg":            115,
 "waterproof_additive_kg": 260,
 "formwork_m2":          380,
 "brick_piece":           12,
 "pvc110_m":             330,
 "pvc75_m":              165,
 "pvc50_m":               95,
 "GIgutter06_m":         320,   # 0.45mm GI, 600mm girth, fabricated
 "gutter_bracket_no":     75,
 "GI_sheet_downpipe_m":  290,
 "HDPE_tank_5000":     58000,
 "ballvalve_50mm":       720,
 "bibcock_brass":        380,
 "floatvalve":           650,
 "leafscreen_no":        420,
 "gravel_m3":           3200,
 "filter_sand_m3":      2800,
 "charc_kg":              95,
 "candle_filter_set":   1350,
 "calhypo_kg":           185,   # 65% granular
 "chlorine_testkit":    2200,
 "hatch_lid_RCC":       1650,
 "manhole_cover":        950,
 "tapstand_set":        2400,
 "soakpit_ring":         620,
 "paint_epoxy_l":        620,
 "signage_no":           450,
 "pipe_fittings_ls":     900,
 "mason_day":           1050,
 "helper_day":           720,
 "welder_day":          1250,
 "plumber_day":         1100,
 "supervision_day":      900,
 "transport_ls":        3800,
 "testkit_pH_Cl":       2800,
 "training_hh":          600,
}

def bags(vol_m3_per_bag): return vol_m3_per_bag

# ---------------- Ferrocement cylindrical tank ----------------
def ferro_tank(V_l, D, t_wall=25, t_base=100, t_cover=65):
    A = math.pi*(D/2)**2
    h = (V_l/1000.0)/A
    wall_area = math.pi*D*h
    mortar_vol = wall_area*(t_wall/1000.0) + A*(t_cover/1000.0)
    # 1:2 mortar -> 12.8 bags cement + 0.887 m3 sand per m3
    cement  = mortar_vol*12.8 + 0.6        # +0.6 bag for joint/repair
    sand    = mortar_vol*0.887
    # base slab 1:2:4
    base_vol = A*(t_base/1000.0)
    cement  += base_vol*6.4
    sand    += base_vol*0.47
    agg      = base_vol*0.94
    # armature
    n_vert = math.ceil(math.pi*D/0.15)
    vert_len = n_vert*(h+0.35)
    n_ring = math.ceil(h/0.20)+1
    ring_len = n_ring*math.pi*D
    base_mesh_len = 0.6*(D/0.15+1)*D
    steel_len = vert_len + ring_len + base_mesh_len
    steel_kg = steel_len*0.395*1.12
    mesh_m2  = (wall_area*1.6 + A*1.3)
    return dict(V=V_l, D=D, h=round(h,2), wall_area=round(wall_area,2),
        cement_bag=round(cement,1), sand_m3=round(sand,2), aggregate_m3=round(agg,2),
        steel8_kg=round(steel_kg,1), mesh_m2=round(mesh_m2,1),
        GIwire_kg=round(mesh_m2*0.12+3,1), formwork_m2=round(wall_area*0.4,1),
        additive_kg=round(cement*0.3,1), cover_area=round(A,2))

def rcc_tank(V_l, D, tw=200, tb=250, tcover=150):
    A=math.pi*(D/2)**2; h=(V_l/1000.0)/A
    wall_area=math.pi*D*h
    conc = wall_area*(tw/1000.0) + A*(tb/1000.0) + A*(tcover/1000.0)
    cement = conc*7.0; sand=conc*0.45; agg=conc*0.90
    steel_kg = conc*95          # RCC, seismic+water retaining
    formwork = wall_area*2.2 + A*1.2
    return dict(V=V_l, D=D, h=round(h,2), wall_area=round(wall_area,2),
        cement_bag=round(cement,1), sand_m3=round(sand,2), aggregate_m3=round(agg,2),
        steel_kg=round(steel_kg,1), formwork_m2=round(formwork,1),
        waterproof_kg=round(conc*0.8,1), cover_area=round(A,2))

def cost_of(q, kind="ferro"):
    r=RATES
    s=0
    s+=q["cement_bag"]*r["cement_bag_50kg"]
    s+=q["sand_m3"]*r["sand_m3"]
    s+=q["aggregate_m3"]*r["aggregate_m3"]
    if kind=="ferro":
        s+=q["steel8_kg"]*r["steel_8mm_kg"]; s+=q["mesh_m2"]*r["chickenwire_m2"]
        s+=q["GIwire_kg"]*r["GIwire_kg"]; s+=q["formwork_m2"]*r["formwork_m2"]
        s+=q["additive_kg"]*r["waterproof_additive_kg"]
    else:
        s+=q["steel_kg"]*r["steel_10mm_kg"]; s+=q["formwork_m2"]*r["formwork_m2"]
        s+=q["waterproof_kg"]*r["waterproof_additive_kg"]
    return round(s)

if __name__=="__main__":
    for V,D in [(5000,1.80),(30000,3.90)]:
        q=ferro_tank(V,D,t_wall=25 if V<10000 else 32)
        print(f"FERRO {V} L D={D}m -> h={q['h']}m  cement {q['cement_bag']} bags, sand {q['sand_m3']} m3, "
              f"agg {q['aggregate_m3']} m3, steel {q['steel8_kg']} kg, mesh {q['mesh_m2']} m2, cost {cost_of(q):,} BDT")
    q=rcc_tank(60000,5.60)
    print(f"RCC 60000 L D=5.6 -> h={q['h']}m cement {q['cement_bag']} bags, steel {q['steel_kg']} kg, "
          f"conc {round(q['cement_bag']/7,1)} m3, cost {cost_of(q,'rcc'):,} BDT")
