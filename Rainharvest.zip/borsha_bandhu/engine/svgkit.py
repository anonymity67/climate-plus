"""Minimal engineering drafting kit -> SVG. Millimetre-accurate via a px/metre scale."""
import math, html

INK="#1a1a1a"; DIM="#0b5fa5"; ACC="#b3261e"; NAVY="#1F3A5F"; HID="#8a8a8a"; FILL_W="#e8f1f8"; FILL_C="#dcdcdc"
FILL_G="#cfe3d4"; FILL_B="#f3e2c7"; RED="#b3261e"; GREEN="#1e6b4f"

class DWG:
    def __init__(self, w, h, scale_px_per_m=200, title="", no="", sheet="A3"):
        self.w, self.h, self.s = w, h, scale_px_per_m
        self.b=[]; self.title=title; self.no=no; self.sheet=sheet
    def m(self, x): return x*self.s
    def add(self,s): self.b.append(s)
    # ---------- primitives ----------
    def line(self,x1,y1,x2,y2,w=1.4,c=INK,dash=None,cap="butt"):
        d=f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{c}" stroke-width="{w}" stroke-linecap="{cap}"{d}/>')
    def rect(self,x,y,w,h,fill="none",c=INK,sw=1.4,rx=0,dash=None):
        d=f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" stroke="{c}" stroke-width="{sw}"{d}/>')
    def circle(self,cx,cy,r,fill="none",c=INK,sw=1.4,dash=None):
        d=f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" stroke="{c}" stroke-width="{sw}"{d}/>')
    def poly(self,pts,fill="none",c=INK,sw=1.4):
        p=" ".join(f"{a:.1f},{b:.1f}" for a,b in pts)
        self.add(f'<polyline points="{p}" fill="{fill}" stroke="{c}" stroke-width="{sw}" stroke-linejoin="round"/>')
    def path(self,d,fill="none",c=INK,sw=1.4):
        self.add(f'<path d="{d}" fill="{fill}" stroke="{c}" stroke-width="{sw}"/>')
    def text(self,x,y,t,size=13,c=INK,anchor="start",bold=False,rot=0,italic=False):
        fw="700" if bold else "400"; fs="italic" if italic else "normal"
        tr=f' transform="rotate({rot} {x:.1f} {y:.1f})"' if rot else ""
        self.add(f'<text x="{x:.1f}" y="{y:.1f}" font-family="DejaVu Sans, Arial, sans-serif" font-size="{size}" '
                 f'fill="{c}" text-anchor="{anchor}" font-weight="{fw}" font-style="{fs}"{tr}>{html.escape(str(t))}</text>')
    # ---------- hatching ----------
    def hatch(self,x,y,w,h,kind="brick",c=INK,sw=0.8):
        pat={"brick":"url(#hbrick)","conc":"url(#hconc)","soil":"url(#hsoil)","water":"url(#hwater)",
             "gravel":"url(#hgravel)","sand":"url(#hsand)"}.get(kind,kind)
        self.rect(x,y,w,h,fill=pat,c="none",sw=0)
        self.rect(x,y,w,h,fill="none",c=c,sw=sw)
    # ---------- dimensions ----------
    def dimh(self,x1,x2,y,label,off=0,c=DIM,size=11):
        self.line(x1,y,x2,y,0.8,c)
        for x in (x1,x2):
            self.line(x,y-5,x,y+5,0.8,c)
            self.add(f'<polygon points="{x},{y} {x+(6 if x==x1 else -6)},{y-3.5} {x+(6 if x==x1 else -6)},{y+3.5}" fill="{c}"/>')
        self.line(x1,y+off*0,x1,y-0.0,0.4,c)
        if label: self.text((x1+x2)/2,y-6,label,size,c,"middle")
    def dimv(self,y1,y2,x,label,size=11,c=DIM):
        self.line(x,y1,x,y2,0.8,c)
        for y in (y1,y2):
            self.line(x-5,y,x+5,y,0.8,c)
            self.add(f'<polygon points="{x},{y} {x-3.5},{y+(6 if y==y1 else -6)} {x+3.5},{y+(6 if y==y1 else -6)}" fill="{c}"/>')
        if label: self.text(x-8,(y1+y2)/2,label,size,c,"middle",rot=-90)
    def leader(self,x1,y1,x2,y2,label,size=11,anchor="start",c=INK):
        self.line(x1,y1,x2,y2,0.8,c)
        self.circle(x1,y1,2.6,fill=c,c=c,sw=0)
        self.text(x2+(4 if anchor=="start" else -4),y2-3,label,size,c,anchor)
    def tag(self,x,y,t,size=10,fill="#ffffff"):
        w=len(t)*size*0.56+10
        self.rect(x,y-10,w,16,fill=fill,c=INK,sw=0.8,rx=2)
        self.text(x+5,y+2,t,size,INK)
    # ---------- frame ----------
    def frame(self, proj="BORSHA-BANDHU INTEGRATED RWH SYSTEM", disc="DISCIPLINE: CIVIL / PUBLIC HEALTH ENGINEERING"):
        m=18
        self.rect(m,m,self.w-2*m,self.h-2*m,fill="none",c=INK,sw=2)
        self.rect(m+5,m+5,self.w-2*m-10,self.h-2*m-10,fill="none",c=INK,sw=0.7)
        # title block bottom-right
        tw,th=430,96
        x0,y0=self.w-m-tw,self.h-m-th
        self.rect(x0,y0,tw,th,fill="#ffffff",c=INK,sw=1.6)
        self.line(x0,y0+34,x0+tw,y0+34,1)
        self.line(x0,y0+64,x0+tw,y0+64,0.8)
        self.line(x0+250,y0+34,x0+250,y0+th,0.8)
        self.text(x0+10,y0+23,self.title[:52],13,INK,bold=True)
        self.text(x0+10,y0+52,proj,9,HID)
        self.text(x0+10,y0+82,disc,8.5,HID)
        self.text(x0+258,y0+52,"DWG No.",8.5,HID)
        self.text(x0+258,y0+78,self.no,13,RED,bold=True)
        self.text(x0+tw-8,y0+52,self.sheet,9,HID,"end")
        self.text(x0+tw-8,y0+78,"SCALE: AS NOTED",8.5,HID,"end")
    def render(self):
        defs=f'''<defs>
<pattern id="hbrick" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#f0e6d8"/><path d="M0,12 L12,0 M-3,3 L3,-3 M9,15 L15,9" stroke="#b08d63" stroke-width="1"/></pattern>
<pattern id="hconc" width="9" height="9" patternUnits="userSpaceOnUse"><rect width="9" height="9" fill="#e4e4e4"/><circle cx="3" cy="3" r="1" fill="#999"/><circle cx="7" cy="7" r="1.1" fill="#888"/></pattern>
<pattern id="hsoil" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="#efe7d8"/><path d="M0,14 L14,0 M-4,4 L4,-4 M10,18 L18,10" stroke="#a08f6f" stroke-width="1.1"/></pattern>
<pattern id="hwater" width="16" height="10" patternUnits="userSpaceOnUse"><rect width="16" height="10" fill="#dceaf5"/><path d="M0,6 q4,-4 8,0 t8,0" stroke="#5b8fc0" stroke-width="1.2" fill="none"/></pattern>
<pattern id="hgravel" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#e8e2d5"/><circle cx="3" cy="4" r="2.1" fill="#b9ae97"/><circle cx="9" cy="9" r="2.4" fill="#c2b8a2"/><circle cx="9" cy="3" r="1.6" fill="#b0a58e"/></pattern>
<pattern id="hsand" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="#f2ecdd"/><circle cx="2" cy="2" r="0.9" fill="#c3b391"/><circle cx="6" cy="6" r="0.9" fill="#cdbd9b"/><circle cx="8" cy="3" r="0.8" fill="#bfae8b"/></pattern>
<marker id="arw" markerWidth="10" markerHeight="10" refX="6" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 z" fill="{INK}"/></marker>
</defs>'''
        self.frame()
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">'
                f'<rect width="{self.w}" height="{self.h}" fill="#ffffff"/>{defs}'+"".join(self.b)+'</svg>')
    def save(self,path):
        open(path,"w").write(self.render()); return path

def arrow(d,x1,y1,x2,y2,c=INK,sw=1.6):
    d.add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{c}" stroke-width="{sw}" marker-end="url(#arw)"/>')

def BENGALI_NOTE():
    return "বাংলা নির্দেশনা সংযুক্ত"
