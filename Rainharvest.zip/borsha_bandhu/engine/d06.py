from svgkit import *
def draw(path):
    d=DWG(1500,920,100,title="D-06  ZONE ADAPTATIONS",no="BB-D-06")
    d.text(40,50,"ZONE ADAPTATIONS  —  ONE DESIGN FAMILY, THREE HAZARD PROFILES",20,INK,bold=True)
    d.text(40,72,"The tank does not change. What changes is where it sits, what it is sealed with, and what the overflow is for.",11,HID)

    cols=[("A — COASTAL BELT","Zones A & B · Khulna, Satkhira, Cox's Bazar","Cyclone wind · storm surge · salinity intrusion",
           ["Tank sealed and anchored: 4 × M16 SS anchors, tie-down straps over the cover.",
            "All fixings stainless 304. Galvanised steel corrodes to failure in 3–4 years in salt air.",
            "Epoxy lining mandatory: protects stored water from chloride ingress through micro-cracks.",
            "Plinth raised 300 mm above surrounding ground; site on the highest point of the homestead.",
            "MAR recharge pit is not optional here. It holds back the freshwater lens that salinity is eating.",
            "Emergency reserve valve: 14 days of drinking water sealed in the tank before landfall."],"#e8f1f8"),
          ("B — FLOOD PLAIN & HAOR","Zone C · Kurigram, Gaibandha, Sirajganj, Sunamganj","Annual monsoon inundation · flash flood",
           ["Tank on a raised plinth to at least 0.5 m above the recorded 100-year flood level, from the BWDB gauge.",
            "Anti-buoyancy: an empty tank in 1 m of floodwater has an uplift 2.5× its own weight. It will float and tip.",
            "If it cannot be raised, anchor to a mass concrete base of at least 1.5× the uplift force.",
            "Backwater flap valve on the overflow so flood water cannot enter the tank.",
            "Pre-flood protocol: fill the tank before the crest arrives. A full tank is an emergency water point.",
            "Keep the draw-off and tapstand 600 mm above the 100-year flood level so it stays reachable."],"#fdf2f0"),
          ("C — BARIND & CHAR","Zone D · Rajshahi, Chapainawabganj, Naogaon, char lands","Drought · low rainfall · arsenic in groundwater",
           ["Rainfall here is 1,157 mm in a dry year. Roof area is the binding constraint — extend the catchment.",
            "30 m² minimum catchment, not 20 m². Use a lean-to extension or a separate sheet catchment if needed.",
            "Tank sized at 5,000 L even though the roof rarely fills it: the constraint is the dry season, not the monsoon.",
            "MAR recharge is the primary benefit in a drought year — it keeps the shallow aquifer alive.",
            "RWH is the arsenic-free source. Never blend with tubewell water that has not been tested.",
            "Two tanks in series where the household can afford it: decanting lets sediment settle in the first."],"#eef7ee")]

    for i,(t,sub,haz,points,fillc) in enumerate(cols):
        x=40+i*476; y=110
        d.rect(x,y,468,600,fill="#ffffff",c=INK,sw=1.6,rx=4)
        d.rect(x,y,468,92,fill=fillc,c=INK,sw=1.6,rx=4)
        d.rect(x,y+80,468,12,fill=fillc,c="none",sw=0)
        d.text(x+18,y+30,t,14,RED,bold=True)
        d.text(x+18,y+52,sub,8.8,INK)
        d.text(x+18,y+74,haz,8.8,ACC,bold=True)
        yy=y+118
        for j,p in enumerate(points):
            d.circle(x+26,yy-4,9,fill=RED if i==1 else GREEN,c="none",sw=1.4)
            d.text(x+26,yy,str(j+1),8.5,RED if i==1 else GREEN,"middle",bold=True)
            # wrap
            words=p.split(); line=""; ln=0
            for w in words:
                if len(line)+len(w)>56:
                    d.text(x+44,yy+ln*12,line,8.4,INK); line=w; ln+=1
                else: line=(line+" "+w).strip()
            d.text(x+44,yy+ln*12,line,8.4,INK)
            yy+=28+ln*12

        # small sketch
        sy=y+376
        d.rect(x+18,sy,432,180,fill="#fbfbfb",c=HID,sw=1)
        if i==0:
            d.line(x+30,sy+150,x+440,sy+150,1.6,INK)
            d.hatch(x+30,sy+150,410,20,"water")
            d.rect(x+150,sy+70,110,80,fill=FILL_W,c=INK,sw=1.6)
            d.text(x+205,sy+115,"TANK",9,HID,"middle",bold=True)
            d.rect(x+140,sy+150,130,26,fill="url(#hbrick)",c=INK,sw=1.2)
            for xx in (x+165,x+205,x+245):
                d.line(xx,sy+70,xx,sy+52,2,RED); d.circle(xx,sy+50,3,fill=RED,c=RED,sw=0)
            d.text(x+205,sy+46,"M16 SS anchors + straps",7.8,RED,"middle")
            d.text(x+300,sy+60,"storm surge level",8,HID)
            d.text(x+205,sy+186,"Plinth on high ground, sealed cover, tied down",8.2,GREEN,"middle")
        elif i==1:
            d.line(x+30,sy+95,x+440,sy+95,1.2,"#5b8fc0",dash="6 3")
            d.text(x+300,sy+88,"100-yr flood level",7.8,"#5b8fc0")
            d.hatch(x+30,sy+150,410,20,"water")
            d.rect(x+150,sy+62,110,68,fill=FILL_W,c=INK,sw=1.6)
            d.rect(x+140,sy+130,130,20,fill="url(#hbrick)",c=INK,sw=1.2)
            d.text(x+205,sy+100,"TANK",9,HID,"middle",bold=True)
            d.line(x+120,sy+150,x+120,sy+176,1.6,INK)
            d.line(x+290,sy+150,x+290,sy+176,1.6,INK)
            d.line(x+100,sy+176,x+310,sy+176,2.4,INK)
            d.text(x+205,sy+196,"mass concrete anchor if the plinth cannot be raised",7.8,RED,"middle")
            d.arrow if False else None
            arrow(d,x+205,sy+56,x+205,sy+34,sw=1.4,c=RED)
            d.text(x+205,sy+28,"uplift on empty tank",7.8,RED,"middle")
        else:
            d.rect(x+40,sy+120,150,40,fill="#f0eadb",c=INK,sw=1.2)
            d.text(x+115,sy+144,"EXTENDED CATCHMENT 30 m²",7.6,INK,"middle")
            d.rect(x+220,sy+70,100,90,fill=FILL_W,c=INK,sw=1.6)
            d.text(x+270,sy+120,"TANK",9,HID,"middle",bold=True)
            d.rect(x+220,sy+160,100,24,fill="url(#hsoil)",c=INK,sw=1.2)
            arrow(d,x+192,sy+120,x+216,sy+120,sw=1.4)
            d.rect(x+340,sy+130,70,50,fill="url(#hgravel)",c=INK,sw=1.2)
            d.text(x+375,sy+192,"MAR pit",7.8,GREEN,"middle")
            arrow(d,x+322,sy+178,x+352,sy+160,sw=1.4,c=GREEN)
            d.text(x+250,sy+30,"Roof is the constraint, not the tank",8,GREEN,"middle")

    d.text(40,752,"Deployment rule:  one standard design, three site adaptations. Never deploy the coastal anchorage detail in the Barind (wasted cost), and never deploy the Barind 20 m² catchment in Satkhira (it will not fill).",9,GREEN,bold=True)
    return d.save(path)
if __name__=="__main__": print(draw("/home/user/borsha_bandhu/drawings/D-06_zone_adaptations.svg"))
