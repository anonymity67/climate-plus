from docx import Document
from docx.shared import Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY=RGBColor(0x1F,0x3A,0x5F); TEAL=RGBColor(0x0E,0x7C,0x7B); RED=RGBColor(0xB3,0x26,0x1E)
GREY=RGBColor(0x59,0x59,0x59); GREEN=RGBColor(0x1E,0x6B,0x4F); BLACK=RGBColor(0x1a,0x1a,0x1a)

def shade(cell,hexcolor):
    tcPr=cell._tc.get_or_add_tcPr(); sh=OxmlElement('w:shd')
    sh.set(qn('w:val'),'clear'); sh.set(qn('w:color'),'auto'); sh.set(qn('w:fill'),hexcolor)
    tcPr.append(sh)

def set_cell_margins(table,tw=60,th=40):
    for row in table.rows:
        for cell in row.cells:
            tcPr=cell._tc.get_or_add_tcPr()
            mar=OxmlElement('w:tcMar')
            for k,v in (('top',th),('bottom',th),('left',tw),('right',tw)):
                e=OxmlElement(f'w:{k}'); e.set(qn('w:w'),str(v)); e.set(qn('w:type'),'dxa'); mar.append(e)
            tcPr.append(mar)

def rule(doc,color="1F3A5F",size=8):
    p=doc.add_paragraph(); pPr=p._p.get_or_add_pPr()
    b=OxmlElement('w:pBdr'); bo=OxmlElement('w:bottom')
    bo.set(qn('w:val'),'single'); bo.set(qn('w:sz'),str(size)); bo.set(qn('w:color'),color)
    bo.set(qn('w:space'),'1'); b.append(bo); pPr.append(b)
    p.paragraph_format.space_after=Pt(6); return p

class Doc:
    def __init__(self, title, subtitle, meta, landscape=False):
        self.d=Document()
        s=self.d.sections[0]
        if landscape:
            s.orientation=1; s.page_width, s.page_height = Cm(29.7), Cm(21.0)
        else:
            s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.left_margin=s.right_margin=Cm(2.0); s.top_margin=Cm(2.0); s.bottom_margin=Cm(1.9)
        st=self.d.styles['Normal']; st.font.name='Calibri'; st.font.size=Pt(10.5); st.font.color.rgb=BLACK
        st.paragraph_format.space_after=Pt(6); st.paragraph_format.line_spacing=1.12
        for h,sz,col in [('Heading 1',16,NAVY),('Heading 2',13,TEAL),('Heading 3',11.5,NAVY)]:
            hs=self.d.styles[h]; hs.font.name='Calibri'; hs.font.size=Pt(sz); hs.font.bold=True
            hs.font.color.rgb=col; hs.paragraph_format.space_before=Pt(14 if h=='Heading 1' else 10)
            hs.paragraph_format.space_after=Pt(5)
        self.title=title; self.subtitle=subtitle; self.meta=meta
        self._footer()
    def _footer(self):
        for s in self.d.sections:
            p=s.footer.paragraphs[0]; p.text=""
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            r=p.add_run("BORSHA-BANDHU Integrated Rainwater Harvesting System  ·  Bangladesh  ·  page ")
            r.font.size=Pt(7.5); r.font.color.rgb=GREY
            fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE')
            rr=OxmlElement('w:r'); rPr=OxmlElement('w:rPr'); sz=OxmlElement('w:sz'); sz.set(qn('w:val'),'15')
            rPr.append(sz); rr.append(rPr); t=OxmlElement('w:t'); t.text="1"; rr.append(t); fld.append(rr)
            p._p.append(fld)
    def cover(self, code, blurb, stats=None):
        d=self.d
        for _ in range(3): d.add_paragraph()
        p=d.add_paragraph(); r=p.add_run("BORSHA-BANDHU"); r.font.size=Pt(11); r.font.bold=True
        r.font.color.rgb=TEAL; p.paragraph_format.space_after=Pt(2)
        p=d.add_paragraph(); r=p.add_run(self.title); r.font.size=Pt(30); r.font.bold=True
        r.font.color.rgb=NAVY; p.paragraph_format.space_after=Pt(6)
        p=d.add_paragraph(); r=p.add_run(self.subtitle); r.font.size=Pt(13.5); r.font.color.rgb=GREY
        p.paragraph_format.space_after=Pt(18)
        rule(d)
        p=d.add_paragraph(); r=p.add_run(blurb); r.font.size=Pt(11); r.font.color.rgb=BLACK
        p.paragraph_format.space_after=Pt(16)
        if stats:
            t=d.add_table(rows=1,cols=len(stats)); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER
            for i,(v,l) in enumerate(stats):
                c=t.cell(0,i); c.text=""
                pa=c.paragraphs[0]; pa.alignment=WD_ALIGN_PARAGRAPH.CENTER
                r=pa.add_run(v); r.font.size=Pt(17); r.font.bold=True; r.font.color.rgb=NAVY
                pb=c.add_paragraph(); pb.alignment=WD_ALIGN_PARAGRAPH.CENTER
                r=pb.add_run(l); r.font.size=Pt(8); r.font.color.rgb=GREY
                shade(c,"EAF1F6")
            set_cell_margins(t,80,70)
        d.add_paragraph()
        for k,v in self.meta:
            p=d.add_paragraph(); p.paragraph_format.space_after=Pt(1)
            r=p.add_run(f"{k}:  "); r.font.size=Pt(8.5); r.font.bold=True; r.font.color.rgb=NAVY
            r=p.add_run(v); r.font.size=Pt(8.5); r.font.color.rgb=GREY
        d.add_page_break()
    def h1(self,t): self.d.add_heading(t,1)
    def h2(self,t): self.d.add_heading(t,2)
    def h3(self,t): self.d.add_heading(t,3)
    def p(self,t,size=10.5,bold=False,italic=False,color=None,after=6,before=0):
        par=self.d.add_paragraph(); r=par.add_run(t)
        r.font.size=Pt(size); r.font.bold=bold; r.font.italic=italic
        if color: r.font.color.rgb=color
        par.paragraph_format.space_after=Pt(after); par.paragraph_format.space_before=Pt(before)
        return par
    def lead(self,t): 
        par=self.d.add_paragraph(); r=par.add_run(t); r.font.size=Pt(12); r.font.color.rgb=GREY
        r.font.italic=True; par.paragraph_format.space_after=Pt(9); return par
    def bullets(self,items,style='List Bullet'):
        for it in items:
            if isinstance(it,tuple):
                par=self.d.add_paragraph(style=style)
                r=par.add_run(it[0]); r.font.bold=True; r.font.size=Pt(10.3)
                r2=par.add_run("  "+it[1]); r2.font.size=Pt(10.3)
            else:
                par=self.d.add_paragraph(it,style=style)
                for r in par.runs: r.font.size=Pt(10.3)
            par.paragraph_format.space_after=Pt(2)
    def numbered(self,items):
        for i,it in enumerate(items,1):
            par=self.d.add_paragraph()
            r=par.add_run(f"{i}.  "); r.font.bold=True; r.font.color.rgb=TEAL; r.font.size=Pt(10.3)
            r=par.add_run(it); r.font.size=Pt(10.3)
            par.paragraph_format.left_indent=Cm(0.6); par.paragraph_format.first_line_indent=Cm(-0.6)
            par.paragraph_format.space_after=Pt(3)
    def table(self,headers,rows,widths=None,fontsize=8.8,headercolor="1F3A5F",zebra=True,align=None):
        t=self.d.add_table(rows=1,cols=len(headers)); t.style='Table Grid'
        t.alignment=WD_TABLE_ALIGNMENT.CENTER
        hdr=t.rows[0].cells
        for i,h in enumerate(headers):
            hdr[i].text=""
            par=hdr[i].paragraphs[0]; par.alignment=WD_ALIGN_PARAGRAPH.CENTER
            r=par.add_run(str(h)); r.font.bold=True; r.font.size=Pt(fontsize); r.font.color.rgb=RGBColor(0xFF,0xFF,0xFF)
            shade(hdr[i],headercolor)
        for ri,row in enumerate(rows):
            cells=t.add_row().cells
            for i,v in enumerate(row):
                cells[i].text=""
                par=cells[i].paragraphs[0]
                if align and i in align: par.alignment=align[i]
                r=par.add_run(str(v)); r.font.size=Pt(fontsize)
                if zebra and ri%2==1: shade(cells[i],"F2F6F9")
        set_cell_margins(t)
        if widths:
            tot=sum(widths); avail=17.0
            if tot>avail: widths=[w*avail/tot for w in widths]
            t.autofit=False
            for row in t.rows:
                for i,w in enumerate(widths):
                    row.cells[i].width=Cm(w)
        self.d.add_paragraph().paragraph_format.space_after=Pt(2)
        return t
    def callout(self,title,body,color="FFF8E1"):
        t=self.d.add_table(rows=1,cols=1); t.style='Table Grid'
        c=t.rows[0].cells[0]; c.text=""
        par=c.paragraphs[0]; r=par.add_run(title); r.font.bold=True; r.font.size=Pt(10); r.font.color.rgb=RED
        par2=c.add_paragraph(); r=par2.add_run(body); r.font.size=Pt(9.6)
        shade(c,color); set_cell_margins(t,110,80)
        self.d.add_paragraph().paragraph_format.space_after=Pt(2)
    def kv(self,pairs,w1=5.0,w2=11.5):
        t=self.d.add_table(rows=0,cols=2); t.style='Table Grid'
        for k,v in pairs:
            row=t.add_row().cells
            row[0].text=""; r=row[0].paragraphs[0].add_run(k); r.font.bold=True; r.font.size=Pt(9)
            shade(row[0],"EAF1F6")
            row[1].text=""; r=row[1].paragraphs[0].add_run(v); r.font.size=Pt(9)
            row[0].width=Cm(w1); row[1].width=Cm(w2)
        set_cell_margins(t,80,50)
        self.d.add_paragraph().paragraph_format.space_after=Pt(2)
    def pagebreak(self): self.d.add_page_break()
    def save(self,path): self.d.save(path); return path
