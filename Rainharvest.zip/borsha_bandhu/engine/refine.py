from rwh_model import *
def rd(z): return [r*DESIGN_FACTOR for r in ZONES[z]["m"]]

print("="*100)
print("T2 CLUSTER - 60 persons @ 5 lpcd = 300 L/d, catchment 160 m2")
print("="*100)
for v in [20000,25000,30000,35000,40000]:
    cells=[]
    for z in ZONES:
        s=simulate(rd(z),160,v,300)
        cells.append(f"{s['rel']*100:3.0f}/{s['dry_days_covered']:3.0f}")
    print(f"{v:>7d} L  " + "  ".join(f"Z-{z}:{c}" for z,c in zip(ZONES,cells)) + "   (annual% / dry-days of 243)")

print()
print("="*100)
print("T3 INSTITUTION - 400 users, normal demand 1000 L/d, catchments 300/450/600 m2")
print("="*100)
for a in [300,450,600]:
    print(f"\n-- catchment {a} m2 --   (annual% / dry-days of 243 / emergency days at 3000 L/d from full tank)")
    for v in [30000,40000,50000,60000]:
        cells=[]
        for z in ZONES:
            s=simulate(rd(z),a,v,1000)
            cells.append(f"{s['rel']*100:3.0f}/{s['dry_days_covered']:3.0f}/{v/3000:4.0f}")
        print(f"{v:>7d} L  " + "  ".join(f"Z-{z}:{c}" for z,c in zip(ZONES,cells)))

print()
print("="*100); print("SUPPLY / DEMAND ratios for T3"); print("="*100)
for a in [300,450,600]:
    print(f"{a:>5d} m2 : " + "  ".join(f"Z-{z} {supply_ratio(rd(z),a,1000):4.2f}" for z in ZONES))

print()
print("="*100)
print("T1 - the 'standard' 2000 L tank vs our 5000 L, 20 m2, 6 persons @5 lpcd")
print("="*100)
for v in [2000,3000,4000,5000]:
    print(f"-- {v} L --")
    for z in ZONES:
        s=simulate(rd(z),20,v,30)
        print(f"   Z-{z} {ZONES[z]['name'][:26]:28s} annual {s['rel']*100:5.1f}%  dry {s['dry_rel']*100:5.1f}%  days {s['dry_days_covered']:3.0f}/243  spill {s['spill']:6.0f} L")

print()
print("="*100); print("SURPLUS AVAILABLE FOR MAR RECHARGE (spill beyond tank)"); print("="*100)
for tag,a,v,dmd in [("T1",20,5000,30),("T2",160,30000,300),("T3",600,60000,1000)]:
    print(f"{tag}: " + "  ".join(f"Z-{z} {simulate(rd(z),a,v,dmd)['spill']/1000:5.1f} m3" for z in ZONES))
