import json
from docx.shared import Pt, Cm
from docxkit import *
B=json.load(open("bom.json"))
f=lambda n: f"{n:,.0f}"

d=Doc("Programme Implementation & DRR Guide",
      "Deploying the system at scale",
      [("Document","BB-PIG-03  ·  Revision A  ·  20 November 2026"),
       ("Audience","Programme managers, WASH officers, DRR coordinators, implementing partners"),
       ("Covers","Targeting, mobilisation, delivery modality, training, M&E, finance, risk and exit"),
       ("Companion documents","Technical Design Manual (BB-TDM-01); Construction & O&M Manual (BB-COM-02); Costing & Sizing Model (XLSX)")])
d.cover("BB-PIG-03",
 "Engineering is the easy part. Most rainwater harvesting programmes in Bangladesh fail not because the tank was built badly but because "
 "the wrong household got it, nobody agreed who maintains it, the chlorine ran out in the second year, and the tank was abandoned by the "
 "third. This guide is about the programme architecture that makes the engineering survive contact with a real community over twenty years.",
 [("3","delivery modalities"),("4","training sessions"),("18","M&E indicators"),("20 yr","design life to protect")])

# 1. LOGIC
d.h1("1.  Programme logic")
d.p("The results chain below is intentionally short. Every link is something the programme controls directly, and every assumption "
    "is something it must verify rather than hope for.")
d.table(["Level","Statement","Assumption that must hold"],
 [["Impact","Reduced waterborne disease and reduced distress migration in water-scarce, disaster-prone communities","Other WASH inputs (sanitation, hygiene promotion) continue; health system reporting is reliable"],
  ["Outcome 2","Households and institutions have continuous safe water through the dry season and through a disaster","The managed secondary source remains functional in the months the tank is empty"],
  ["Outcome 1","Households and institutions use harvested rainwater as their primary drinking and cooking source","Water quality is verified and trusted; the queue rules are accepted"],
  ["Output 3","Systems remain functional at 5 years","O&M fund is real, chlorine supply chain exists, a local mason is available"],
  ["Output 2","Water quality meets ECR'97 at the point of use","Caretakers test and dose; the laboratory testing schedule is funded"],
  ["Output 1","Units built to specification with community agreement in place","Masons trained; QC hold points enforced; agreement signed before construction"],
  ["Input","Site engineers, mason teams, materials, community time","Procurement is timely and material quality checks are actually applied"]],
 widths=[2.0,7.6,7.4],fontsize=8.3)
d.h2("1.1  The assumption that most often fails")
d.p("Output 1 → Outcome 1 rests on households trusting the water. Programmes routinely install an excellent tank and then discover "
    "that families still drink tubewell water because the tank water 'looks flat' or 'tastes of nothing', or because the potable point "
    "is locked at the hour they need it. Trust is built by visible testing — a chlorine and bacteriological result posted on a board "
    "beside the tapstand, with the date — and by siting the tapstand where women actually collect water. Both are programme decisions, "
    "not engineering ones.")
d.pagebreak()

# 2. TARGETING
d.h1("2.  Targeting and beneficiary selection")
d.p("Selection is the point at which a technically sound programme becomes either pro-poor or merely pro-access. The scoring below is "
    "applied by a two-person team, one of whom must be a woman, and the results are read out at a community meeting so the list can be challenged.")
d.h2("2.1  Community eligibility")
d.p("A community is eligible where at least three of the following hold:")
d.bullets(["The shallow aquifer is saline, above the arsenic limit, or dry for more than four months a year.",
 "The union is classified as a cyclone or flood high-risk union in the national risk atlas, or has been declared disaster-affected in two of the last five years.",
 "Median distance to a functional safe water point exceeds 500 m, or collection time exceeds 30 minutes each way.",
 "The community is in the lowest two wealth quintiles by the local poverty map.",
 "A school, cyclone shelter or health post exists that can host a Tier 3 unit.",
 "There is no piped supply and none planned within the programme period."])
d.h2("2.2  Household scoring — rank and select, do not cherry-pick")
d.table(["Criterion","Score","Verification"],
 [["Female-headed household","3","Union Parishad record or community confirmation"],
  ["Household includes a person with a disability","3","Self-declaration, verified by the committee"],
  ["Household includes a pregnant woman or a child under 5","2","Community health worker record"],
  ["Landless or homestead on land owned by another (char, haor)","3","Community verification"],
  ["Currently drinking from a saline or arsenic-affected source","3","Field test kit: EC or arsenic"],
  ["Source is more than 500 m away or collection exceeds 30 min","2","Timed walk, disaggregated by sex"],
  ["Household was displaced by a disaster in the last three years","2","Union Parishad disaster register"],
  ["Roof is suitable and household controls it","Gate","Roof inspection (see BB-COM-02 §1.1). Score of 0 excludes the household"],
  ["No prior RWH system in the household","Gate","Register check"]],
 widths=[7.2,1.6,8.2],fontsize=8.4)
d.p("The two gate criteria are pass/fail rather than scored. A household whose roof cannot be used is not a lower-priority household; "
    "it is a household for whom this intervention does not work, and it should be referred to a different water intervention rather "
    "than built a tank that will never fill.",size=9.6,italic=True)
d.h2("2.3  Quotas")
d.table(["Group","Minimum share of household units","Rationale"],
 [["Female-headed households","30%","They carry the water burden and are least able to pay a contractor"],
  ["Households with a member with a disability","15%","Tapstand height and apron design are adjusted for wheelchair and seated access"],
  ["Extremely poor (lowest wealth quintile)","50%","The intervention is a poverty intervention before it is a water intervention"],
  ["Women in WASH committee positions","50% of seats, and the chair or treasurer role","Decision-making, not representation"]],
 widths=[6.4,4.6,6.0],fontsize=8.4)
d.pagebreak()

# 3. DELIVERY MODALITY
d.h1("3.  Delivery modality")
d.p("Three modalities, chosen by context. The choice has a large effect on unit cost, on ownership and on quality — and getting it "
    "wrong is the difference between a community asset and a contractor's invoice.")
d.table(["Modality","Best used where","Cost effect","Quality risk","Ownership effect"],
 [["Community-managed with a trained mason","Rural, cohesive community, T1 and T2. High social capital.","Lowest labour cost; 10–20% below contractor rates","Moderate — depends on supervision intensity","Highest — the community built it"],
  ["Cash-for-work / food-for-asset","Post-disaster recovery; seasonal unemployment; public works programmes","Labour cost is a transfer, not a loss; net programme cost similar","Moderate — requires the same QC hold points","High, if the asset is genuinely public"],
  ["Contractor-built","Institutional (T3), urban, tight timelines, or where no skilled labour exists locally","Highest — 15–25% above community rates including overheads","Lowest, if supervision is competent","Lowest — needs deliberate handover work"]],
 widths=[3.8,4.6,3.2,2.8,2.6],fontsize=8.2)
d.h2("3.1  What the community contributes, and what it does not")
d.p("Community contribution is a genuine ownership mechanism and an equity hazard at the same time. The rule: contribution is in "
    "labour and local materials, never in cash, and never in a way that excludes the poorest.")
d.bullets(["Unskilled labour (excavation, carting, backfilling) — 8 to 12 person-days per T1 unit, voluntary or cash-for-work.",
 "Local materials where quality can be verified — sand, brick chips, bricks. Never cement, mesh, pipe or chlorine.",
 "Land for the tank, agreed in writing.",
 "Not required: cash payment, skilled labour, or materials the household must buy."])
d.h2("3.2  Supervision ratios — non-negotiable")
d.table(["Tier","Site engineer visits","Inspection hold points","Approximate engineer days per unit"],
 [["T1","At HP1, HP2/3, HP4 minimum","4","0.5 day"],
  ["T2","Weekly during construction, plus all hold points","4","4 days"],
  ["T3","Full-time supervision during the shell and the treatment train","4 plus structural inspection","25 days"]],
 widths=[2.2,7.4,3.4,4.0],fontsize=8.4)
d.p("A programme that builds household units without an engineer at the hold points is not building a water supply; it is distributing "
    "concrete. The supervision cost is roughly 6–9% of T1 capital cost and is the highest-value line in the budget.",size=9.6,italic=True)

# 4. TRAINING
d.h1("4.  Training and local capacity")
d.p("Three tiers of training, each with a certified output. Training without a competency test is a workshop, not a capacity investment.")
d.table(["Training","Who","Duration","Certification"],
 [["Ferrocement mason","Local masons, 2 per union minimum","10 days, hands-on, building a real tank","Practical test: builds a 1 m trial shell that passes HP3 and a fill test"],
  ["Caretaker","2 per cluster or institution; 1 per 20 household units","2 days","Demonstrates dosing, chlorine test, diverter reset and pre-filter backwash unaided"],
  ["WASH committee","7 per cluster; SMC or shelter committee for T3","2 days + quarterly follow-up","Has produced a signed O&M plan, a tariff decision and a disaster trigger sheet"],
  ["Site engineer / technician","Programme staff and partner staff","3 days","Signs off two units under observation before working independently"],
  ["Union Parishad / DPHE counterpart","Local government","1 day orientation","Knows the asset register entry and the reporting line"]],
 widths=[3.6,4.4,3.4,5.6],fontsize=8.2)
d.callout("Train the mason before you buy the cement",
  "If the training happens after procurement, the first three tanks in every union will be built by someone learning on the job, and "
  "they will be the tanks that leak. Sequence the training in the work plan: mason training in month 1, first construction in month 2.")
d.pagebreak()

# 5. DRR
d.h1("5.  Disaster risk reduction integration")
d.p("In a disaster-prone country, a water supply that stops working in a disaster is not a water supply. DRR is therefore built into "
    "the asset and into the calendar, in four places.")
d.h2("5.1  Four places DRR lives in this system")
d.table(["Layer","What it is","Where it is specified"],
 [["Structural","Anchorage at 72 m/s gust; plinth above the 100-year flood level; anti-buoyancy; sealed cover that survives debris","Design Manual §6.2, §6.3; Drawing D-06"],
  ["Operational","Named triggers and a written sequence of actions before, during and after a cyclone or flood","Construction & O&M Manual §7; Drawing D-05 panel C"],
  ["Asset value in disaster","A sealed 60,000 L tank holds 30 days of drinking water for 400 people with no resupply","Design Manual §3, stage 9"],
  ["Early warning link","Programme coordinates with the FFWC and BMD warning chain so the 'fill the tank' action happens before, not during","This section, 5.2"]],
 widths=[3.2,7.6,6.2],fontsize=8.4)
d.h2("5.2  Early warning integration — the 48-hour window")
d.p("The single most valuable DRR action is also the cheapest: filling the tank in the 48 hours before a hazard arrives. This requires "
    "the programme to plug into the existing warning chain rather than invent a parallel one.")
d.table(["Trigger","Source","Message to the community","Action"],
 [["Cyclone: signal 3 hoisted","BMD / CPP volunteers","SMS and loudspeaker: 'Fill your tank now, then seal it'","Committee fills, seals the reserve valve, bolts covers, lashes taps"],
  ["Flood: river at danger level, forecast to rise","FFWC 5-day forecast","SMS to committee chair and UP member","Fill tank, close the flap valve, raise loose equipment"],
  ["Drought: tank 30 days ahead of seasonal norm","Caretaker log reviewed monthly","Committee meeting","Activate and verify the secondary source before the tank empties"],
  ["Earthquake","BMD / national alert","SMS","Inspect the tank base and cover before use"]],
 widths=[4.2,3.6,4.8,4.4],fontsize=8.2)
d.h2("5.3  Resilience indicators the programme should report")
d.bullets(["Percentage of units that remained functional through the last cyclone or flood season.",
 "Percentage of committees that completed the pre-hazard 'fill and seal' action when a trigger occurred.",
 "Median days from hazard to restored service.",
 "Percentage of units with an intact, sealed, lockable cover after the hazard season — the single best proxy for whether the hardware survived."])

# 6. M&E
d.h1("6.  Monitoring, evaluation and learning")
d.p("Eighteen indicators across six domains, with means of verification and frequency. The full indicator table is Sheet 12 of the "
    "costing model so that it can be filtered and reported directly. The six domains and the logic behind them:")
d.table(["Domain","What it tells you","The indicator that matters most"],
 [["Output 1 — infrastructure","Whether the hardware exists and was built properly","Percentage of units passing all four QC hold points at first inspection"],
  ["Output 2 — water safety","Whether the water is actually safe at the point of use","Percentage of samples with E. coli 0/100 mL"],
  ["Output 3 — use and behaviour","Whether people are using it correctly","Percentage of households drawing water through the tap, not by rope or bucket"],
  ["Output 4 — continuity","Whether the service is continuous through the dry season","Dry-season days of potable water supplied, against the design target"],
  ["Outcome 5 — wellbeing","Whether it made a difference to people's lives","Hours per week saved in water collection, disaggregated by sex"],
  ["Sustainability 6 — institutional","Whether it will still work in five years","Percentage of systems at 'basic' or 'safely managed' on the service ladder at 5 years"]],
 widths=[3.6,6.0,7.4],fontsize=8.3)
d.h2("6.1  The two indicators to build the whole M&E system around")
d.p("Most programmes measure too much and learn too little. Two indicators carry most of the information:")
d.numbered(["Dry-season days of potable water supplied. This is the outcome the tank exists to deliver. It is recorded daily by the "
 "caretaker in the log book, and it directly tests whether the storage sizing in this design was right for that site. A unit that "
 "empties in March in Zone A is telling you the catchment was smaller than measured, the roof leaked, or the household size was wrong.",
 "Functionality at 5 years. Everything else — training quality, O&M fund discipline, chlorine supply chain, cover integrity — shows "
 "up here. A programme that cannot report this number is not managing for sustainability, whatever its monitoring forms say."])

# 7. FINANCE
d.h1("7.  Sustainability and O&M finance")
d.p("Whole-life cost, not capital cost, decides whether a programme leaves an asset or a ruin. The 20-year present value of O&M and "
    "component renewal is roughly 30–45% of capital cost at an 8% discount rate.")
d.table(["Cost element","T1 household","T2 cluster","T3 institution"],
 [["Capital (core scope)",f"{f(B['T1']['core_total'])}",f"{f(B['T2']['core_total'])}",f"{f(B['T3rcc']['core_total'])}"],
  ["Routine O&M per year (1.5% of capital + consumables)","~1,900","~7,300","~28,000"],
  ["Chlorine and consumables per year","~900","~3,200","~11,000"],
  ["Media and candle renewal (every 5 years)","~2,700","~11,000","~45,000"],
  ["Gutter renewal (every 8 years)","~6,100","~24,600","~102,000"],
  ["Lining renewal (every 10 years)","~3,400","~13,700","~57,000"],
  ["20-year whole-life PV at 8%","~95,000","~370,000","~1,540,000"],
  ["Whole-life cost per person per year","~790","~310","~190"]],
 widths=[7.0,3.3,3.3,3.4],fontsize=8.4)
d.p("The institutional unit has the highest capital cost and by far the lowest whole-life cost per person per year. That is the "
    "strongest economic argument in this document for making institutions the first call on a programme budget.",size=9.6,italic=True)
d.h2("7.1  How O&M is actually paid for")
d.table(["Tier","Mechanism","Amount","Discipline"],
 [["T1","Household responsibility; no tariff","~1,900 BDT/yr, mostly chlorine and candles","Household log book; community water agent checks quarterly"],
  ["T2","Water tariff, set by the committee","20–30 BDT per household per month","Committee account; 3 months of O&M held as a balance; passbook shown at every meeting"],
  ["T3","Institutional budget line + school/shelter committee","~28,000 BDT/yr","Annual O&M plan approved by the SMC; bank account in the institution's name"]],
 widths=[1.6,5.4,3.6,6.4],fontsize=8.4)
d.callout("The chlorine trap",
  "A programme that supplies two years of chlorine and no supply chain has created a system that will be non-functional in year three, "
  "with a community that believes it is drinking treated water. Before commissioning, name the supplier, the distance, the price and "
  "who pays. If there is no supply chain, install a system that does not depend on chlorine — and say so plainly.")
d.pagebreak()

# 8. SCALE
d.h1("8.  Scale-up costing")
d.p("Per-unit costs fall only modestly with scale, because the dominant cost is materials. What falls sharply is the fixed programme "
    "cost of training, supervision and laboratory testing, spread over more units.")
d.table(["Programme size","Composition","Capital, core scope","Fixed programme cost","Total","Reached"],
 [["Pilot — 10 units","6 T1, 3 T2, 1 T3","~1,558,000","~1,200,000","~2,758,000","2,616 people"],
  ["District — 100 units","60 T1, 30 T2, 10 T3","~16,730,000","~4,500,000","~21,230,000","5,560 people"],
  ["Division — 500 units","300 T1, 150 T2, 50 T3","~83,650,000","~16,000,000","~99,650,000","27,800 people"],
  ["National — 2,000 units","1,200 T1, 600 T2, 200 T3","~334,600,000","~52,000,000","~386,600,000","111,200 people"]],
 widths=[3.2,3.4,3.2,3.2,3.0,2.6],fontsize=8.2)
d.p("Fixed programme cost covers mason training, engineer supervision, laboratory testing, M&E and community mobilisation. It is "
    "estimated at roughly 27% of capital at 100 units and falls to about 13% at 2,000 units — which is why a programme that pilots "
    "once and stops never learns whether the unit cost was real.",size=9.6,italic=True)

# 9. RISK
d.h1("9.  Risk register")
d.table(["Risk","Likelihood","Impact","Mitigation","Owner"],
 [["Tank abandoned after 2–3 years","High","High","Signed agreement before build; O&M fund; functionality audit at year 3 and 5; a named chlorine supplier","Programme manager"],
  ["Arsenic or salinity in the 'secondary source' is untested","Medium","High","Test every fallback source at design stage; do not accept community assurance","WASH officer"],
  ["Mason workmanship fails — shell cracks, tank leaks","Medium","High","Ten-day mason training before construction; four QC hold points; 7-day curing record","Site engineer"],
  ["Chlorine supply chain breaks","Medium","High","Identify supplier and price at design stage; hold 6 months of stock at the union level","Logistics"],
  ["Elite capture — the tank serves the better-off","Medium","High","Published scoring; read the list aloud; quota for female-headed and disabled-headed households","Community mobiliser"],
  ["Cyclone damages units; cover lost, tank contaminated","High","Medium","Anchorage on every tier; pre-hazard protocol; post-hazard inspection within 2 weeks","Programme + CPP"],
  ["Funding ends before O&M is institutionalised","Medium","High","UP and DPHE asset register entry at handover; O&M plan approved before final payment","Programme director"],
  ["Cost inflation on cement and steel","High","Medium","Rate refresh before tender; contingency of 8% on materials; procurement aggregation","Finance"],
  ["Community contribution excludes the poorest","Medium","Medium","Contribution in labour only, never cash; labour can be substituted by a neighbour or by cash-for-work","Community mobiliser"]],
 widths=[4.0,1.9,1.5,7.2,2.4],fontsize=7.9)

# 10. EXIT
d.h1("10.  Exit and institutionalisation")
d.p("An exit strategy written at the end of a programme is an apology. This one is written at the design stage, and each element is a "
    "deliverable with a completion test.")
d.numbered([
 "Asset register entry with the Union Parishad and DPHE before final payment, so the asset exists in the national system rather than only in the programme's spreadsheet.",
 "A trained mason and a trained caretaker retained in each union, with contact details on the signage board and a small retainer or a defined fee-for-service arrangement.",
 "Chlorine supply named, priced and local: a specific dealer, a specific price, and an agreement that the union-level stock is replenished.",
 "O&M fund seeded for year one and controlled by the committee from day one, so that the habit of holding a balance exists before the programme leaves.",
 "A functionality audit at 12 months, 3 years and 5 years, funded and reported publicly, with a defined threshold for re-engagement.",
 "A written handover to the school management committee or shelter committee for institutional units, with the O&M plan approved and the bank account in the institution's name.",
 "A standing invitation to the Union Parishad WASH standing committee to inspect, so that local government ownership is practised rather than stated."])
d.h2("10.1  What success looks like in year five")
d.p("A successful programme in year five has: 70% or more of units at 'basic' or 'safely managed' service; a chlorine residual record "
    "in the log book for most weeks; a committee passbook with a balance; an asset in the UP register; a mason in the union who has "
    "repaired at least one tank without programme support; and at least one institutional unit that was used as a shelter and worked.")
d.p("")
rule(d.d)
p=d.d.add_paragraph(); r=p.add_run("Borsha-Bandhu Programme Implementation & DRR Guide  ·  BB-PIG-03 Rev A  ·  20 November 2026")
r.font.size=Pt(8); r.font.color.rgb=GREY; r.italic=True
d.save("/home/user/borsha_bandhu/03_Programme_Implementation_and_DRR_Guide.docx")
print("saved doc3")
