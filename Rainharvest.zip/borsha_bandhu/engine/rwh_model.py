"""
BORSHA-BANDHU - integrated RWH design engine
Monthly mass balance, cyclically converged (tank starts wet-season-end).
Bangladesh climate zones from BMD 30-yr monthly normals.
"""
import math

ZONES = {
 "A": dict(name="Southwest Coastal Belt",  ex="Khulna, Satkhira, Bagerhat, Barguna, Patuakhali, Pirojpur",
           m=[8,24,40,78,165,300,320,290,240,130,25,8]),
 "B": dict(name="Southeast Coastal Belt",  ex="Cox's Bazar, Chattogram, Bhola, Noakhali, Feni",
           m=[4,17,35,122,287,802,925,667,330,214,109,13]),
 "C": dict(name="Flood Plain & Haor",      ex="Kurigram, Gaibandha, Sirajganj, Jamalpur, Sunamganj, Netrokona",
           m=[10,30,90,220,400,550,560,450,380,180,25,8]),
 "D": dict(name="Barind & Char (drought)", ex="Rajshahi, Chapainawabganj, Naogaon, Pabna, char lands",
           m=[11,18,25,64,136,265,321,274,296,106,16,11]),
 "E": dict(name="Central Plain",           ex="Dhaka, Mymensingh, Cumilla, Tangail, Faridpur",
           m=[8,29,66,156,339,340,373,317,300,172,34,13]),
}
DAYS = [31,28,31,30,31,30,31,31,30,31,30,31]
MONTHS=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
DESIGN_FACTOR = 0.75
RUNOFF_COEF   = 0.80
FIRST_FLUSH_MM = 1.5
RHO_W = 9.81

def annual(mm): return sum(mm)

def runoff_monthly(rain_mm, area_m2):
    return [r*area_m2*RUNOFF_COEF for r in rain_mm]   # mm x m2 = litres

def simulate(rain_mm, area, tank, demand_lpd, tol=0.5, maxyr=60):
    """Cyclic monthly mass balance. Returns converged reliability metrics."""
    supply = runoff_monthly(rain_mm, area)
    dem = [d*demand_lpd for d in DAYS]
    S = tank*1.0                      # start wet-season end: tank full
    for _ in range(maxyr):
        S_start = S
        served=[0.0]*12; spill=[0.0]*12
        for i in range(12):
            room = max(tank-S, 0.0)
            taken = min(supply[i], room)
            spill[i] = supply[i]-taken
            S += taken
            d = dem[i]
            s = min(S, d); S -= s; served[i]=s
        if abs(S-S_start) < tol: break
    rel = sum(served)/sum(dem)
    dry_idx=[10,11,0,1,2,3,4]        # Nov-May
    wet_idx=[5,6,7,8,9]              # Jun-Oct
    dry_rel=sum(served[i] for i in dry_idx)/sum(dem[i] for i in dry_idx)
    wet_rel=sum(served[i] for i in wet_idx)/sum(dem[i] for i in wet_idx)
    # continuous dry-season coverage in days from 1 Nov
    order=dry_idx
    cov=0
    for i in order:
        frac=served[i]/dem[i]
        cov += frac*DAYS[i]
    return dict(rel=rel, dry_rel=dry_rel, wet_rel=wet_rel, spill=sum(spill),
                served=served, final=S, dry_days_covered=cov,
                annual_supply=sum(supply), annual_demand=sum(dem))

def supply_ratio(rain_mm, area, demand_lpd):
    return sum(runoff_monthly(rain_mm,area))/sum(d*demand_lpd for d in DAYS)

def max_reliability(rain_mm, area, demand_lpd):
    """Reliability with effectively infinite storage = min(1, supply/demand)."""
    return min(1.0, supply_ratio(rain_mm, area, demand_lpd))

def size_tank(rain_mm, area, demand_lpd, target=0.95, cap=200000):
    """Smallest tank (round 100 L) reaching target reliability; None if infeasible."""
    if max_reliability(rain_mm,area,demand_lpd) < target: return None
    lo,hi=100.0,cap
    if simulate(rain_mm,area,hi,demand_lpd)["rel"]<target: return None
    for _ in range(70):
        mid=(lo+hi)/2
        if simulate(rain_mm,area,mid,demand_lpd)["rel"]>=target: hi=mid
        else: lo=mid
    return int(round(hi/100.0)*100)

# ---------- hydraulics ----------
def peak_flow(area, intensity_mmhr=180):
    """Design peak roof yield, L/s. intensity 180mm/h = ~1-in-25yr 10-min BD storm."""
    return area*intensity_mmhr*RUNOFF_COEF/3600.0

def halfround_capacity(D_mm, S=0.005, n=0.011):
    """Manning, half-round PVC gutter, flowing full. L/s."""
    D=D_mm/1000.0
    A=math.pi*D*D/8.0
    R=D/4.0
    Q=(1.0/n)*A*(R**(2/3))*(S**0.5)
    return Q*1000.0

def gutter_size(area, intensity=180, S=0.005):
    q=peak_flow(area,intensity)
    for D in [75,90,110,125,150,200,250,300,375]:
        if halfround_capacity(D,S)>=q: return D, round(q,2), round(halfround_capacity(D,S),2)
    return 375, round(q,2), round(halfround_capacity(375,S),2)

def fullpipe_capacity(D_mm, S=0.02, n=0.011):
    D=D_mm/1000.0; A=math.pi*D*D/4.0; R=D/4.0
    return ((1.0/n)*A*(R**(2/3))*(S**0.5))*1000.0

def downpipe_size(area, intensity=180, S=0.02, pipes=1):
    q=peak_flow(area,intensity)/pipes
    for D in [50,63,75,90,110,125,160,200]:
        if fullpipe_capacity(D,S)>=q: return D, round(q,2)
    return 200, round(q,2)

def first_flush_volume(area, mm=FIRST_FLUSH_MM): return round(mm*area,1)

# ---------- structure ----------
def tank_dims(V, D):
    h = V/(math.pi*(D/2)**2)/1000.0
    return round(h,2)

def ferro_hoop(V, D, t_mm):
    h = tank_dims(V,D); r=D/2
    sigma = RHO_W*1000*h*r/(t_mm/1000.0)/1e6
    return dict(depth=h, hoop=round(sigma,3))

def uplift(D, flood_depth):
    A=math.pi*(D/2)**2
    return RHO_W*A*flood_depth

def selfweight(V, D, t_wall_mm=25, t_base_mm=100):
    A=math.pi*(D/2)**2; h=tank_dims(V,D)
    return (A*(t_base_mm/1000.0) + math.pi*D*h*(t_wall_mm/1000.0))*23.0

def wind_overturning(V,D,H_total, v_ms=72):
    """Cyclone gust 72 m/s (Cyclone Amphan-class). Overturning about base edge vs restoring."""
    A_proj=D*H_total
    F=0.6*1.2*v_ms**2/2*A_proj/1000.0        # kN, Cd=0.6
    M=F*H_total/2
    A=math.pi*(D/2)**2
    W=selfweight(V,D)
    Mr=W*(D/2)
    return dict(F_kN=round(F,1), M_overturn=round(M,1), M_restore=round(Mr,1),
                FoS=round(Mr/M,2) if M else None)
