from svgkit import *
def draw(path):
    d=DWG(1500,1020,90,title="D-03  CATCHMENT, FIRST-FLUSH & PRE-FILTER",no="BB-D-03")
    d.text(40,50,"CATCHMENT CONNECTION, FIRST-FLUSH DIVERTER & PRE-FILTER",20,INK,bold=True)
    d.text(40,72,"The two components that decide whether the water in the tank is safe. Scale 1:50 / 1:10 as noted.",11,HID)

    # ---------- A. ELEVATION (1:50) ----------
    d.text(40,110,"A — ROOF-TO-TANK ELEVATION   (1:50)",12,RED,bold=True)
    gl=500
    d.hatch(40,gl,610,26,"soil"); d.line(40,gl,650,gl,1.6)
    # house
    d.rect(60,gl-180,240,180,fill="#faf7f0",c=INK,sw=1.6)
    d.poly([(40,gl-180),(180,gl-268),(320,gl-180)],fill="#e8dcc8",c=INK,sw=1.8)
    d.text(180,gl-70,"HOUSE",13,HID,"middle",bold=True)
    d.text(180,gl-52,"20 m² roof",9,HID,"middle")
    # gutter + downpipe
    d.rect(296,gl-186,16,10,fill="#cfd8dc",c=INK,sw=1.3)
    d.rect(300,gl-184,8,182,fill="#cfd8dc",c=INK,sw=1.3)
    d.leader(300,gl-180,340,gl-206,"GI gutter 75 mm, fall 1:200",8.5,DIM)
    d.leader(304,gl-110,258,gl-146,"uPVC downpipe Ø50",8.5,DIM,"end")
    # first flush
    d.rect(288,gl-46,36,34,fill="#fde7e4",c=RED,sw=1.7)
    d.leader(306,gl-30,236,gl-16,"first-flush 30 L",8.5,RED,"end")
    # to filter
    d.rect(308,gl-92,10,10,fill="#cfd8dc",c=INK,sw=1.1)
    d.arrow if False else None
    arrow(d,312,gl-87,364,gl-87,sw=1.6)
    # filter drum
    d.rect(366,gl-142,76,142,fill="#fafafa",c=INK,sw=1.7)
    d.hatch(370,gl-96,68,22,"gravel"); d.hatch(370,gl-70,68,26,"sand"); d.hatch(370,gl-130,68,32,"gravel")
    d.leader(442,gl-60,452,gl-26,"3-stage pre-filter",8.5,DIM)
    # tank
    d.rect(500,gl-180,150,180,fill=FILL_W,c=INK,sw=1.9)
    d.rect(506,gl-142,138,134,fill="url(#hwater)",c="none",sw=0)
    d.text(575,gl-70,"TANK",12,HID,"middle",bold=True)
    arrow(d,444,gl-100,496,gl-100,sw=1.6)
    d.text(40,gl+46,"Peak flow at 180 mm/h design intensity = 0.80 L/s  →  75 mm gutter, 50 mm downpipe for a 20 m² roof.",9,GREEN)
    d.text(40,gl+64,"Gutter fall must be at least 1:200 towards the downpipe. A gutter that ponds is a mosquito breeding site.",9,GREEN)

    # ---------- D. TABLE ----------
    d.text(700,110,"D — CONVEYANCE SIZING TABLE",12,RED,bold=True)
    hdr=["Catchment","Peak flow","Gutter","Downpipe","First flush"]
    rows=[["20 m² (T1)","0.80 L/s","Ø75 half-round","1 × Ø50","30 L"],
          ["80 m²","3.20 L/s","Ø110 half-round","2 × Ø50","120 L"],
          ["120 m²","4.80 L/s","Ø150 half-round","4 × Ø50","180 L"],
          ["160 m² (T2)","4.80 L/s","Ø150 half-round","4 × Ø50","240 L"],
          ["400 m²","16.0 L/s","Ø250 half-round","8 × Ø63","600 L"],
          ["600 m² (T3)","16.0 L/s","Ø250 half-round","8 × Ø63","900 L"]]
    x0,y0=700,120; cw=[82,76,96,80,78]
    x=x0
    for i,h in enumerate(hdr):
        d.rect(x,y0,cw[i],24,fill=NAVY,c=INK,sw=0.8)
        d.text(x+cw[i]/2,y0+16,h,8.5,"#ffffff","middle",bold=True); x+=cw[i]
    for r,row in enumerate(rows):
        x=x0
        for i,v in enumerate(row):
            d.rect(x,y0+24+r*26,cw[i],26,fill="#ffffff" if r%2 else "#f2f6f9",c=INK,sw=0.8)
            d.text(x+cw[i]/2,y0+41+r*26,v,8.5,INK,"middle"); x+=cw[i]
    yy=y0+24+6*26+16
    d.text(x0,yy,"Sizing basis: Rational Method at 180 mm/h design intensity (1:25-yr, 10-min storm, Bangladesh).",8.5,HID)
    d.text(x0,yy+14,"Gutter capacity from Manning at 1:200 fall, n = 0.011, flowing full.",8.5,HID)
    d.text(x0,yy+28,"Never downsize a downpipe to save a fitting: the gutter will overtop at the wall and wash out the footing.",8.5,ACC)

    d.text(700,420,"THE THREE RULES THAT DECIDE WATER QUALITY",10,RED,bold=True)
    rules=["1.  Keep the first 1.5 mm out of the tank.",
           "     It carries most of the faecal indicator bacteria and the",
           "     leaf-derived colour. This is the single highest-value",
           "     component in the whole system for its cost.",
           "",
           "2.  Keep light out.",
           "     An uncovered tank grows algae and breeds Aedes",
           "     mosquitoes. A sealed, lockable cover is not optional.",
           "",
           "3.  Keep hands out.",
           "     Draw through a tap, never a bucket on a rope. A rope",
           "     dipped into the tank is the fastest route to contamination."]
    for i,t in enumerate(rules): d.text(700,442+i*15,t,8.5,INK)

    # ---------- B. FIRST FLUSH ----------
    d.text(40,600,"B — FIRST-FLUSH DIVERTER, SECTION   (1:10)",12,RED,bold=True)
    fx,fy=120,640
    d.rect(fx,fy,44,170,fill="#ffffff",c=INK,sw=1.8)
    d.rect(fx+6,fy+88,32,76,fill="url(#hwater)",c="none",sw=0)
    d.line(fx+6,fy+88,fx+38,fy+88,1.3,"#5b8fc0")
    d.rect(fx+8,fy-46,28,46,fill="#cfd8dc",c=INK,sw=1.3)
    d.rect(fx+44,fy+10,64,18,fill="#cfd8dc",c=INK,sw=1.3)
    arrow(d,fx+16,fy-42,fx+16,fy+24,sw=1.5)
    d.circle(fx+22,fy+84,7.5,fill="#ffffff",c=RED,sw=1.8)
    d.rect(fx+18,fy+8,9,9,fill=INK,c=INK,sw=0)
    d.line(fx+22,fy+17,fx+22,fy+77,1.1,INK,"3 2")
    d.text(fx+8,fy-58,"from downpipe",8.5,DIM)
    d.leader(fx+44,fy+18,fx+130,fy+2,"to pre-filter and tank",9,DIM)
    d.leader(fx+22,fy+84,fx-14,fy+150,"float ball seals outlet",8.5,RED,"end")
    d.dimv(fy+88,fy+164,fx+62,"30 L")
    d.text(40,872,"HOW IT WORKS",9.5,RED,bold=True)
    for i,t in enumerate(["Water fills the chamber first. The float rises and seals the outlet,",
                          "so the dirtiest first water is trapped instead of entering the tank.",
                          "A 3 mm bleed hole drains it over 10–15 min, the float drops, and the",
                          "diverter re-arms itself for the next rain event. No manual reset."]):
        d.text(40,890+i*14,t,8.5,INK)
    d.text(40,952,"Discard volume = 1.5 mm × catchment area:   T1  30 L    T2  180 L    T3  600 L",8.5,INK,bold=True)

    # ---------- C. PRE-FILTER ----------
    d.text(520,600,"C — 3-STAGE PRE-FILTER, SECTION   (1:10)",12,RED,bold=True)
    px,py=560,632
    d.rect(px,py,140,196,fill="#fafafa",c=INK,sw=1.9)
    d.hatch(px+6,py+8,128,44,"gravel");  d.text(px+70,py+35,"20 mm washed gravel",8.5,INK,"middle")
    d.hatch(px+6,py+54,128,52,"sand");    d.text(px+70,py+84,"graded coarse sand",8.5,INK,"middle")
    d.hatch(px+6,py+108,128,42,"gravel"); d.text(px+70,py+134,"charcoal, 3 kg",8.5,INK,"middle")
    d.rect(px+6,py+152,128,24,fill="url(#hwater)",c="none",sw=0)
    d.rect(px+48,py-30,26,30,fill="#cfd8dc",c=INK,sw=1.3)
    d.rect(px+56,py+196,24,34,fill="#cfd8dc",c=INK,sw=1.3)
    arrow(d,px+60,py-26,px+60,py+4,sw=1.4)
    d.text(px+40,py-36,"in from diverter",8.5,DIM)
    d.text(px+90,py+212,"to tank",8.5,DIM)
    d.leader(px+140,py+20,px+168,py-6,"removable top mesh, clean weekly",8.5,GREEN)
    d.leader(px+140,py+164,px+168,py+196,"backwash drain",8.5,GREEN)
    d.text(520,880,"Replace the charcoal and the top 50 mm of sand every 6 months.",8.5,ACC)
    d.text(520,896,"Backwash monthly: open the drain, run 10 L to waste.",8.5,ACC)
    d.text(520,912,"A filter that is never cleaned becomes a bacterial incubator — worse than no filter.",8.5,ACC,bold=True)
    return d.save(path)
if __name__=="__main__": print(draw("/home/user/borsha_bandhu/drawings/D-03_catchment_firstflush_filter.svg"))
