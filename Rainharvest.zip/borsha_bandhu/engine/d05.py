from svgkit import *
def draw(path):
    d=DWG(1500,1060,100,title="D-05  T3 INSTITUTIONAL UNIT — 60,000 L",no="BB-D-05")
    d.text(40,50,"T3 INSTITUTIONAL UNIT  —  60,000 L, SCHOOL / CYCLONE SHELTER",20,INK,bold=True)
    d.text(40,72,"400 users · 600 m² roof · full treatment train · 20-day emergency reserve in shelter mode.",11,HID)

    # ---- A. treatment train ----
    d.text(40,112,"A — TREATMENT TRAIN",12,RED,bold=True)
    steps=[("ROOF","600 m², 8 gutter\nruns, 8 downpipes"),
           ("FIRST FLUSH","8 × 600 L\ndiverters"),
           ("ROUGHING\nFILTER","1.2 m² up-flow,\ngravel 3 grades"),
           ("SLOW SAND\nFILTER","2.0 m², 0.15 m/h,\n0.7 m sand bed"),
           ("STORAGE","60,000 L RCC or\nferrocement tank"),
           ("CHLORINATION","flow-proportional\nhypochlorinator"),
           ("DAY TANK","2,000 L overhead,\ngravity to taps")]
    x=40; y=130; w=178; gap=20
    for i,(t,s) in enumerate(steps):
        fill="#dcece2" if i<4 else ("#e8eef7" if i>4 else FILL_W)
        d.rect(x,y,w,72,fill=fill,c=INK,sw=1.5,rx=3)
        lines=t.split("\n")
        d.text(x+w/2,y+22,lines[0],10,INK,"middle",bold=True)
        if len(lines)>1: d.text(x+w/2,y+36,lines[1],9,INK,"middle")
        for j,ln in enumerate(s.split("\n")):
            d.text(x+w/2,y+52+j*12,ln,7.8,HID,"middle")
        if i<len(steps)-1:
            arrow(d,x+w+3,y+36,x+w+gap-3,y+36,sw=1.6)
        x+=w+gap
    d.text(40,224,"Slow sand filtration is what makes institutional rainwater genuinely safe for children: it removes protozoal cysts (Cryptosporidium, Giardia) that chlorine alone does not.",8.5,GREEN)
    d.text(40,238,"Chlorine is a final barrier and a residual, not a primary treatment. Do not delete the filters to save capital cost.",8.5,GREEN)

    # ---- B. tank section ----
    d.text(40,286,"B — STORAGE TANK SECTION   (1:70)",12,RED,bold=True)
    S=70; sx=320; gl=770
    ro,ri=196,190
    pt=gl-0.25*S; bt=pt-0.25*S; wt=bt-2.44*S; cv=wt-0.15*S
    d.hatch(60,gl,530,24,"soil"); d.line(60,gl,590,gl,1.5)
    d.hatch(sx-212,pt,424,18,"conc")
    d.hatch(sx-ro,pt-18,392,18,"conc")
    d.hatch(sx-ro,wt,ro-ri,bt-wt,"conc"); d.hatch(sx+ri,wt,ro-ri,bt-wt,"conc")
    d.hatch(sx-ri,bt-18,2*ri,18,"conc")
    d.hatch(sx-ro,cv,2*ro,11,"conc")
    d.rect(sx-74,cv,42,11,fill="#ffffff",c=INK,sw=1.1)
    d.rect(sx+32,cv,42,11,fill="#ffffff",c=INK,sw=1.1)
    wl=wt+15
    d.rect(sx-ri,wl,2*ri,bt-18-wl,fill="url(#hwater)",c="none",sw=0)
    d.line(sx-ri,wl,sx+ri,wl,1.3,"#5b8fc0")
    d.rect(sx-ri,bt-18-49,2*ri,49,fill="none",c=RED,sw=1.1,dash="6 3")
    d.tag(sx-96,bt-40,"14-day sealed reserve",8.5,"#fff5f3")
    d.text(sx,gl+34,"RCC raft 250 mm · 2 layers Ø12 @150 · waterbar",8.3,INK,"middle")
    d.dimv(cv,gl,616,"3.34 m",9)
    d.dimh(sx-ro,sx+ro,gl+64,"Ø5.60 m internal")
    d.dimh(sx-212,sx+212,gl+98,"Ø6.00 m raft")
    d.text(40,880,"Wall 200 mm, water-retaining mix, crystalline waterproofing plus food-grade epoxy to the internal face. Roof slab with 2 sealed, lockable,",8.3,INK)
    d.text(40,894,"insect-screened manholes. Hoop tension at base 1.25 MPa, carried by Ø12 @150. Wind: overturning FoS 1.8 at 72 m/s gust before anchorage.",8.3,INK)

    # ---- C. emergency mode ----
    d.text(640,286,"C — CYCLONE SHELTER MODE",12,RED,bold=True)
    d.rect(640,298,820,182,fill="#fdf2f0",c=RED,sw=1.6,rx=4)
    rows=[("48 h before landfall","Top the tank up from pre-landfall rain, or run the hand pump. If it is under 70 % full, fill it first and seal afterwards."),
          ("During the event","All manholes sealed and bolted. Tapstands lashed down. Ladder removed so it cannot become a projectile."),
          ("First 72 h after","Drinking and cooking only: 5 L/person/day. Hygiene water comes from the shelter pond or PSF, never from this tank."),
          ("Day 4 onward","If relief water arrives, stop drawing from this tank and keep it as the fallback. Re-test the water before reopening.")]
    y=318
    for a,b in rows:
        d.text(656,y,a,9,RED,bold=True)
        d.text(656,y+13,b,8.3,INK)
        y+=42
    d.text(640,510,"At 400 people x 5 L/day, a 60,000 L tank gives 30 days of drinking water with no resupply — the most valuable thing this building can hold.",9,GREEN,bold=True)

    # ---- D. duties table ----
    d.text(700,570,"D — INSTITUTIONAL DUTIES & SAFEGUARDS",12,RED,bold=True)
    hdr=["Item","Requirement","Frequency"]
    rows=[["Caretaker","1 named teacher + 1 support staff, trained, named on a board","Continuous"],
          ["Candle / media","Pre-filter media replaced; SSF sand scraped when head loss > 0.4 m","6 months / 3 months"],
          ["Tank cleaning","2 trained people, ladder + rope + second person outside","2 × per year"],
          ["Chlorine residual","0.2–0.5 mg/L at the furthest tap; logged on a board","Weekly"],
          ["Bacteriological test","E. coli 0/100 mL at tank and at tap","Quarterly"],
          ["O&M fund","3 months of O&M cost held in the school account","Reviewed annually"],
          ["Drill","Shelter-mode drill with students and committee","Before monsoon"]]
    x0,y0=700,584; cw=[130,460,150]
    x=x0
    for i,h in enumerate(hdr):
        d.rect(x,y0,cw[i],22,fill=NAVY,c=INK,sw=0.8)
        d.text(x+6,y0+15,h,8.5,"#ffffff",bold=True); x+=cw[i]
    for r,row in enumerate(rows):
        x=x0
        for i,v in enumerate(row):
            d.rect(x,y0+22+r*23,cw[i],23,fill="#ffffff" if r%2 else "#f2f6f9",c=INK,sw=0.8)
            d.text(x+6,y0+38+r*23,v,8,INK); x+=cw[i]
    return d.save(path)
if __name__=="__main__": print(draw("/home/user/borsha_bandhu/drawings/D-05_T3_institutional_unit.svg"))
