import json
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docxkit import *
from rwh_model import ZONES, DESIGN_FACTOR, simulate, size_tank, gutter_size, downpipe_size, first_flush_volume, DAYS, MONTHS
B=json.load(open("bom.json"))
def rd(z): return [r*DESIGN_FACTOR for r in ZONES[z]["m"]]
f=lambda n: f"{n:,.0f}"

d=Doc("Integrated Rainwater Harvesting System",
      "Technical Design Manual",
      [("Document","BB-TDM-01  ·  Revision A"),
       ("Prepared","20 November 2026"),
       ("Scope","Household, cluster and institutional rainwater harvesting for marginalised and disaster-prone communities in Bangladesh"),
       ("Design zones","Coastal belt · Flood plain and haor · Barind and char · Central plain"),
       ("Status","For engineering review and field pilot")])
d.cover("BB-TDM-01",
  "A three-tier rainwater harvesting system designed to be built with local labour, maintained by the community that owns it, "
  "and to keep delivering safe drinking water through a cyclone, a flood or a drought. This manual contains the design basis, "
  "the hydraulic and structural calculations, the tier specifications, the bills of quantities and the zone adaptations needed "
  "to deploy it in any upazila of Bangladesh.",
  [("3","deployment tiers"),("5","climate zones"),("100%","potable demand met, T1"),(f(B['T2']['core_total']/60),"BDT per person, cluster")])

# ---------------- 1. EXEC SUMMARY ----------------
d.h1("1.  Executive summary")
d.lead("What this system is, what it costs, and the one number that should change how programmes in Bangladesh buy rainwater tanks.")
d.p("Borsha-Bandhu is a modular rainwater harvesting system with three deployment tiers built around one process train: "
    "roof catchment, first-flush diversion, pre-filtration, protected storage, disinfection and a public draw-off point. "
    "Every tier reuses the same components and the same construction technique, so a single trained mason team can build "
    "a household jar, a cluster tank and an institutional tank from one set of drawings.")
d.p("The design work produced four findings that a programme manager should act on before procuring anything.")
d.h3("Finding 1 — The standard 2,000 litre tank does not work, and the sector knows it but keeps buying it")
d.p("A 2,000 litre tank on a 20 m² roof meets 79.9% of a six-person household's potable demand over a year in the southwest "
    "coastal belt, and only 65.4% during the dry season — about 139 of the 243 dry-season days. Households fall back on saline "
    "or arsenic-bearing tubewells for four months of the year, which is precisely when those sources are worst. "
    "Moving to 5,000 litres on the same roof takes annual coverage to 100% and dry-season coverage to 100% in all five climate zones.")
d.table(["Tank volume","Zone A annual","Zone A dry season","Zone D annual","Zone D dry season"],
        [["2,000 L (sector standard)","79.9%","65.4%","76.1%","58.8%"],
         ["3,000 L","89.0%","81.1%","85.2%","74.5%"],
         ["4,000 L","98.2%","96.9%","94.3%","90.3%"],
         ["5,000 L  (this design)","100%","100%","100%","100%"]],
        widths=[5.0,2.9,2.9,2.9,2.9])
d.p("The extra 3,000 litres of storage costs roughly 12,000–14,000 BDT in materials and labour. It buys four months of safe water "
    "per year for twenty years. No other item in the bill of quantities returns anything close to that.",size=9.6,italic=True)

d.h3("Finding 2 — Storage, not catchment, is the binding constraint for households; the reverse is true for institutions")
d.p("For a household, 20 m² of roof delivers 19,500 litres a year against a demand of 10,950 — nearly twice what is needed. "
    "The only reason households run dry is that they cannot store the monsoon surplus. For an institution, 400 users on a 600 m² "
    "roof is supply-limited: even with unlimited storage it can meet only 73–82% of a 1,000 litre/day institutional demand in the "
    "driest zones. This means household money should go into tank volume, and institutional money should go into catchment area and "
    "a guaranteed secondary source.")

d.h3("Finding 3 — The surplus is the most under-used asset in Bangladeshi RWH")
d.p("A household unit spills 7.6–31 m³ a year. A cluster spills 58–238 m³. An institution spills 290–970 m³. In almost every "
    "existing programme that water is piped to a ditch. Managed into a recharge pit or a shallow recharge well, the same water "
    "holds the freshwater lens above the saline interface in the coastal belt and keeps the shallow aquifer — and the tubewells "
    "in it — alive through the Barind dry season. Recharge is not an add-on; it is what makes a 40-year-old asset useful after "
    "the tank is empty.")

d.h3("Finding 4 — Institutional systems deliver water at one fifth the unit cost")
d.p(f"A household unit costs {f(B['T1']['core_total'])} BDT for six people — {f(B['T1']['core_total']/6)} BDT per person. "
    f"A cluster unit costs {f(B['T2']['core_total'])} BDT for sixty people — {f(B['T2']['core_total']/60)} BDT per person. "
    f"An institutional unit costs {f(B['T3']['core_total'])} BDT for four hundred users — {f(B['T3']['core_total']/400)} BDT per person. "
    "The institution is also the building people shelter in during a cyclone. A programme that builds only household jars is paying "
    "a large premium to reach dispersed families; a mixed portfolio reaches far more people per taka and leaves the community with "
    "a public asset that works on the worst day of the decade.")
d.callout("The design position",
  "Build household units where families are dispersed and no shared structure exists. Build cluster units where a hamlet already "
  "shares a courtyard or a tubewell. Build institutional units first wherever a school or cyclone shelter can be served, because "
  "that is where the cost per person and the disaster value are both best. In all three cases, size the tank to 5 litres per "
  "person per day of drinking and cooking water across 243 dry-season days, and route the overflow to recharge.")
d.pagebreak()

# ---------------- 2. DESIGN BASIS ----------------
d.h1("2.  Design basis")
d.h2("2.1  Service level — what the system promises")
d.p("Bangladeshi RWH programmes frequently claim to supply 'domestic water' and then deliver a fraction of it. This design is "
    "explicit about what it guarantees and what it does not.")
d.table(["Parameter","Value","Basis"],
 [["Guaranteed service","Drinking and cooking water","The uses where a contaminated or saline alternative causes direct harm"],
  ["Service level","5 litres per person per day","WHO/Sphere basic drinking-water access; sufficient for drinking plus cooking"],
  ["Reliability target","100% of days, Tier 1","At P80 dry-year rainfall, verified by mass balance (Section 5)"],
  ["Reliability target","≥ 85% annual, Tier 2","Cluster demand of 300 L/day; remainder from a managed secondary source"],
  ["Reliability target","100% of institutional demand within tank capacity, Tier 3","Plus a sealed 14-day emergency reserve in shelter mode"],
  ["Not guaranteed","Bathing, laundry, livestock","Deliberately excluded; these loads would triple the tank and destroy affordability"]],
 widths=[4.0,5.0,7.5])
d.p("Setting the service level at 5 lpcd rather than the conventional 20 lpcd is the single most important design decision in this "
    "manual. A 20 lpcd system for six people needs roughly 44,000 litres of storage to be reliable — twenty times the cost, for water "
    "that households can obtain from a pond or a tubewell without immediate health risk. Concentrating the capital on the 5 litres "
    "that must be safe is what makes the system affordable and, therefore, what makes it real.",size=9.6,italic=True)

d.h2("2.2  Design rainfall")
d.p("Rainfall is taken from Bangladesh Meteorological Department 30-year monthly normals for five representative stations. "
    "The design value is the P80 dry-year rainfall, approximated as 0.75 × the mean. A tank sized to this value performs to "
    "its service standard in four years out of five; in the fifth, the household draws more heavily on the secondary source.")
d.table(["Zone","Region","Representative districts","Mean annual (mm)","Design P80 (mm)"],
 [[z,ZONES[z]["name"],ZONES[z]["ex"],f(sum(ZONES[z]["m"])),f(sum(ZONES[z]["m"])*DESIGN_FACTOR)] for z in ZONES],
 widths=[1.3,3.7,5.6,2.7,2.9])
d.p("Using the mean instead of a dry-year value is the commonest hydrological error in RWH design in Bangladesh. It produces a tank "
    "that works in a good year and fails in the year the household most needs it — and it fails silently, because the failure looks "
    "like a drought rather than a design fault.",size=9.6,italic=True)

d.h2("2.3  Load and loss assumptions")
d.table(["Assumption","Value","Justification"],
 [["Runoff coefficient","0.80","GI sheet, tile or asbestos roof in fair condition; allows splash-out, evaporation and gutter loss. Clean new GI is 0.90."],
  ["First-flush discard","1.5 mm of rainfall per event","Upper end of the 0.5–2 mm range; Bangladesh monsoon rain follows long dry spells with heavy leaf and dust loading."],
  ["Filter / treatment loss","10% of delivered volume","Backwash and cartridge losses."],
  ["Roof catchment, T1","20 m²","Median rural homestead roof. Zone D requires 30 m² (see Section 8)."],
  ["Roof catchment, T2","160 m²","10 households × 16 m² of connected roof."],
  ["Roof catchment, T3","600 m²","School or cyclone shelter with a full-length roof."]],
 widths=[4.2,3.6,8.7])

d.h2("2.4  Standards applied")
d.bullets([("Water quality","Environment Conservation Rules 1997 (ECR'97) drinking-water limits: E. coli 0/100 mL, turbidity 10 NTU, pH 6.5–8.5, arsenic 0.05 mg/L, TDS 1,000 mg/L, chloride 150–600 mg/L."),
 ("Structural","Ferrocement hoop stress limited to 3.0 MPa, giving a factor of safety of at least 4 on the mortar tensile strength and 8 on typical field workmanship."),
 ("Wind","Design gust 72 m/s, equivalent to Cyclone Amphan and Sidr class landfall."),
 ("Flood","Plinth level set from the local BWDB gauge to 100-year flood level plus 0.5 m, or to the highest recorded flood where no gauge exists."),
 ("Sanitation","Potable point separated from latrines by at least 10 m and sited upslope.")])
d.pagebreak()

# ---------------- 3. SYSTEM ARCHITECTURE ----------------
d.h1("3.  System architecture")
d.p("The three tiers are not three different systems. They are one process train at three scales. This is deliberate: it means one "
    "training curriculum, one set of spare parts, one maintenance routine, and a mason who has built a household jar can build an "
    "institutional tank.")
d.table(["Stage","Function","Household (T1)","Cluster (T2)","Institutional (T3)"],
 [["1  Catchment","Collect rain","20 m² roof","160 m² of roofs","600 m² roof"],
  ["2  Conveyance","Move water, screen debris","Ø75 gutter, 1 × Ø50 downpipe","Ø150 gutter, 4 × Ø50","Ø250 gutter, 8 × Ø63"],
  ["3  First flush","Reject the dirtiest water","1 × 30 L diverters","4 × 180 L","8 × 600 L"],
  ["4  Pre-treatment","Remove grit, colour, organics","60 L 3-layer drum","200 L battery","1.2 m² roughing + 2.0 m² slow sand"],
  ["5  Storage","Hold 243 days of demand","5,000 L ferrocement","30,000 L ferrocement","60,000 L RCC or ferrocement"],
  ["6  Disinfection","Kill pathogens, leave a residual","dropper dosing","constant-head chlorinator","flow-proportional hypochlorinator"],
  ["7  Distribution","Safe, accessible draw-off","1 tapstand + candle filter","2 tapstands + locked potable point","4 tapstands + hand pump + day tank"],
  ["8  Overflow","Recover the surplus","recharge pit + garden","recharge pit + well","up to 4 pits + well + garden"],
  ["9  Reserve","Function when everything else fails","—","—","sealed 14-day emergency reserve"]],
 widths=[2.4,4.0,3.3,3.2,3.6],fontsize=8.2)
d.p("Stage 9 is what separates a water supply from a disaster response asset. A sealed 60,000 litre tank in a cyclone shelter holds "
    "thirty days of drinking water for four hundred people. Nothing else the programme can buy for the same money does that.")
d.pagebreak()

# ---------------- 4. HYDRAULIC DESIGN ----------------
d.h1("4.  Hydraulic design and storage sizing")
d.h2("4.1  Method")
d.p("Storage is sized by monthly mass balance, run cyclically to convergence. The tank is assumed full at the end of the wet season "
    "— which is what actually happens — and the model then steps through twelve months. In each month, supply is rainfall × catchment "
    "area × runoff coefficient; demand is users × 5 litres × days in month. The tank accepts inflow up to its remaining freeboard, "
    "spills the excess, then serves demand from storage. The year repeats until closing storage equals opening storage, so the result "
    "is a steady-state reliability rather than an artefact of the starting condition.")
d.callout("Why cyclic convergence matters",
  "A naive single-year run starting with an empty tank in January will report that even a 60,000 litre tank fails, because the tank "
  "begins the dry season empty. That is a modelling error, not a design finding — and it is one of the reasons so many RWH designs "
  "in the region are mis-sized. Starting full and iterating to convergence removes it.")
d.p("The same calculation is implemented as a live worksheet in the accompanying costing model (Sheet 3, Sizing Engine), so any "
    "engineer can re-run it for a specific site with a measured roof area and a local rainfall record.")

d.h2("4.2  Storage required for 90% annual reliability")
rows=[]
for name,a,dmd,std in [("T1 household · 20 m²",20,30,"6 users @ 5 lpcd"),
                        ("T1 household · 30 m²",30,30,"6 users @ 5 lpcd"),
                        ("T2 cluster · 160 m²",160,300,"60 users @ 5 lpcd"),
                        ("T3 institution · 600 m²",600,1000,"400 users @ 1,000 L/d")]:
    r=[name,std]
    for z in ZONES:
        v=size_tank(rd(z),a,dmd,0.90)
        r.append(f"{(v/1000):.1f} m³" if v else "not feasible")
    rows.append(r)
d.table(["Tier / catchment","Service standard","Zone A","Zone B","Zone C","Zone D","Zone E"],rows,
        widths=[4.0,3.4,2.1,2.1,2.1,2.1,2.1],fontsize=8.4)
d.p("Read the table this way: if a tank sized for 90% reliability in the worst zone (A or D) is adopted as the standard, that same "
    "tank over-performs in every other zone. This is why the design specifies 5,000 litres for household units and 30,000 litres for "
    "clusters throughout the country, rather than a different size per zone. Standardisation cuts cost and error more than it costs "
    "in over-capacity.")

d.h2("4.3  Adopted tier sizes and their performance")
rows=[]
for code,tiers in [("T1",[(2000,"sector standard"),(3000,"—"),(4000,"—"),(5000,"ADOPTED")]),
                   ]:
    pass
perf=[("T1 household",20,[2000,3000,4000,5000],30),
      ("T2 cluster",160,[10000,20000,30000,40000],300),
      ("T3 institution",600,[30000,45000,60000,80000],1000)]
for name,a,vols,dmd in perf:
    for v in vols:
        r=[name,f"{v:,} L",f"{a} m²"]
        for z in ["A","B","C","D","E"]:
            s=simulate(rd(z),a,v,dmd)
            r.append(f"{s['rel']*100:.0f}% / {s['dry_days_covered']:.0f} d")
        rows.append(r)
d.table(["Tier","Tank","Catchment","Zone A","Zone B","Zone C","Zone D","Zone E"],rows,
        widths=[3.0,2.2,2.0,2.2,2.2,2.2,2.2,2.2],fontsize=8.0)
d.p("Each cell reads: annual reliability / dry-season days covered out of 243. The adopted sizes are emboldened in the tier "
    "specification in Section 10. Note that no institutional tank reaches 100% from roof capture alone in Zones A and D. That is not "
    "a failure of the design; it is arithmetic. It is why Section 9 makes the secondary source and recharge integral rather than optional.",
    size=9.6,italic=True)

d.h2("4.4  Hydraulic checks")
d.p("Peak flow is calculated by the Rational Method using a design intensity of 180 mm/h, the approximate 1-in-25-year ten-minute "
    "intensity for Bangladesh, rather than a mean intensity. Using a mean value under-sizes the gutter and the roof overtops at the "
    "wall during exactly the convective storms that characterise the pre-monsoon.")
rows=[]
for name,a,npipes in [("T1  20 m²",20,1),("T2  160 m²",160,4),("T3  600 m²",600,8)]:
    D,q,cap=gutter_size(a); dp,qd=downpipe_size(a,pipes=npipes)
    rows.append([name,f"{q:.2f}",f"Ø{D} mm half-round",f"{cap:.2f}",f"{npipes} × Ø{dp} mm",f"{first_flush_volume(a):.0f} L"])
d.table(["Catchment","Peak flow (L/s)","Gutter","Gutter capacity (L/s)","Downpipes","First-flush volume"],rows,
        widths=[3.0,2.8,3.4,3.3,3.0,3.0],fontsize=8.6)
d.p("Gutter capacity is computed from Manning's equation at 1:200 fall with n = 0.011, flowing full. A 1:200 fall is the minimum "
    "that will still self-clean; flatter gutters pond, and ponding gutters breed Aedes mosquitoes. This is a health requirement "
    "expressed as a hydraulic one.",size=9.6,italic=True)
d.pagebreak()

# ---------------- 5. TREATMENT ----------------
d.h1("5.  Treatment and water quality")
d.p("Rainwater is chemically excellent and microbiologically unreliable. It is soft, near-neutral, low in dissolved solids and free "
    "of arsenic — which matters enormously in a country where 20 million people drink arsenic-contaminated groundwater. What it is "
    "not is sterile. Bird and animal faeces on the roof, leaf litter in the gutter and biofilm in the tank deliver faecal indicator "
    "bacteria and, in institutional systems, protozoal cysts.")
d.p("The treatment train is therefore built in that order of importance: keep contamination out, remove what gets in, then disinfect.")

d.h2("5.1  Barriers and what each one is worth")
d.table(["Barrier","Removes","Design value","If omitted"],
 [["Sealed, lockable cover","Light, insects, rodents, hands, airborne dust","Eliminates algal growth and Aedes breeding; prevents the commonest contamination route","Mosquito breeding, algae, taste complaints, tank abandonment"],
  ["First-flush diverter (1.5 mm)","Faecal indicator bacteria, leaf-derived colour, grit","Removes the majority of the microbial load from a single event","Tank becomes a settling tank for faeces"],
  ["Gravel / sand / charcoal pre-filter","Grit, turbidity, colour, dissolved organics","Protects the tank from silt and the chlorine from chlorine demand","Sludge accumulates; chlorine is consumed before it disinfects"],
  ["Slow sand filter (T3 only)","Protozoal cysts, bacteria, turbidity to < 1 NTU","The only barrier in the train that removes Cryptosporidium and Giardia","Children in schools exposed to protozoal risk that chlorine cannot address"],
  ["Chlorination, 0.2–0.5 mg/L residual","Bacteria and viruses; provides a residual through distribution","Protects the water between the tank and the cup","Recontamination at the tapstand goes undetected"],
  ["Floating or calmed inlet","Sediment resuspension on refill","Keeps stored water clear so chlorine works","Every storm turns the tank over"]],
 widths=[3.4,3.4,5.2,4.2],fontsize=8.2)

d.h2("5.2  Disinfection dosing")
d.p("Calcium hypochlorite (65% granular, HTH) is used throughout because it is available in every district, has a long shelf life "
    "when kept dry and dark, and does not require the sodium hypochlorite solution to be transported. Dosing is set by the "
    "free-chlorine residual, not by a fixed spoon per tank.")
d.table(["Tier","Method","Target residual","Verification"],
 [["T1","Household dropper bottle: 5 mL of 1% stock per 20 L of stored water, adjusted after the first week","0.2–0.5 mg/L at the tap","DPD tablet test weekly for the first month, then monthly"],
  ["T2","Constant-head chlorinator, 20 L, feeding the draw-off line","0.2–0.5 mg/L at the furthest tapstand","DPD test by the caretaker weekly; logged"],
  ["T3","Flow-proportional hypochlorinator, 50 L, lockable","0.2–0.5 mg/L at the furthest tap","DPD weekly; full ECR'97 suite quarterly at a DPHE or ICDDR,B laboratory"]],
 widths=[1.4,6.0,3.4,5.4],fontsize=8.4)
d.callout("Do not dose by rule of thumb",
  "Turbid water consumes chlorine. A tank reading 20 NTU will need two to three times the dose of a clear one to hold the same residual. "
  "This is why the pre-filter matters as much as the chlorine, and why every caretaker is trained to test the residual rather than "
  "count drops.")

d.h2("5.3  Water quality targets")
d.table(["Parameter","ECR'97 limit","Design target","Notes"],
 [["E. coli","0 per 100 mL","0 per 100 mL","Any detection triggers re-chlorination and investigation of the cover and first-flush"],
  ["Turbidity","10 NTU","< 5 NTU","Pre-filter and first flush should hold this comfortably"],
  ["pH","6.5–8.5","6.5–8.0","Fresh concrete tanks can push pH to 8.5+ for the first months; epoxy lining prevents it"],
  ["Arsenic","0.05 mg/L","< 0.01 mg/L","Rainwater contains none; this is the reason the system exists in Zone D"],
  ["TDS","1,000 mg/L","< 100 mg/L","Rainwater is very low; any rise indicates ingress"],
  ["Chloride","150–600 mg/L","< 20 mg/L","A rising chloride reading in the coastal belt is the early warning of salt spray ingress"],
  ["Residual chlorine","0.2–0.5 mg/L","0.2–0.5 mg/L","Measured at the furthest tap, not in the tank"]],
 widths=[2.8,2.8,2.8,7.6],fontsize=8.4)
d.p("The design deliberately reports arsenic and chloride targets that are far tighter than the national limits. Rainwater that meets "
    "only the ECR'97 limit has, in practice, been contaminated by something. Tight internal targets catch that early.",size=9.6,italic=True)
d.pagebreak()

# ---------------- 6. STRUCTURAL ----------------
d.h1("6.  Structural design")
d.h2("6.1  Ferrocement shell (T1 and T2)")
d.p("The tank is a thin cylindrical shell of cement-sand mortar reinforced with two layers of chicken wire and a weld-mesh armature, "
    "wrapped around a grid of 8 mm mild steel bars at 150 mm centres in both directions. The armature carries the tension; the mortar "
    "carries the compression and protects the steel. This is what allows a 25 mm wall where reinforced concrete would need 150 mm.")
d.p("Hoop stress at the base of a full tank, for a thin cylinder free at the top, is:")
p=d.d.add_paragraph(); r=p.add_run("      σ = γ · h · r / t")
r.font.name='Consolas'; r.font.size=Pt(11); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
d.p("where γ is the unit weight of water, h the depth, r the radius and t the wall thickness. Results for the adopted geometries:")
rows=[]
for V,D,tw in [(3000,1.40,25),(4000,1.60,25),(5000,1.80,25),(10000,2.40,30),(30000,3.90,32),(60000,5.60,45)]:
    h=(V/1000)/(3.14159*(D/2)**2); sig=9810*h*(D/2)/(tw/1000)/1e6
    rows.append([f"{V:,} L",f"{D:.2f} m",f"{tw} mm",f"{h:.2f} m",f"{sig:.2f} MPa",f"{3.0/sig:.1f}", "Ferrocement"])
d.table(["Volume","Diameter","Wall","Depth","Hoop stress","FoS","Material"],rows,
        widths=[2.4,2.4,2.0,2.2,2.8,1.8,2.6],fontsize=8.6)
d.p("All cases sit below the 3.0 MPa allowable, with factors of safety between 2.4 and 6.9 on the allowable stress — and the "
    "allowable is itself already a conservative fraction of mortar tensile strength. The governing failure mode in practice is not "
    "hoop stress; it is poor workmanship at the base junction and inadequate curing, which is why the construction manual fixes "
    "both with inspection hold points.")

d.h2("6.2  Wind and cyclone anchorage")
d.p("Free-standing tanks are checked for overturning under a 72 m/s gust, the order of landfall intensity for Cyclone Amphan and Sidr. "
    "Wind force is taken as 0.6 × ½ρv² × projected area, acting at mid-height, resisted by the self-weight about the downwind base edge.")
rows=[]
for V,D,H in [(3000,1.40,2.3),(5000,1.80,2.4),(10000,2.40,2.8),(30000,3.90,3.3),(60000,5.60,3.4)]:
    A=D*H; F=0.6*1.2*72**2/2*A/1000; Mo=F*H/2
    Ab=3.14159*(D/2)**2; W=(Ab*0.10+3.14159*D*H*0.03)*23
    Mr=W*(D/2)
    rows.append([f"{V:,} L",f"{D:.2f} m",f"{F:.1f} kN",f"{Mo:.0f} kNm",f"{W:.1f} kN",f"{Mr:.0f} kNm",
                 f"{Mr/Mo:.2f}", "Anchorage required" if Mr/Mo<1.5 else "Stable"])
d.table(["Volume","Dia","Wind force","Overturning","Self-weight","Restoring","FoS","Outcome"],rows,
        widths=[2.2,1.8,2.2,2.4,2.3,2.2,1.5,3.2],fontsize=8.3)
d.p("Only the 30,000 litre tank and above are stable on self-weight alone. Household tanks between 3,000 and 5,000 litres have "
    "overturning factors of safety below 1.2 — they will tip in a severe cyclone if empty or partly empty. The design therefore "
    "specifies four M16 stainless anchors and two tie-down straps over the cover for every tier, in every zone. The marginal cost "
    "is about 2,000 BDT for a household unit. The cost of omitting it is the water supply for the following dry season.")

d.h2("6.3  Buoyancy in flood")
d.p("An empty tank standing in floodwater experiences uplift equal to the weight of the displaced water, while its own submerged "
    "weight is reduced. For a 30,000 litre tank of 3.9 m diameter in 1.0 m of floodwater the uplift is about 117 kN against a "
    "self-weight of about 46 kN: it floats and rolls. This is not a theoretical concern in the haor and char areas.")
d.table(["Tank","Flood depth","Uplift","Self-weight","FoS","Required action"],
 [["10,000 L","0.6 m","27 kN","19 kN","0.70","Raise on plinth above flood level"],
  ["10,000 L","1.2 m","53 kN","19 kN","0.36","Raise, or anchor to mass concrete"],
  ["30,000 L","0.6 m","52 kN","46 kN","0.88","Raise, or anchor to mass concrete"],
  ["30,000 L","1.2 m","103 kN","46 kN","0.45","Raise, or anchor to mass concrete"],
  ["60,000 L","1.0 m","193 kN","85 kN","0.44","Raise, or anchor to mass concrete"]],
 widths=[2.6,2.6,2.4,2.6,1.8,5.6],fontsize=8.6)
d.p("The primary strategy is elevation, not anchorage. A plinth that puts the base of the tank above the 100-year flood level plus "
    "0.5 m removes the problem entirely and is cheaper than 1.5 times the uplift force in mass concrete. Anchorage is the fallback "
    "where the plinth cannot be raised — for example in a homestead where the whole compound is below the flood line.")
d.callout("Rule",
  "Never bury a ferrocement tank in clay soil in a flood-prone area. Expansive clay cycles plus buoyancy plus an empty tank is the "
  "most reliable way to crack a shell. Keep it above ground, on a plinth, sealed and tied down.")
d.pagebreak()

# ---------------- 7. ZONE ADAPTATIONS ----------------
d.h1("7.  Zone adaptations")
d.p("The tank does not change between zones. What changes is where it sits, what it is sealed with, how much roof is connected and "
    "what the overflow is for. Deploying the coastal anchorage detail in the Barind wastes money; deploying the Barind catchment "
    "assumption in Satkhira produces a tank that never fills.")
d.h2("7.1  Zone A and B — coastal belt")
d.bullets([("Sealing and anchorage.","Four M16 stainless anchors and two tie-down straps over the cover. All fixings stainless 304; galvanised steel fasteners fail in three to four years in salt air."),
 ("Epoxy lining is mandatory, not optional.","Chloride ingress through micro-cracks attacks the armature from inside. A food-grade epoxy lining is the only barrier that survives twenty years."),
 ("Plinth 300 mm above surrounding ground,","sited on the highest point of the homestead, so that a storm surge of less than a metre does not reach the base."),
 ("Recharge pit is compulsory.","In the coastal belt the overflow is what holds the freshwater lens above the saline interface. It is the mechanism by which the community's fallback source survives the dry season."),
 ("Emergency reserve valve.","Fourteen days of drinking water sealed in the tank before landfall, opened only by the shelter or WASH committee.")])

d.h2("7.2  Zone C — flood plain and haor")
d.bullets([("Plinth to 100-year flood level plus 0.5 m,","read from the local BWDB gauge. Where no gauge exists, use the highest flood remembered by the oldest residents and add 0.5 m."),
 ("Anti-buoyancy calculation is required,","not assumed. See Section 6.3. If the plinth cannot be raised, anchor to mass concrete of at least 1.5 times the uplift force."),
 ("Backwater flap valve on the overflow","so that flood water cannot enter the tank through the overflow pipe — a real and common failure that turns a clean tank into a contaminated one within hours."),
 ("Pre-flood protocol.","Fill the tank before the crest arrives. A full tank resists buoyancy far better than an empty one and becomes the emergency water point for the settlement."),
 ("Draw-off and tapstand above the 100-year flood level","so the tank is still usable when the ground floor is under water.")])

d.h2("7.3  Zone D — Barind and char lands")
d.bullets([("Catchment is the binding constraint, not storage.","Design rainfall is 1,157 mm in a dry year. The household unit requires a 30 m² catchment here, not 20 m², achieved by a lean-to roof extension or a separate sheet catchment."),
 ("Keep the 5,000 litre tank even though the roof rarely fills it.","The constraint is the length of the dry season, not the volume of the monsoon."),
 ("Recharge is the principal benefit in a drought year.","It keeps the shallow aquifer — and the shallow tubewells in it — alive. The tank is the visible asset; the recharge pit is the one that works in April."),
 ("Rainwater is the arsenic-free source.","Never blend stored rainwater with untested tubewell water. Where a household has both, the tank water is for drinking and cooking and the tubewell for everything else."),
 ("Two tanks in series where affordable,","so sediment settles in the first and the second stays clear. A useful upgrade path for households that start with one.")])

d.h2("7.4  Zone E — central plain")
d.p("Moderate rainfall, standard design applies, with two local adjustments: urban and peri-urban sites need a first-flush volume "
    "increased by 50% because of heavier roof dust and industrial fallout, and peri-urban households should be assessed for arsenic "
    "in the shallow aquifer before deciding whether the tank is a potable source or a convenience source.")
d.pagebreak()

# ---------------- 8. INTEGRATED ELEMENTS ----------------
d.h1("8.  Integrated elements — recharge, garden and secondary source")
d.p("This is what makes the system 'integrated' rather than simply a tank. The overflow is not a waste pipe.")
d.table(["Element","Function","Sizing","Annual volume recovered"],
 [["Recharge soak pit","Returns overflow to the shallow aquifer; sustains the freshwater lens in the coastal belt","1.5 m dia × 2.2 m deep, brick ring, graded gravel; one pit per ~70 m³ of annual spill",
   "T1: 7.6–31 m³   T2: 58–238 m³   T3: 290–970 m³"],
  ["Recharge well","Direct recharge where the water table is shallower than 10 m","75 mm slotted uPVC to 8 m, gravel pack","Same as above, higher infiltration rate"],
  ["Kitchen garden supply","Irrigation and livestock water from the overflow","110 mm PVC to a 200 L drum","Garden productivity through the dry season"],
  ["Managed secondary source","The source households use when the tank is empty","Pond sand filter (coastal), shallow tubewell (Barind), tanker (haor) — identified and tested at design stage, not assumed","Keeps total service continuous"],
  ["Emergency reserve","Sealed volume held for cyclone shelter mode","14 days × users × 5 L","30 days of drinking water for 400 people at T3"]],
 widths=[3.2,5.2,4.8,4.0],fontsize=8.2)
d.p("The secondary source is listed as a design element, not an afterthought, for a specific reason: a rainwater system that has no "
    "defined fallback will be abandoned the first dry season it runs out. Identifying, testing and — where necessary — rehabilitating "
    "the fallback is part of the capital scope, and the community is told explicitly which months it will be relying on which source.")
d.pagebreak()

# ---------------- 9. TIER SPECIFICATIONS ----------------
d.h1("9.  Tier specifications and cost")
for key,label in [("T1","9.1  T1 — Household unit"),("T2","9.2  T2 — Cluster unit (10 households)")]:
    m=B[key]["meta"]
    d.h2(label)
    d.kv([("Storage",f"{m['volume']:,} litres, ferrocement, ID {m['dia']} m × {m['height']} m high"),
          ("Catchment",f"{m['catchment_m2']} m² of roof"),
          ("Users",f"{m['users']} people at 5 litres/person/day"),
          ("Performance","100% of potable demand met year-round in all five zones at P80 rainfall" if key=="T1" else "82–92% annual reliability; 146–183 of 243 dry-season days"),
          ("Core capital cost",f"{f(B[key]['core_total'])} BDT"),
          ("Cost per beneficiary",f"{f(B[key]['core_total']/m['users'])} BDT"),
          ("Cost per litre of storage",f"{B[key]['core_total']/m['volume']:.1f} BDT/L"),
          ("Dominant cost items","Storage 29%, labour 16%, catchment 14%")])

for key,label in [("T3","9.3  T3 — Institutional unit (school / cyclone shelter)")]:
    m=B["T3"]["meta"]
    d.h2(label)
    d.kv([("Storage","60,000 litres"),
          ("Construction options",f"Ferrocement: {f(B['T3']['core_total'])} BDT.  RCC: {f(B['T3rcc']['core_total'])} BDT."),
          ("Catchment","600 m² of roof"),
          ("Users","400 people (school population or shelter capacity)"),
          ("Performance","73–82% annual reliability at 1,000 L/day; plus 20 days of emergency reserve at 3,000 L/day shelter demand"),
          ("Core capital cost",f"{f(B['T3']['core_total'])} BDT (ferrocement) / {f(B['T3rcc']['core_total'])} BDT (RCC)"),
          ("Cost per beneficiary",f"{f(B['T3']['core_total']/400)} BDT (ferrocement) / {f(B['T3rcc']['core_total']/400)} BDT (RCC)")])
d.h3("Choosing between ferrocement and RCC at institutional scale")
d.table(["Criterion","Ferrocement","RCC"],
 [["Capital cost","Lower by roughly 300,000 BDT at 60,000 L","Higher"],
  ["Skill required","Trained ferrocement masons; sensitive to workmanship","Standard RCC contractors; more forgiving"],
  ["Debris impact (cyclone)","More vulnerable to puncturing and spalling","Significantly more robust — recommended for shelters"],
  ["Roof loading / access","Light; roof not trafficable","Roof slab can be designed for access and equipment"],
  ["Maintenance","Annual inspection of the lining; patch repairs easy","Minimal; long intervals between interventions"],
  ["Recommendation","Schools and institutions with a reliable local maintenance team","Cyclone shelters, and any institution where maintenance capacity is weak"]],
 widths=[4.2,6.0,6.6],fontsize=8.4)

d.h2("9.4  Cost summary across the three tiers")
rows=[]
for k in ["T1","T2","T3","T3rcc"]:
    m=B[k]["meta"]
    rows.append([m["name"] if k!="T3rcc" else "Institutional (RCC)",f"{m['volume']:,}",f(B[k]['core_total']),
                 m["users"],f(B[k]['core_total']/m['users']),f"{B[k]['core_total']/m['volume']:.1f}"])
d.table(["Tier","Storage (L)","Core capital (BDT)","Users","BDT / person","BDT / litre"],rows,
        widths=[5.0,2.4,3.2,1.8,2.4,2.4],fontsize=8.6)
d.p(f"A mixed programme of 60 household, 30 cluster and 10 institutional units reaches "
    f"{60*6+30*60+10*400:,} people for roughly "
    f"{f(60*B['T1']['core_total']+30*B['T2']['core_total']+10*B['T3rcc']['core_total'])} BDT — about "
    f"{f((60*B['T1']['core_total']+30*B['T2']['core_total']+10*B['T3rcc']['core_total'])/(60*6+30*60+10*400))} BDT per person. "
    "Full procurement quantities for that package are in Sheet 11 of the costing model.")
d.p("These are core-scope figures. Optional add-ons (solar pumping, roof extension, recharge wells) and alternatives (bought-in HDPE "
    "tanks) are priced separately in the model so that a programme can see the marginal cost of each decision.",size=9.6,italic=True)
d.pagebreak()

# ---------------- 10. DRAWINGS ----------------
d.h1("10.  Drawing register")
d.table(["Drawing","Title","Content"],
 [["BB-D-01","Integrated RWH — process schematic","The nine-stage train common to all tiers, with tier capacities annotated"],
  ["BB-D-02","T1 household tank — GA","Plan, section, unrolled wall armature detail, base/wall junction detail, construction notes"],
  ["BB-D-03","Catchment, first-flush and pre-filter","Roof-to-tank elevation, first-flush diverter section, three-stage pre-filter section, conveyance sizing table"],
  ["BB-D-04","T2 cluster unit","Plan with inlet ring and tapstand layout, tank section, cluster-specific management requirements"],
  ["BB-D-05","T3 institutional unit","Treatment train, tank section, cyclone shelter mode protocol, institutional duties and safeguards"],
  ["BB-D-06","Zone adaptations","Coastal, flood-plain and Barind panels, each with the specific detailing and a section sketch"],
  ["BB-D-07","Overflow, MAR recharge and access","Overflow hierarchy, soak pit and recharge well sections, confined-space entry rules"]],
 widths=[2.4,4.6,9.8],fontsize=8.4)

# ---------------- 11. LIMITATIONS ----------------
d.h1("11.  Limitations and assumptions to verify on site")
d.p("A design manual that does not state its limits is not usable in the field. The following must be verified for every site "
    "before construction, and the design adjusted if the answer is unfavourable.")
d.numbered([
 "Soil bearing capacity at the tank location. Assumed ≥ 50 kN/m². On soft or filled ground a raft or a wider footing is required.",
 "Flood level from the BWDB gauge for the specific union. Assumed values by zone are indicative only.",
 "Roof condition, material and actual plan area. Assumed 20 m² of sound GI, tile or asbestos. A damaged or thatched roof cannot be used without a liner.",
 "Roof structural capacity for the gutter and its water load, particularly on older timber purlins.",
 "Roof tenure. If the roof is not controlled by the household — a rented room, a shared landlord roof — the conveyance cannot be built there and an alternative catchment is needed.",
 "Local material prices. Rates in the costing model are 2026 market rates delivered to upazila; re-quote before tender.",
 "Availability of calcium hypochlorite and a supply chain to replenish it. A chlorination system with no consumable supply chain is worse than none, because it creates false confidence.",
 "The secondary source. It must exist, be tested, and be improved if necessary. This is the most frequently skipped step in RWH programming.",
 "Aquifer depth and permeability before specifying a recharge well. A recharge well in low-permeability clay is a hole in the ground.",
 "Local masonry skill. If no ferrocement-trained mason is available within the upazila, either train one or use the bought-in HDPE alternative priced in the model."])
d.h2("11.1  What this design deliberately does not do")
d.bullets(["It does not attempt to supply all domestic water. That would require twenty times the storage and would not be affordable.",
 "It does not treat heavily polluted roof runoff — roofs used for drying fish, or downwind of brick kilns, are excluded.",
 "It does not replace a community's obligation to maintain a secondary source.",
 "It does not claim institutional RWH is self-sufficient in the driest zones. It is one source in a package, and the manual says so."])
d.p("")
rule(d.d)
p=d.d.add_paragraph(); r=p.add_run("Borsha-Bandhu Technical Design Manual  ·  BB-TDM-01 Rev A  ·  20 November 2026  ·  "
  "Prepared for engineering review and field pilot. Design values to be verified per site before construction.")
r.font.size=Pt(8); r.font.color.rgb=GREY; r.italic=True
d.save("/home/user/borsha_bandhu/01_Technical_Design_Manual.docx")
print("saved doc1")
