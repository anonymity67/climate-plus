from svgkit import *
def draw(path):
    d=DWG(1500,1060,100,title="D-04  T2 CLUSTER UNIT — 30,000 L",no="BB-D-04")
    d.text(40,50,"T2 CLUSTER UNIT  —  30,000 L SHARED FERROCEMENT TANK",20,INK,bold=True)
    d.text(40,72,"Serves 10 households / 60 people, fed by 160 m² of aggregated roofs. Plan 1:100, section 1:50.",11,HID)

    # ============ PLAN ============
    d.text(60,112,"PLAN   (1:100)",12,RED,bold=True)
    cx,cy,r=270,370,195
    d.rect(60,180,420,380,fill="none",c=HID,sw=1,dash="6 4")
    d.text(66,196,"fence line, 16 m",8.5,HID)
    d.circle(cx,cy,r,fill="#f7f3ea",c=INK,sw=1.8)
    d.circle(cx,cy,r-6,fill=FILL_W,c=INK,sw=2)
    d.circle(cx,cy,62,fill="#ffffff",c=INK,sw=1.3,dash="5 3")
    d.text(cx,cy-4,"2 × Ø600",9,HID,"middle"); d.text(cx,cy+10,"manholes",9,HID,"middle")
    d.line(cx-215,cy,cx+215,cy,0.7,HID,"14 4 3 4"); d.line(cx,cy-215,cx,cy+215,0.7,HID,"14 4 3 4")
    # 4 inlets
    for ang in (0,90,180,270):
        import math
        a=math.radians(ang); x1=cx+(r+2)*math.cos(a); y1=cy+(r+2)*math.sin(a)
        x2=cx+(r+26)*math.cos(a); y2=cy+(r+26)*math.sin(a)
        d.line(x1,y1,x2,y2,7,"#cfd8dc"); d.line(x1,y1,x2,y2,1.2,INK)
        d.circle(x2,y2,9,fill="#fde7e4",c=RED,sw=1.5)
    d.text(cx,cy-r-42,"4 no. first-flush diverters + downpipes",8.5,RED,"middle")
    # tapstands
    for (tx,ty,lab) in [(cx-140,cy+238,"TAPSTAND 1"),(cx+140,cy+238,"TAPSTAND 2")]:
        d.rect(tx-40,ty,80,34,fill="#e8eef7",c=INK,sw=1.4)
        d.text(tx,ty+21,lab,8,INK,"middle")
        d.line(tx,ty,cx,cy+r,1.4,DIM,"4 3")
    d.rect(cx-48,cy+210,96,26,fill="#e8eef7",c=INK,sw=1.4)
    d.text(cx,cy+227,"potable point",8,INK,"middle")
    d.dimh(cx-r,cx+r,cy+316,"Ø3.90 m internal")
    d.text(cx,cy+346,"4 × Ø50 downpipes discharge into a common manifold",8.5,HID,"middle")

    # ============ SECTION ============
    d.text(600,112,"SECTION   (1:50)",12,RED,bold=True)
    S=100; sx=800; gl=760
    pt=gl-0.30*S; bt=pt-0.15*S; wt=bt-2.51*S; cv=wt-0.08*S
    ro,ri=195,192
    d.hatch(600,gl,470,30,"soil"); d.line(600,gl,1070,gl,1.6)
    # ring beam
    d.hatch(sx-205,pt-10,410,40,"conc")
    d.text(sx,gl+40,"RCC ring beam 300 × 400 with 2 × Ø12 continuous",8.5,INK,"middle")
    # walls
    d.hatch(sx-ro,wt,ro-ri,bt-wt,"conc"); d.hatch(sx+ri,wt,ro-ri,bt-wt,"conc")
    d.hatch(sx-ro,wt,2*ro,6,"conc") if False else None
    # base
    d.hatch(sx-ri,bt-15,2*ri-4,15,"conc")
    # cover
    d.hatch(sx-ro,cv,2*ro,wt-cv,"conc")
    d.rect(sx-92,cv,52,wt-cv,fill="#ffffff",c=INK,sw=1.2)
    d.rect(sx+40,cv,52,wt-cv,fill="#ffffff",c=INK,sw=1.2)
    # water
    wl=wt+20
    d.rect(sx-ri,wl,2*ri-4,bt-15-wl,fill="url(#hwater)",c="none",sw=0)
    d.line(sx-ri,wl,sx+ri,wl,1.4,"#5b8fc0")
    # ladder
    d.line(sx+150,cv,sx+150,wt+40,1.6,INK); d.line(sx+168,cv,sx+168,wt+40,1.6,INK)
    for k in range(0,8): d.line(sx+150,cv+16+k*22,sx+168,cv+16+k*22,1.2,INK)
    d.text(sx+178,wt+50,"SS ladder",8,HID)
    # dims
    d.dimv(cv,gl,1096,"3.34 m overall",9)
    d.dimv(wl,bt-15,1058,"2.51 m internal depth",9)
    d.dimh(sx-ro,sx+ro,gl+86,"Ø3.90 m internal")
    d.dimh(sx-205,sx+205,gl+126,"Ø4.10 m ring beam")
    # annotations
    d.leader(sx-ro-6,wl+30,sx-250,wl+6,"calmed inlet on a common manifold",8.5,GREEN,"end")
    d.leader(sx-ri+30,bt-8,sx-250,bt+70,"sump: base falls 1% to a lockable 75 mm drain valve",8.5,GREEN,"end")

    # ============ NOTES ============
    d.text(1130,520,"CLUSTER-SPECIFIC REQUIREMENTS",10,RED,bold=True)
    nt=["1.  Water is a common resource; the management rules matter as",
        "     much as the concrete. A WASH committee of 7 (≥ 4 women) is",
        "     formed before construction begins, not after.",
        "",
        "2.  Two caretakers are trained and paid a small stipend from a",
        "     water tariff of about 20–30 BDT per household per month.",
        "",
        "3.  The potable point is locked. The caretaker opens it morning",
        "     and evening; this protects the treated water and the filter",
        "     candles from misuse.",
        "",
        "4.  Conflict rule agreed in writing at handover: queue order,",
        "     priority for pregnant women, elderly and children, and a",
        "     penalty for washing clothes at the drinking tap.",
        "",
        "5.  Tank is cleaned twice a year (before and after monsoon) by",
        "     two trained people, never one alone, with the ladder and",
        "     a rope. Confined-space entry without a second person has",
        "     killed people in Bangladesh tanks.",
        "",
        "6.  Chlorine is stored locked, away from children, in a labelled",
        "     opaque container. Dosing chart is fixed inside the lid.",
        "",
        "7.  Test the tank water for E. coli three times a year. Record",
        "     it on the board next to the tapstand where everyone sees it."]
    for i,t in enumerate(nt): d.text(1130,544+i*15,t,8.3,INK)
    return d.save(path)
if __name__=="__main__": print(draw("/home/user/borsha_bandhu/drawings/D-04_T2_cluster_unit.svg"))
