import json
from docx.shared import Pt, Cm
from docxkit import *
B=json.load(open("bom.json"))
f=lambda n: f"{n:,.0f}"

d=Doc("Construction, Operation & Maintenance",
      "Field Manual and Water Safety Plan",
      [("Document","BB-COM-02  ·  Revision A  ·  20 November 2026"),
       ("For use by","Site engineers, mason teams, WASH committees, caretakers"),
       ("Covers","Tiers T1, T2 and T3 in all five climate zones"),
       ("Structure","Site readiness → construction sequence with hold points → commissioning → O&M calendar → water safety plan → disaster protocols")])
d.cover("BB-COM-02",
 "This is the manual that is actually used on site. It assumes the reader has the drawings, a trained mason, and a community that has "
 "already agreed where the tank will go. It sets out what must be true before work starts, the order in which to build, the four "
 "points at which work stops until an inspector signs it off, and what the household or committee must do every day, month, season "
 "and year afterwards to keep the water safe.",
 [("4","QC hold points"),("12","build steps"),("18","O&M tasks"),("0","compromises on the cover")])
d.h1("1.  Before anything is built — site readiness")
d.p("Most rainwater systems that fail in Bangladesh fail before the first bag of cement is opened. They are built on the wrong site, "
    "for the wrong household, without an agreement about who maintains them. This section exists to prevent that.")
d.h2("1.1  Site selection criteria")
d.p("All nine of the following must be satisfied. If any one is not, the site is changed or the design is adjusted — the answer is "
    "never to build it anyway and hope.")
d.table(["#","Criterion","Test to apply","If it fails"],
 [["1","Roof material is suitable","GI, tile, asbestos or concrete. Not thatch, not a roof used for drying fish or grain, not downwind of a brick kiln","Provide a separate sheet catchment, or exclude"],
  ["2","Roof area is adequate","Measure plan area, not slope area. ≥ 20 m² for T1, ≥ 30 m² in Zone D","Extend the catchment (priced as an option in the model)"],
  ["3","Roof is structurally sound","Gutter and full of water must not bend the purlins. Check for rot at the wall plate","Downgrade to a smaller gutter run or repair the roof first"],
  ["4","Household controls the roof","Owner-occupier, or written landlord permission","Find an alternative catchment or a different household"],
  ["5","Ground is firm and level","Test with a 20 mm rod: it should not sink under hand pressure. No organic or filled ground","Move the site, or cast a wider raft"],
  ["6","Tank sits ≥ 900 mm from the house wall","Measure","Move it. A tank against a wall traps damp and undermines the footing"],
  ["7","Site is above the flood line","Read the BWDB gauge, or ask the oldest residents for the highest flood","Raise the plinth (Zone C detailing)"],
  ["8","Sun exposure is manageable","Some shade is good; deep shade under a tree is not","Move away from the canopy — leaf load will block the gutter"],
  ["9","Household or committee has agreed to maintain it","Signed agreement, witnessed, with the O&M tasks read aloud","Do not build. An unmaintained tank is a mosquito farm"]],
 widths=[0.8,3.6,7.0,5.4],fontsize=8.2)

d.h2("1.2  Community agreement — read aloud and signed before construction")
d.p("For T1 this is a one-page agreement with the household. For T2 and T3 it is a signed minutes with the WASH committee, the "
    "school management committee or the shelter committee. It must cover, in plain Bengali:")
d.bullets(["Who owns the tank and who may draw from it.",
 "Who holds the key to the potable point, and at what hours it is open.",
 "Who cleans the tank, how often, and who pays them.",
 "Who buys chlorine, from where, and out of which fund.",
 "The queue rules: priority for pregnant women, elderly people, children and people with disabilities.",
 "What happens when the tank runs dry — which secondary source, and who organises it.",
 "That no one enters the tank alone, ever, for any reason."])
d.callout("Why the agreement comes first",
  "A tank is a shared asset the moment it is built, even in a single compound. Programmes that skip the agreement spend the next "
  "three years mediating disputes about a 5,000 litre jar. It takes one hour to prevent that.")

d.h2("1.3  Material quality checks on delivery")
d.table(["Material","Check","Reject if"],
 [["Cement","Bag weight, date of manufacture, no lumps, cool to the touch","More than 90 days old, lumpy, or the bag has been damp"],
  ["Sand","Grab a handful, squeeze, release. It should hold shape faintly then crumble. No salt taste, no clay smell","Salty, silty, or contains organic matter. Do the bottle test: 50 mm sand in water, shake, let stand — silt layer must be < 5%"],
  ["Aggregate / brick chips","12 mm downgraded, washed, free of dust","Contains soil or unburnt brick"],
  ["Chicken wire","Galvanised, 20 gauge, 25 mm mesh. Bend it: it should spring back","Rusty, brittle, or non-galvanised (bright steel)"],
  ["Weld mesh","25 × 25 mm, 3 mm wire, galvanised","Rust or loose welds"],
  ["MS rod, 8 mm","Diameter check with a calliper; surface free of heavy scale","Under gauge or heavily corroded"],
  ["uPVC pipe","Class 5, UV-stabilised, correct diameter printed on the wall","Rigid unplasticised pipe UV-degraded and chalky"],
  ["Calcium hypochlorite","Sealed container, 65% available chlorine stated, no clumping","Container open, damp, or unlabelled"]],
 widths=[3.2,8.0,5.8],fontsize=8.3)
d.pagebreak()

d.h1("2.  Construction sequence")
d.p("Twelve steps in fixed order. Work does not proceed past a hold point until the inspecting engineer has signed the checklist. "
    "The four hold points exist because they catch the four failure modes that actually occur: a bad base, a thin shell, a shell "
    "that was never cured, and a tank that leaks before it is handed over.")
d.table(["Step","Activity","Duration (T1 / T2 / T3)","Hold point"],
 [["1","Set out and excavate; blind the base with 50 mm of lean concrete","1 / 2 / 4 days","—"],
  ["2","Cast the base slab; cast the brick plinth or RCC ring beam","2 / 4 / 8 days","HP1  Base and plinth inspection"],
  ["3","Erect the armature: vertical rods, horizontal rings, tied, then weld mesh, then two layers of chicken wire","1 / 3 / 8 days","HP2  Armature inspection"],
  ["4","First mortar coat to the outside; work from the outside in","2 / 5 / 12 days","—"],
  ["5","Second mortar coat to the inside; rod and compact; fillet the base junction","2 / 5 / 12 days","HP3  Shell thickness and junction"],
  ["6","Cure wet for 7 days — sacks, plastic sheet, or intermittent wetting","7 / 7 / 7 days","HP4a  Curing record"],
  ["7","Cast the cover and manhole separately; cure","3 / 3 / 5 days","—"],
  ["8","Fit pipework: inlet, calmed inlet, overflow, sump drain, draw-off, tapstand","1 / 3 / 6 days","—"],
  ["9","Fit the cover with sealant and anchor bolts; fit insect screens and vents","1 / 2 / 3 days","HP4b  Cover security"],
  ["10","Fit the first-flush diverter and pre-filter; connect the gutter and downpipes","2 / 4 / 8 days","—"],
  ["11","Fill test, disinfect, water quality sample to the laboratory","3 / 5 / 10 days","HP4  Commissioning sign-off"],
  ["12","Handover: training, agreement, signage, O&M kit handed over","1 / 2 / 3 days","—"]],
 widths=[1.0,7.4,3.4,4.4],fontsize=8.2)

d.h2("2.1  Hold point checklists")
d.h3("HP1 — Base and plinth")
d.bullets(["Base slab is level to within 5 mm across the full diameter. Test with a straightedge and a spirit level.",
 "Base is square, true and the correct diameter. Measure two diameters at right angles.",
 "No voids or honeycombing. Tap the surface: a hollow sound means a void and the slab is re-cast.",
 "Brick plinth is plumb and the mortar joints are full. Fill any voids before HP2.",
 "If in a flood zone, the plinth height is confirmed against the flood level, measured, and recorded."])
d.h3("HP2 — Armature")
d.bullets(["Rod spacing 150 mm in both directions, measured at three heights. Tolerance ±15 mm.",
 "All rod intersections tied with galvanised wire. A rod that clinks when tapped is not tied.",
 "Two complete layers of chicken wire with 50% overlap, wired at 150 mm centres. No bare patches at all — a bare patch is where the shell will crack.",
 "Weld mesh in place and tied down. Rods do not protrude more than 20 mm through the finished surface.",
 "Base-to-wall rods turned 90° into the slab and tied. This joint is the single most common point of failure."])
d.h3("HP3 — Shell")
d.bullets(["Wall thickness measured with a probe at 8 points around the circumference, at mid-height. 25 mm ± 5 mm (32 mm for T2, 45 mm for T3).",
 "No dry patches, no sand-only areas, no visible mesh. Any visible wire is a reject — it will rust and split the shell.",
 "Base fillet is in place and smooth. There is no sharp internal corner.",
 "Inside surface is dense and has been rodded, not just trowelled. Trowelling alone leaves a porous skin.",
 "The sump falls to the drain valve. Test with a bucket of water: it should run to the drain, not stand."])
d.h3("HP4 — Commissioning")
d.bullets(["Curing record shows 7 days of continuous moisture. Photograph or witness signature per day.",
 "Fill test passed: fill, mark the level, hold 24 hours, top up and measure. Loss must be less than 1% of capacity.",
 "Cover is in place, sealed, bolted, lockable, and the insect screens are intact.",
 "First-flush diverter empties itself and re-arms — test it with a bucket poured into the gutter.",
 "Free chlorine residual 0.2–0.5 mg/L at the furthest tap, measured with a DPD tablet in front of the household or committee.",
 "Bacteriological sample sent to a DPHE or ICDDR,B laboratory, and the result recorded before handover.",
 "Household or committee can demonstrate: drawing water through the tap, resetting the diverter, and reading the dosing chart."])
d.pagebreak()

d.h1("3.  Ferrocement technique — the parts that go wrong")
d.p("Ferrocement is not difficult, but it is unforgiving of shortcuts. The three things that decide whether a shell lasts twenty years "
    "or two are the mortar mix, the way it is applied, and the cure.")
d.h2("3.1  Mortar")
d.kv([("Mix ratio","1 part cement : 2 parts sand by volume. Not 1:3 — a lean mix is porous and will leak."),
      ("Water","Just enough to make a stiff mix that holds on a trowel held vertically. Roughly 0.4–0.45 water:cement ratio. If it slides off the trowel, it is too wet."),
      ("Additive","Integral waterproofing compound at 1% of cement mass, mixed into the gauging water, never sprinkled dry."),
      ("Mixing","On a clean hard surface or in a mixer. Dry-mix cement and sand until the colour is uniform, then add water. Never add water to a mix that has begun to set."),
      ("Pot life","Use within 30 minutes of adding water. Discard anything older. In Bangladeshi heat, mix in small batches.")])
d.h2("3.2  Application")
d.numbered(["Wet the armature first. Dry mesh pulls the water out of the mortar and leaves a weak, dusty layer.",
 "Apply the first coat from the outside, pressing mortar through the mesh with a gloved hand or a steel float. Work in small areas.",
 "Do not build up thickness in one pass. Two passes per face, each about 12 mm, scratching the first pass to give a key.",
 "Compact with a rod or a float until water sheens on the surface. This is what closes the pores.",
 "Apply the base fillet while the wall is still green, so it bonds as one material rather than sitting on a cold joint.",
 "Finish the inside with a steel float. A wooden float leaves a surface that traps biofilm."])
d.h2("3.3  Curing")
d.p("Seven days wet. Not damp, not 'we splashed it once a day' — wet. Cover the shell with wet sacks or plastic sheeting and keep it "
    "wet, or set up a drip. If the shell dries white before seven days, the cure has failed and the shell is more likely to crack.")
d.callout("The cure is where field teams cut corners, and where tanks fail",
  "A tank that is cured properly for seven days will hold water for twenty years with a patch repair or two. A tank that is cured "
  "for two days will develop hairline cracks within a season, leak, and be abandoned. There is no later repair that fully recovers "
  "an uncured shell. Budget the seven days in the work plan and pay the mason for them.")
d.h2("3.4  Cover — the most-skipped item, and the most important")
d.p("The cover is not a lid. It is the barrier that keeps light, insects, rodents, hands and airborne dust out of the water. An "
    "uncovered tank grows algae within weeks and breeds Aedes aegypti — the dengue mosquito — which is a direct public health harm "
    "caused by the intervention. Covers are cast separately, cured, sealed with a flexible food-grade sealant, and bolted down.")
d.table(["Cover requirement","Specification","Do not accept"],
 [["Material","Precast RCC, 65 mm, with weld mesh","Timber, GI sheet, cloth, or a loose concrete slab"],
  ["Manhole","Ø600, hinged, lockable, insect-screened","An open hole, or a slab you have to lift off completely"],
  ["Seal","Flexible food-grade sealant on a clean dry joint","Cement mortar alone — it cracks and the cover lifts in wind"],
  ["Anchorage","4 × M8 minimum stainless bolts, or 2 tie-down straps","Gravity alone. It will lift in a cyclone"],
  ["Vent","Ø75 goose-neck with 1 mm mesh","A gap under the cover"]],
 widths=[3.4,6.8,6.8],fontsize=8.4)
d.pagebreak()

d.h1("4.  Commissioning and handover")
d.h2("4.1  Testing")
d.table(["Test","Method","Pass criterion","If it fails"],
 [["Structural fill","Fill to overflow, hold 24 h","No movement, no seepage at the base","Drain, investigate the base junction, re-render"],
  ["Watertightness","Fill, mark, hold 24 h, top up, measure the top-up volume","Loss < 1% of capacity","Re-render the inside; re-test"],
  ["Diverter function","Pour 40 L into the gutter at a steady rate","Chamber fills, seals, then drains fully within 15 min","Clean the bleed hole; check the float seat"],
  ["Filter flow","Time to fill a 10 L container at the pre-filter outlet","Within the design range for the unit","Backwash; check media is not compacted"],
  ["Chlorine residual","DPD tablet at the furthest tap","0.2–0.5 mg/L","Adjust dose, re-test after 30 min contact"],
  ["Bacteriological","Sterile sample to a DPHE or ICDDR,B laboratory","E. coli 0/100 mL","Re-disinfect, find and fix the contamination route, re-test before use"]],
 widths=[2.8,5.6,4.4,4.6],fontsize=8.4)
d.h2("4.2  Handover package")
d.p("Handover is not complete until every item on this list is physically in the hands of the household or committee, and they can "
    "demonstrate each one.")
d.bullets(["Signed agreement, in Bengali, with the O&M tasks and the queue rules.",
 "Dosing chart, laminated, fixed inside the tank cover and beside the tapstand.",
 "O&M kit: brush on a long handle, 1 kg calcium hypochlorite, DPD test kit, spare diverter float, spare insect screen, a length of rope.",
 "The tank log book: a simple exercise book with columns for date, task, chlorine test reading and signature.",
 "Contact numbers for the mason and the supervising organisation, on the signage board.",
 "A demonstration: the household draws water, resets the diverter, cleans the pre-filter, and reads a chlorine test — all unaided."])
d.h2("4.3  Training — four sessions, each under 90 minutes")
d.table(["Session","Audience","Content","Competency test"],
 [["1  Why and what","Household / committee","Where water comes from, why 5 lpcd, what the tank does and does not do, the agreement","Can explain the service level and the queue rules in their own words"],
  ["2  Using it","All users","Drawing water, keeping the cover closed, not putting hands or ropes in the tank, reporting problems","Demonstrates drawing water and locking the cover"],
  ["3  Keeping it safe","Caretaker(s) / household","Dosing, testing residual chlorine, cleaning the pre-filter, resetting the diverter","Correctly doses, tests and reads chlorine, unaided"],
  ["4  Keeping it working","Committee / household head","Seasonal tasks, tank cleaning with the two-person rule, the O&M fund, disaster protocol","Walks through the O&M calendar; knows the disaster trigger"]],
 widths=[3.0,3.2,7.2,4.0],fontsize=8.3)
d.pagebreak()

d.h1("5.  Operation and maintenance calendar")
d.p("Eighteen tasks, scheduled by frequency. The household or caretaker version of this table is printed, laminated and fixed "
    "beside the tapstand. A task that is not on the calendar does not happen.")
d.table(["Frequency","Task","Who","Time","Record"],
 [["Every day","Check the tank has water; confirm the cover is closed and locked","User","1 min","—"],
  ["Every day","Draw drinking water through the tap only; never dip a container","User","—","—"],
  ["Weekly","Test free chlorine residual at the tap and dose if below 0.2 mg/L","Caretaker","5 min","Log book"],
  ["Weekly","Clear leaves and debris from the gutter and leaf screen","Caretaker / household","10 min","—"],
  ["Weekly","Check the first-flush diverter emptied after the last rain","Caretaker","2 min","—"],
  ["Weekly","Check the potable point filter still flows","Caretaker","2 min","—"],
  ["Monthly","Backwash the pre-filter: open the drain, run 10 L to waste","Caretaker","15 min","Log book"],
  ["Monthly","Inspect the cover seal, bolts and insect screens; repair","Caretaker","15 min","Log book"],
  ["Monthly","Check tapstand apron and drainage — no ponding near the base","Caretaker","10 min","—"],
  ["Monthly","Inspect the tank exterior for cracks, staining or efflorescence","Caretaker","10 min","Log book"],
  ["3-monthly","Scrape the top 50 mm of the slow sand filter (T3); re-top with clean sand","Trained operator","1 h","Log book"],
  ["3-monthly","Bacteriological sample to the laboratory (T2 and T3)","Committee","—","Lab report"],
  ["6-monthly","Replace charcoal and the top 50 mm of sand in the pre-filter","Caretaker","30 min","Log book"],
  ["6-monthly","Replace ceramic candle filters in the potable point","Caretaker","30 min","Log book"],
  ["Twice a year","Full tank clean: before and after the monsoon, using the two-person rule","2 trained people","2 h","Log book"],
  ["Twice a year","De-silt the recharge pit","Community labour","1 h","—"],
  ["Annually","Inspect and patch the internal lining; re-epoxy if the coating has broken down","Mason","1 day","Log book"],
  ["Annually","Review the O&M fund balance and the water tariff","Committee","1 h","Minutes"]],
 widths=[2.4,6.6,2.8,1.8,2.4],fontsize=8.0)

d.h2("5.1  Tank cleaning — the procedure, not the idea")
d.numbered(["Two people minimum, plus a third outside holding the rope. No exceptions, no 'just quickly'.",
 "Drain the tank to 200 mm through the drain valve the evening before.",
 "Open the lid and let it vent for 15 minutes before anyone leans over it.",
 "One person on the ladder lashes it at the top; the second person stays at the top opening, above the tank, never inside.",
 "Scrub the walls and base with a long-handled brush and clean water. Do not use detergent or bleach inside the tank.",
 "Scoop the sludge out with a plastic container on a rope. Never a metal scoop — it scores the lining.",
 "Rinse, refill, and dose with chlorine at 5 mg/L. Hold for 12 hours, drain, then refill for service.",
 "Record the date, who did it, and anything unusual in the log book."])
d.callout("Confined space — the rule that has no exception",
  "Nobody enters a water tank alone. Deaths in Bangladeshi tanks are usually from oxygen displacement or hydrogen sulphide, not "
  "drowning, and they happen to people who thought the tank was just a tank. If the cleaning genuinely needs someone inside, drain "
  "it first. A tank can always be refilled; a person cannot.")
d.pagebreak()

d.h1("6.  Water safety plan")
d.p("A short, working water safety plan: for each hazard, the control that prevents it, how the control is monitored, and what is "
    "done when the control has failed. This is the version that gets laminated and hung up, not the 60-page one that stays in an office.")
d.table(["Hazard","Where it enters","Control","Monitoring","Corrective action"],
 [["Animal and bird faeces on the roof","Catchment","First-flush diverter, 1.5 mm","Weekly check that the diverter empties","Reset or repair the diverter; re-chlorinate the tank"],
  ["Leaves and debris","Gutter","Leaf screen, weekly clearing","Weekly visual","Clear; flush the gutter"],
  ["Insect breeding","Storage","Sealed cover, insect-screened vents","Weekly visual of cover and screens","Repair immediately; investigate any larvae"],
  ["Hands, ropes, buckets in the tank","Storage and draw-off","Lockable cover; draw only through taps","Weekly visual; user reports","Re-disinfect; re-train; repair the lock"],
  ["Algal growth","Storage","Light-proof cover","Monthly internal inspection","Clean and re-disinfect; fix the light leak"],
  ["Biofilm in the filter","Pre-treatment","Monthly backwash; 6-monthly media change","Monthly flow check; log book","Backwash or replace media"],
  ["Inadequate chlorination","Disinfection","Dose set by residual test, not by rule","Weekly DPD test","Re-dose to 0.5 mg/L, hold 30 min, re-test"],
  ["Chlorine supply runs out","Disinfection","Committee buys 6 months of stock","Monthly stock check","Buy locally; if unavailable, boil water until restocked and record it"],
  ["Backflow of floodwater","Overflow pipe","Flap valve; overflow above flood level","Before each monsoon","Refit or replace the valve; do not use the water until tested"],
  ["Latrine or livestock close to the tapstand","Distribution","10 m separation, apron and drainage","At design stage and annually","Relocate the latrine or the tapstand"],
  ["Sediment resuspension","Storage","Calmed inlet; annual cleaning","Annual cleaning","Clean; consider a floating intake"],
  ["Contamination during household storage","Household","Safe storage container with a lid and a tap","Household survey","Provide a safe container; re-train"]],
 widths=[3.4,2.4,4.2,3.2,4.2],fontsize=7.9)
d.pagebreak()

d.h1("7.  Disaster protocols")
d.p("These are the actions that turn the system from a water supply into a disaster asset. They are triggered by a named event, not "
    "by judgement in the moment.")
d.h2("7.1  Cyclone — trigger: signal 3 hoisted, or 48 hours before expected landfall")
d.table(["When","Action","Who"],
 [["Signal raised (48 h)","Fill the tank to capacity from pre-landfall rain; if below 70%, top up by hand pump. Seal the emergency reserve valve.","Committee"],
  ["Signal 3","Bolt all manholes. Lash the tapstands. Remove the ladder. Secure loose pipework and the pre-filter lid.","Caretaker"],
  ["Landfall","No action. Stay in the shelter.","—"],
  ["First 24 h after","Inspect for structural damage before drawing water. Check the cover is intact and the tank is not contaminated. Do not open if the cover is broken until re-tested.","Committee + engineer"],
  ["First 72 h","Drinking and cooking only, 5 L/person/day. Hygiene water from another source.","Committee"],
  ["Day 4 onward","If relief water arrives, keep the tank as the fallback. Re-test before reopening fully.","Committee"],
  ["Within 2 weeks","Full inspection, repair, re-chlorinate, re-test. Record on the functionality register.","Engineer"]],
 widths=[3.4,9.0,4.6],fontsize=8.3)
d.h2("7.2  Flood — trigger: BWDB forecast of the river reaching the danger level")
d.table(["When","Action","Who"],
 [["72 h before crest","Fill the tank. A full tank resists buoyancy and becomes the settlement's water point.","Committee"],
  ["48 h before","Close the backwater flap valve. Move the pre-filter and loose items above flood level. Photograph the site.","Caretaker"],
  ["During inundation","Access only by boat. Do not draw water if the tapstand is submerged — use a container filled before the flood.","Committee"],
  ["After the water recedes","Do not use the tank until the outside has been washed, the cover inspected and the water tested. Re-chlorinate.","Committee + engineer"],
  ["Within 1 week","Check the plinth and foundation for scour. Check for cracking at the base junction.","Engineer"]],
 widths=[3.4,9.0,4.6],fontsize=8.3)
d.h2("7.3  Drought — trigger: tank empty 30 days earlier than the seasonal norm")
d.table(["When","Action","Who"],
 [["Early warning (Feb)","Activate the secondary source. Confirm it is working before the tank empties, not after.","Committee"],
  ["Tank below 25%","Ration to drinking only. Stop all garden and livestock use.","Committee"],
  ["Tank empty","Switch to the defined secondary source. Record the date — it is the key monitoring indicator.","Committee"],
  ["Post-season","Review why it emptied early: a leak, a blocked gutter, an unusually dry year, or a design fault. Fix the cause before the next monsoon.","Engineer"]],
 widths=[3.4,9.0,4.6],fontsize=8.3)
d.pagebreak()

d.h1("8.  Troubleshooting")
d.table(["Symptom","Likely cause","Fix"],
 [["Tank never fills","Blocked gutter or leaf screen; disconnected downpipe; tank leaking","Trace the flow with a bucket of water at each joint"],
  ["Tank fills but empties overnight","Leaking base or sump drain left open; draw-off leaking","Close the drain; inspect the base junction"],
  ["Water is cloudy","First flush not working; pre-filter saturated; sediment resuspended","Reset the diverter; change media; fit a calmed inlet"],
  ["Water smells or tastes unpleasant","Anaerobic conditions from sediment; algal growth; too much chlorine","Clean the tank; check the cover for light leaks; re-check the dose"],
  ["Chlorine residual will not hold","High turbidity consuming chlorine; organic load","Fix the pre-filter first; then re-dose"],
  ["Mosquito larvae in the tank","Cover not sealed; broken insect screen","Repair immediately; this is a notifiable defect"],
  ["Cracks in the shell","Poor cure; base joint failure; ground settlement; impact","Patch with 1:2 mortar after cutting back to sound material; investigate the cause"],
  ["White powder on the outside","Efflorescence — water passing through the shell","Drain, re-render the inside, re-test"],
  ["Gutter overflows at the wall","Undersized gutter or downpipe; blocked downpipe","Clear; if it recurs, upsize per the sizing table on D-03"],
  ["Tapstand surrounded by mud","Apron damaged; drainage blocked","Repair the apron; clear the soakaway"],
  ["Water tastes salty","Salt spray ingress through a broken cover or vent; contamination from a flood","Inspect the cover and vents; re-test chloride; do not drink until re-tested"]],
 widths=[3.8,5.4,7.8],fontsize=8.3)
d.h2("8.1  When to call an engineer, not a caretaker")
d.bullets(["Any structural crack longer than 300 mm, or any crack that runs through the wall thickness.",
 "Movement of the tank, or a gap opening between the plinth and the base.",
 "The cover cannot be secured, or an anchor has pulled out.",
 "Bacteriological contamination that persists after two rounds of re-disinfection.",
 "Flood water reached the tapstand or the overflow, regardless of appearance."])
d.p("")
rule(d.d)
p=d.d.add_paragraph(); r=p.add_run("Borsha-Bandhu Construction, Operation & Maintenance Manual  ·  BB-COM-02 Rev A  ·  20 November 2026")
r.font.size=Pt(8); r.font.color.rgb=GREY; r.italic=True
d.save("/home/user/borsha_bandhu/02_Construction_OM_and_Water_Safety_Plan.docx")
print("saved doc2")
