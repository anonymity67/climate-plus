from rwh_model import simulate as SIM
# ============ 5-8. BoM SHEETS ============
def bom_sheet(title, key, note):
    d=B[key]; m=d["meta"]
    ws=wb.create_sheet(title); widths(ws,[4,20,40,46,9,9,11,13,10])
    ws["B2"]=f"{m['code']} — {m['name'].upper()}   |   {m['volume']:,} L storage".replace("  "," "); ws["B2"].font=TITLE
    ws["B3"]=note; ws["B3"].font=Font(size=9,italic=True,color="666666")
    ws["B4"]=f"Tank ID {m['dia']} m x {m['height']} m high  ·  Catchment {m['catchment_m2']} m2  ·  Serves {m['users']} people @ {m['demand_lpd']} L/day"
    ws["B4"].font=Font(size=10,bold=True,color=TEAL)
    hdr(ws,6,["#","Category","Item","Specification","Unit","Qty","Rate (BDT)","Amount (BDT)","Scope"])
    r=7; n=0; cat=None
    for it in d["items"]:
        if it["cat"]!=cat:
            cat=it["cat"]
            ws.cell(row=r,column=2,value=cat).font=Font(bold=True,size=10,color="FFFFFF")
            for c in range(1,10): ws.cell(row=r,column=c).fill=PatternFill("solid",fgColor=TEAL)
            ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=9); r+=1
        n+=1
        sc = "Optional" if it["optional"] else ("Alternative" if it.get("alt") else "Core")
        vals=[n,it["cat"],it["item"],it["spec"],it["unit"],it["qty"],it["rate"],it["amount"],sc]
        for c,v in enumerate(vals,1):
            cell=ws.cell(row=r,column=c,value=v); cell.border=BOX; cell.font=Font(size=9)
            if c in (6,7,8): cell.number_format='#,##0.00' if c==6 else '#,##0'
            if c==9: cell.alignment=Alignment(horizontal="center")
        if sc!="Core":
            for c in range(1,10): ws.cell(row=r,column=c).fill=PatternFill("solid",fgColor="FFF8E1")
        r+=1
    r+=1
    for lab,val,color in [("CORE SCOPE TOTAL",d["core_total"],NAVY),("Optional add-ons",d["optional_total"],"8D6E63"),
                          ("FULL PACKAGE (core + optional)",d["full_total"],TEAL)]:
        ws.cell(row=r,column=3,value=lab).font=Font(bold=True,size=10,color=color)
        ws.merge_cells(start_row=r,start_column=3,end_row=r,end_column=7)
        ws.cell(row=r,column=3).alignment=Alignment(horizontal="right")
        c=ws.cell(row=r,column=8,value=val); c.number_format='#,##0'; c.font=Font(bold=True,size=11,color=color); c.border=BOX
        c.fill=PatternFill("solid",fgColor=SAND); r+=1
    r+=1
    ws.cell(row=r,column=3,value="Cost per beneficiary").font=H2
    ws.cell(row=r,column=8,value=round(d["core_total"]/m["users"])).number_format='#,##0'; r+=1
    ws.cell(row=r,column=3,value="Cost per litre of storage").font=H2
    ws.cell(row=r,column=8,value=round(d["core_total"]/m["volume"],1)).number_format='0.0'; r+=1
    ws.freeze_panes="A7"
    return d

bom_sheet("5. BoM Household","T1","Household unit. 5,000 L ferrocement tank, 20 m2 roof, 6 users. Sized for 100% of potable demand year-round at P80 rainfall in all five zones.")
bom_sheet("6. BoM Cluster","T2","Cluster unit for 10 households. 30,000 L ferrocement tank fed by 160 m2 of aggregated roofs, with a communal tapstand and caretaker-managed potable point.")
bom_sheet("7. BoM Institution A","T3","Institutional unit, FERROCEMENT option. 60,000 L, 600 m2 roof, 400 users. Lowest capital cost; requires trained masons and periodic inspection.")
bom_sheet("8. BoM Institution B","T3rcc","Institutional unit, RCC option. Same duty, reinforced concrete. Recommended for cyclone shelters and where maintenance capacity is weak.")

# ============ 9. COST SUMMARY ============
ws=wb.create_sheet("9. Cost Summary"); widths(ws,[4,34,15,15,15,15,6,44])
ws["B2"]="COST SUMMARY & COMPARISON"; ws["B2"].font=TITLE
ws["B3"]="Compare the three tiers on capital cost and on cost of water actually delivered."; ws["B3"].font=Font(size=9,italic=True,color="666666")
hdr(ws,5,["","Tier","Storage (L)","Core capital (BDT)","Users served","Cost / beneficiary","","Comment"])
tiers=[("T1","T1 Household",B["T1"]),("T2","T2 Cluster (10 HH)",B["T2"]),("T3","T3 Institution — ferrocement",B["T3"]),("T3rcc","T3 Institution — RCC",B["T3rcc"])]
r=6
for _,lab,d in tiers:
    m=d["meta"]
    vals=[lab,m["volume"],d["core_total"],m["users"],round(d["core_total"]/m["users"])]
    ws.cell(row=r,column=2,value=vals[0]).font=Font(bold=True,size=10)
    ws.cell(row=r,column=3,value=vals[1]).number_format='#,##0'
    ws.cell(row=r,column=4,value=vals[2]).number_format='#,##0'
    ws.cell(row=r,column=5,value=vals[3]).number_format='#,##0'
    ws.cell(row=r,column=6,value=vals[4]).number_format='#,##0'
    for c in range(2,7): ws.cell(row=r,column=c).border=BOX; ws.cell(row=r,column=c).font=Font(bold=True,size=10)
    r+=1
r+=1
section(ws,r,"COST OF WATER DELIVERED — the number that decides which tier to build",8); r+=1
hdr(ws,r,["","Tier","Annual reliability (Zone A)","Litres delivered / yr","Litres delivered / 20 yr","Capital cost / 1,000 L","","Interpretation"]); r+=1
interp={"T1":"Highest unit cost of water; justified because it reaches dispersed households with no shared infrastructure.",
        "T2":"Best balance for hamlets that already share a tube-well or a courtyard.",
        "T3":"Cheapest water per litre by a wide margin — plus a public building gains a disaster refuge."}
for k,lab,d in tiers:
    m=d["meta"]
    rel=SIM([x*DESIGN_FACTOR for x in ZONES["A"]["m"]],m["catchment_m2"],m["volume"],m["demand_lpd"])["rel"]
    vol=m["demand_lpd"]*365*rel
    ws.cell(row=r,column=2,value=lab).font=Font(bold=True,size=10)
    ws.cell(row=r,column=3,value=rel).number_format='0.0%'
    ws.cell(row=r,column=4,value=round(vol)).number_format='#,##0'
    ws.cell(row=r,column=5,value=round(vol*20)).number_format='#,##0'
    ws.cell(row=r,column=6,value=d["core_total"]/(vol*20)*1000).number_format='0.00'
    ws.cell(row=r,column=8,value=interp.get(k,interp["T3"])).font=Font(size=9,italic=True)
    for c in range(2,7): ws.cell(row=r,column=c).border=BOX
    r+=1
r+=1
ws.cell(row=r,column=2,value="Note: Zone A is the least favourable zone. In Zones B, C and E the same asset delivers materially more water, so cost per litre falls further.").font=Font(size=9,italic=True,color="666666")

# ============ 10. LIFECYCLE ============
ws=wb.create_sheet("10. Lifecycle Cost"); widths(ws,[4,40,16,16,16,16,6,38])
ws["B2"]="20-YEAR WHOLE-LIFE COST (Life-Cycle Cost Analysis)"; ws["B2"].font=TITLE
ws["B3"]="Capital cost is roughly half the story. This sheet discounts every future cost to present value."; ws["B3"].font=Font(size=9,italic=True,color="666666")
r=5
ws.cell(row=r,column=2,value="ASSUMPTIONS").font=SUB; r+=1
assum=[("Discount rate (real)",0.08),("Analysis period (years)",20),("Annual routine O&M (% of core capital)",0.015),
       ("Chlorine + consumables (BDT/yr)",None),("Filter media renewal every N years",5),("Media renewal cost (% of capital)",0.04),
       ("Gutter / downpipe renewal every N years",8),("Gutter renewal cost (% of capital)",0.09),
       ("Epoxy relining every N years",10),("Relining cost (% of capital)",0.05)]
for lab,val in assum:
    ws.cell(row=r,column=2,value=lab).font=BODY
    if val is not None:
        c=ws.cell(row=r,column=3,value=val); c.fill=PatternFill("solid",fgColor="FFF2CC"); c.font=Font(bold=True,size=10); c.border=BOX
        c.number_format='0.0%' if isinstance(val,float) and val<1 else '0'
    r+=1
DR=0.08; NPER=20; MEDN=5; GTN=8; EPN=10
r+=1
section(ws,r,"WHOLE-LIFE COST BY TIER",8); r+=1
hdr(ws,r,["","Tier","Capital (core)","PV of O&M","PV of renewals","Whole-life PV (20 yr)","","Whole-life cost per beneficiary"]); r+=1
chlor={"T1":900,"T2":3200,"T3":11000,"T3rcc":11000}
for k,lab,d in tiers:
    m=d["meta"]; C=d["core_total"]
    om_annual=C*0.015+chlor[k]
    pv_om=om_annual*(1-(1+DR)**-NPER)/DR
    pv_ren=0
    for n,pct in [(MEDN,0.04),(GTN,0.09),(EPN,0.05)]:
        t=n
        while t<=NPER:
            pv_ren+=C*pct/(1+DR)**t; t+=n
    total=C+pv_om+pv_ren
    ws.cell(row=r,column=2,value=lab).font=Font(bold=True,size=10)
    for c,v,f in [(3,C,'#,##0'),(4,pv_om,'#,##0'),(5,pv_ren,'#,##0'),(6,total,'#,##0')]:
        cell=ws.cell(row=r,column=c,value=round(v)); cell.number_format=f; cell.border=BOX
        if c==6: cell.font=Font(bold=True,size=10,color=TEAL); cell.fill=PatternFill("solid",fgColor=LIGHT)
    ws.cell(row=r,column=8,value=round(total/m["users"])).number_format='#,##0'
    ws.cell(row=r,column=8).font=Font(bold=True,size=10)
    r+=1
r+=1
ws.cell(row=r,column=2,value="Whole-life PV per beneficiary per year").font=H2
r+=1
for k,lab,d in tiers:
    m=d["meta"]; C=d["core_total"]; om_annual=C*0.015+chlor[k]
    pv_om=om_annual*(1-(1+DR)**-NPER)/DR; pv_ren=0
    for n,pct in [(5,0.04),(8,0.09),(10,0.05)]:
        t=n
        while t<=NPER: pv_ren+=C*pct/(1+DR)**t; t+=n
    tot=C+pv_om+pv_ren
    ws.cell(row=r,column=2,value=lab).font=BODY
    ws.cell(row=r,column=3,value=round(tot/m["users"]/NPER)).number_format='#,##0'
    ws.cell(row=r,column=3).font=Font(bold=True,size=10)
    r+=1
r+=1
ws.cell(row=r,column=2,value="For comparison: a household buying 20 L/day of safe water at 2 BDT/L for 20 years spends 292,000 BDT — and still does not own an asset. RWH pays back in roughly 6-8 years at that price.").font=Font(size=9,italic=True,color=ACC)

# ============ 11. PROCUREMENT ============
ws=wb.create_sheet("11. Procurement"); widths(ws,[4,44,46,10,14,14,6,34])
ws["B2"]="PROCUREMENT SCHEDULE — 100-UNIT PROGRAMME"; ws["B2"].font=TITLE
ws["B3"]="Aggregated core-scope quantities for a mixed package: 60 households + 30 clusters + 10 institutions."; ws["B3"].font=Font(size=9,italic=True,color="666666")
mix={"T1":60,"T2":30,"T3rcc":10}
agg={}
for k,mult in mix.items():
    for it in B[k]["items"]:
        if it["optional"] or it.get("alt"): continue
        key=(it["item"],it["spec"],it["unit"])
        agg.setdefault(key,[0,it["rate"],it["cat"]])
        agg[key][0]+=it["qty"]*mult
hdr(ws,5,["","Item","Specification","Unit","Total qty","Rate (BDT)","","Estimated value (BDT)"])
r=6; cat=None; grand=0
for (item,spec,unit),(qty,rate,ct) in sorted(agg.items(), key=lambda x:(x[1][2],x[0][0])):
    if ct!=cat:
        cat=ct
        ws.cell(row=r,column=2,value=ct).font=Font(bold=True,color="FFFFFF")
        for c in range(1,9): ws.cell(row=r,column=c).fill=PatternFill("solid",fgColor=TEAL)
        ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=8); r+=1
    val=qty*rate; grand+=val
    for c,v in [(2,item),(3,spec),(4,unit),(5,round(qty,1)),(6,rate),(8,round(val))]:
        cell=ws.cell(row=r,column=c,value=v); cell.border=BOX; cell.font=Font(size=9)
        if c in (5,6,8): cell.number_format='#,##0.0' if c==5 else '#,##0'
    r+=1
ws.cell(row=r,column=3,value="TOTAL PROGRAMME VALUE").font=Font(bold=True,size=11,color="FFFFFF")
for c in range(1,9): ws.cell(row=r,column=c).fill=PatternFill("solid",fgColor=NAVY)
c=ws.cell(row=r,column=8,value=round(grand)); c.number_format='#,##0'; c.font=Font(bold=True,size=12,color="FFFFFF")
r+=2
ws.cell(row=r,column=2,value="Beneficiaries reached").font=H2
ws.cell(row=r,column=5,value=60*6+30*60+10*400).number_format='#,##0'; ws.cell(row=r,column=5).font=Font(bold=True,size=11)
r+=1
ws.cell(row=r,column=2,value="Cost per beneficiary").font=H2
ws.cell(row=r,column=5,value=round(grand/(60*6+30*60+10*400))).number_format='#,##0'; ws.cell(row=r,column=5).font=Font(bold=True,size=11)

# ============ 12. M&E ============
ws=wb.create_sheet("12. M&E Indicators"); widths(ws,[4,42,26,14,30,26])
ws["B2"]="MONITORING & EVALUATION INDICATORS"; ws["B2"].font=TITLE
ws["B3"]="Report against these at baseline, 3 months, 12 months and after each monsoon/cyclone season."; ws["B3"].font=Font(size=9,italic=True,color="666666")
hdr(ws,5,["","Indicator","Definition","Target","Means of verification","Frequency"])
inds=[("Output 1 — infrastructure","","","",""),
("Systems built to specification","Count of units passing all 4 QC hold points","100% of planned","QC checklist, photo log","On completion"),
("Storage volume installed","Litres of tank capacity commissioned","Per design matrix","As-built survey","On completion",""),
("Catchment area connected","m2 of roof actually draining to tank","Per design matrix","Field measurement","On completion"),
("Output 2 — water safety","","","",""),
("Tank water meets ECR'97 for E. coli","0 CFU/100 mL","100% of samples","DPHE/ICDDR,B lab","Quarterly"),
("Residual free chlorine","mg/L at tapstand","0.2-0.5","DPD field test","Weekly by caretaker"),
("Turbidity","NTU","<10 (<5 target)","Field turbidity tube","Weekly"),
("Arsenic (Zone D only)","mg/L in tank water","<0.05","Lab (Hach kit)","Annual"),
("Output 3 — use & behaviour","","","",""),
("Households drawing water","Count of registered user households","100% of target","Caretaker register","Monthly"),
("First-flush diverter functional","Observed empty and clean","100%","Spot check","Monthly"),
("Chlorination practised","Dosing log completed correctly","100% of weeks","Dosing log","Monthly"),
("Output 4 — continuity of service","","","",""),
("Days of potable water supplied","Caretaker log, days tank non-empty","Zone target per Sheet 4","Daily log","Monthly"),
("Secondary source use","Days household relied on other source","<15% of dry season","Household survey","Seasonal"),
("System downtime","Days out of service for repair","<7 days/yr","Caretaker log","Monthly"),
("Outcome 5 — wellbeing","","","",""),
("Time saved collecting water","Hours/household/week vs baseline",">=3 h","Time-use survey (disaggregated by sex)","Baseline, 12 mo"),
("Reported diarrhoeal episodes","Under-5 incidence, 2-week recall","-30% vs baseline","Household survey","Baseline, 12 mo, annually"),
("Household water handling safety","Score on safe-handling observation",">=80% of households","Observation checklist","Annually"),
("Sustainability 6 — institutional","","","",""),
("Functionality (service ladder)","% systems at 'basic' or 'safely managed'","70% at 5 yrs","Joint functionality audit","Annually"),
("O&M fund balance","BDT in community account","3 months of O&M cost","Passbook","Quarterly"),
("Women in decision-making","% of WASH committee positions held by women",">=50%","Committee register","Annually")]
r=6
for row in inds:
    if row[1]=="":
        ws.cell(row=r,column=2,value=row[0]).font=Font(bold=True,size=10,color="FFFFFF")
        for c in range(1,7): ws.cell(row=r,column=c).fill=PatternFill("solid",fgColor=TEAL)
        ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=6)
    else:
        for c,v in enumerate([row[0],row[1],row[2],row[3],row[4] if len(row)>4 else ""],2):
            cell=ws.cell(row=r,column=c,value=v); cell.border=BOX; cell.font=Font(size=9)
            cell.alignment=Alignment(wrap_text=True,vertical="top")
    r+=1

# save
import os
os.makedirs("/home/user/borsha_bandhu/build",exist_ok=True)
wb._sheets=[wb["1. Read Me"],wb["2. Rate Library"],wb["3. Sizing Engine"],wb["4. Zone Matrix"],
            wb["5. BoM Household"],wb["6. BoM Cluster"],wb["7. BoM Institution A"],wb["8. BoM Institution B"],
            wb["9. Cost Summary"],wb["10. Lifecycle Cost"],wb["11. Procurement"],wb["12. M&E Indicators"]]
out="/home/user/borsha_bandhu/BorshaBandhu_Costing_and_Sizing_Model.xlsx"
wb.save(out); print("saved",out)
