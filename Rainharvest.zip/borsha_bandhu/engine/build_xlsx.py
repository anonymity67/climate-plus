import json, math
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from rwh_model import ZONES, DESIGN_FACTOR, DAYS, MONTHS, RUNOFF_COEF, FIRST_FLUSH_MM, gutter_size, downpipe_size

B=json.load(open("bom.json"))
NAVY="1F3A5F"; TEAL="0E7C7B"; SAND="F4EDE0"; LIGHT="EAF1F6"; ACC="C0392B"; GREEN="1E6B4F"
H=Font(bold=True,color="FFFFFF",size=11,name="Calibri")
TITLE=Font(bold=True,size=18,color=NAVY,name="Calibri")
SUB=Font(bold=True,size=12,color=TEAL,name="Calibri")
H2=Font(bold=True,size=10,color=NAVY)
BODY=Font(size=10,name="Calibri")
thin=Side(style="thin",color="BFBFBF")
BOX=Border(left=thin,right=thin,top=thin,bottom=thin)
def hdr(ws,row,cols,navy=NAVY):
    for i,c in enumerate(cols,1):
        cell=ws.cell(row=row,column=i,value=c); cell.font=H
        cell.fill=PatternFill("solid",fgColor=navy); cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        cell.border=BOX
    ws.row_dimensions[row].height=30
def band(ws,row,ncol,color=LIGHT):
    for i in range(1,ncol+1): ws.cell(row=row,column=i).fill=PatternFill("solid",fgColor=color)
def widths(ws,w):
    for i,x in enumerate(w,1): ws.column_dimensions[get_column_letter(i)].width=x
def money(ws,cell): ws[cell].number_format='#,##0'
def section(ws,row,text,ncol=8):
    ws.cell(row=row,column=1,value=text).font=SUB
    ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=ncol)

wb=Workbook()

# ============ 1. READ ME ============
ws=wb.active; ws.title="1. Read Me"; widths(ws,[3,46,58,26])
ws["B2"]="BORSHA-BANDHU  |  Integrated Rainwater Harvesting System"; ws["B2"].font=TITLE
ws["B3"]="Costing, Sizing & Procurement Model  —  Bangladesh, marginalised & disaster-prone communities"; ws["B3"].font=SUB
ws["B4"]="Prepared 20 November 2026  ·  Rates are 2026 Bangladesh market, delivered to upazila  ·  All values BDT"; ws["B4"].font=Font(size=9,italic=True,color="666666")
rows=[
 ("HOW TO USE THIS WORKBOOK",""),
 ("Sheet 2 · Rate Library","Every cost in the workbook is a quantity x a rate on this sheet. Change a rate and all six BoM sheets update. Update these first, from upazila-level quotations, before any procurement."),
 ("Sheet 3 · Sizing Engine","A working monthly mass-balance calculator. Enter a zone, roof area, tank volume and demand. It returns reliability, dry-season coverage and annual yield. This is the same engine that produced the design tank sizes."),
 ("Sheet 4 · Zone Design Matrix","The five climate zones, their design rainfall, and the tank/catchment combination that each tier needs to hit its service standard."),
 ("Sheets 5-8 · Bills of Materials","Itemised BoM for Household, Cluster, and Institutional (ferrocement and RCC options). Core scope, optional add-ons and alternatives are separated."),
 ("Sheet 9 · Cost Summary","Cost per unit, per beneficiary, per litre of storage, and per litre of safe water delivered. Use these to compare the three tiers."),
 ("Sheet 10 · Lifecycle Cost","20-year whole-life cost including O&M, media replacement, and component renewal. This is the number that matters, not capital cost."),
 ("Sheet 11 · Procurement","Quantities aggregated for a 100-unit programme, ready to send for quotation."),
 ("Sheet 12 · M&E Indicators","Field indicators, means of verification and targets for monitoring."),
 ("",""),
 ("DESIGN BASIS",""),
 ("Design rainfall","P80 dry-year rainfall = 0.75 x BMD 30-year monthly normal. A tank sized to this value meets its service standard in 4 years out of 5."),
 ("Runoff coefficient","0.80 (GI/asbestos/tile roof, includes splash, evaporation and gutter loss)."),
 ("First flush","1.5 mm of rainfall per rain event discarded. Sized into the diverter chamber, not assumed."),
 ("Service level","5 litres per person per day of safe drinking and cooking water. This is the minimum 'safe water access' service level; it is not total household demand."),
 ("Structural safety","Ferrocement hoop stress limited to 3.0 MPa (FoS >= 8 on mortar tensile strength). RCC designed to water-retaining criteria. Wind check at 72 m/s gust for cyclone zones."),
 ("",""),
 ("IMPORTANT",""),
 ("Rates","Indicative 2026 prices. Cement and steel move. Re-quote locally before procurement. Do not tender from this workbook without a local rate refresh."),
 ("Not a substitute for site design","Confirm soil bearing capacity, flood level from the local Water Development Board gauge, and roof structural capacity before construction."),
]
r=6
for a,b in rows:
    if a and not b:
        ws.cell(row=r,column=2,value=a).font=Font(bold=True,size=11,color=TEAL)
    elif a:
        ws.cell(row=r,column=2,value=a).font=H2
        c=ws.cell(row=r,column=3,value=b); c.font=BODY; c.alignment=Alignment(wrap_text=True,vertical="top")
        ws.row_dimensions[r].height=max(15,13*(len(b)//78+1))
    r+=1

# ============ 2. RATE LIBRARY ============
ws=wb.create_sheet("2. Rate Library"); widths(ws,[5,42,34,12,14,16])
ws["B2"]="RATE LIBRARY — 2026 Bangladesh market, delivered to upazila"; ws["B2"].font=TITLE
ws["B3"]="Edit the Rate column. Every BoM sheet recalculates. Re-quote before tender."; ws["B3"].font=Font(size=9,italic=True,color=ACC)
hdr(ws,5,["Code","Item","Unit","Rate (BDT)","Source basis","Notes"])
from quantities import RATES
basis={"cement_bag_50kg":"Retail 470-620; use 545 delivered remote","sand_m3":"55 BDT/cft x 35.31",
"aggregate_m3":"washed stone, Chattogram/Sylhet supply","brick_chips_m3":"local brick chips",
"steel_8mm_kg":"MS rod 92,000-105,000/tonne","steel_10mm_kg":"as above","steel_12mm_kg":"as above",
"weldmesh_m2":"galvanised weld mesh 3mm @150","chickenwire_m2":"20G 25mm hexagonal","GIwire_kg":"20G binding",
"waterproof_additive_kg":"integral crystalline","formwork_m2":"steel shuttering hire/amortised","brick_piece":"1st class, 10-14",
"pvc110_m":"uPVC class 5 / 4 inch","pvc75_m":"uPVC class 5","pvc50_m":"uPVC class 5",
"GIgutter06_m":"0.45mm GI, 600mm girth, fabricated","gutter_bracket_no":"MS epoxy coated",
"GI_sheet_downpipe_m":"0.47mm GI","HDPE_tank_5000":"retail 52,000-68,000","ballvalve_50mm":"brass/plastic",
"bibcock_brass":"brass","floatvalve":"float valve","leafscreen_no":"SS304 mesh","gravel_m3":"washed, 20-40mm",
"filter_sand_m3":"graded filter sand","charc_kg":"activated charcoal","candle_filter_set":"ceramic gravity filter",
"calhypo_kg":"65% granular HTH","chlorine_testkit":"DPD tablet kit","hatch_lid_RCC":"precast, sealed",
"manhole_cover":"CI/SS","tapstand_set":"GI frame + fittings","soakpit_ring":"brick ring per m",
"paint_epoxy_l":"food-grade 2-pack","signage_no":"Bengali pictogram","pipe_fittings_ls":"elbows/clamps",
"mason_day":"upazila skilled rate","helper_day":"unskilled","welder_day":"","plumber_day":"",
"supervision_day":"engineer/technician","transport_ls":"last mile, incl. boat in monsoon",
"testkit_pH_Cl":"field kit","training_hh":"per household session"}
r=6
for k,v in RATES.items():
    ws.cell(row=r,column=1,value=f"R{r-5}").font=BODY
    ws.cell(row=r,column=2,value=k).font=BODY
    ws.cell(row=r,column=3,value={"bag":"50 kg bag","m":"metre","m2":"sq.m","m3":"cu.m","kg":"kg","l":"litre","no":"each","ls":"lump sum","man-day":"man-day","hh":"household"}.get(k.split("_")[-1],"each")).font=BODY
    c=ws.cell(row=r,column=4,value=v); c.number_format='#,##0'; c.font=Font(bold=True,size=10); c.fill=PatternFill("solid",fgColor="FFF2CC")
    ws.cell(row=r,column=5,value=basis.get(k,"")).font=Font(size=9,color="555555")
    for col in range(1,6): ws.cell(row=r,column=col).border=BOX
    r+=1
ws.freeze_panes="A6"

# ============ 3. SIZING ENGINE ============
ws=wb.create_sheet("3. Sizing Engine"); widths(ws,[4,14,9,13,13,13,13,13,13,13,13,13,4])
ws["B2"]="LIVE MASS-BALANCE SIZING ENGINE"; ws["B2"].font=TITLE
ws["B3"]="Change the yellow cells. Row 12 evaluates the whole year. This is the engine behind Section 4 of the Technical Manual."; ws["B3"].font=Font(size=9,italic=True,color="666666")

ins=[("Climate zone (A-E)","A"),("Roof catchment area (m2)",20),("Tank storage volume (L)",5000),
     ("Design demand (L/person/day)",5),("Number of users",6),("Runoff coefficient",RUNOFF_COEF),
     ("Design rainfall factor (P80=0.75)",0.75)]
r=4
ws.cell(row=r,column=2,value="INPUTS").font=SUB; r+=1
for lab,val in ins:
    ws.cell(row=r,column=2,value=lab).font=H2
    c=ws.cell(row=r,column=4,value=val); c.fill=PatternFill("solid",fgColor="FFF2CC"); c.font=Font(bold=True,size=11); c.border=BOX
    c.alignment=Alignment(horizontal="center"); r+=1
ZIN="D5"; AIN="D6"; VIN="D7"; LIN="D8"; NIN="D9"; CIN="D10"; FIN="D11"
ws.cell(row=5,column=5,value="<- A,B,C,D,E — see Sheet 4").font=Font(size=9,italic=True,color="999999")
ws.cell(row=11,column=5,value="<- 0.75 = P80 dry year").font=Font(size=9,italic=True,color="999999")

r=14
section(ws,r,"MONTHLY MASS BALANCE  (storage carried forward; month 1 starts with a full tank)"); r+=1
cols=["Month","Days","Rainfall (mm)","Demand (L/d)","Supply to tank (L)","Opening storage (L)",
      "Inflow accepted (L)","Overflow / spill (L)","Water available (L)","Demand (L)","Demand served (L)","Closing storage (L)"]
hdr(ws,r,[""]+cols[:1]+cols[1:])
head_row=r; r+=1
first=r
for i in range(12):
    row=r+i
    ws.cell(row=row,column=2,value=MONTHS[i]).font=Font(bold=True,size=10)
    ws.cell(row=row,column=3,value=DAYS[i]).font=BODY
    # rainfall: formula pulling from zone table on sheet 4
    ws.cell(row=row,column=4,value=f"=INDEX('4. Zone Matrix'!$C$7:$G$18,{i+1},MATCH($D$5,'4. Zone Matrix'!$C$6:$G$6,0))*$D$11")
    ws.cell(row=row,column=5,value=f"=$D$8*$D$9")
    ws.cell(row=row,column=6,value=f"=D{row}*$D$6*$D$10")
    ws.cell(row=row,column=7,value=(f"=$D$7" if i==0 else f"=L{row-1}"))
    ws.cell(row=row,column=8,value=f"=MIN(F{row},MAX($D$7-G{row},0))")
    ws.cell(row=row,column=9,value=f"=F{row}-H{row}")
    ws.cell(row=row,column=10,value=f"=G{row}+H{row}")
    ws.cell(row=row,column=11,value=f"=E{row}")
    ws.cell(row=row,column=12,value=f"=MIN(J{row},K{row})")
    ws.cell(row=row,column=13,value=f"=J{row}-L{row}")
    for cc in range(2,14):
        cell=ws.cell(row=row,column=cc); cell.border=BOX; cell.font=Font(size=10)
        if cc in (4,6,7,8,9,10,11,12,13): cell.number_format='#,##0.0' if cc==4 else '#,##0'
    ws.cell(row=row,column=13).fill=PatternFill("solid",fgColor=LIGHT)
tot=r+12
ws.cell(row=tot,column=2,value="ANNUAL").font=Font(bold=True,size=10)
for cc in [6,9,10,11]:
    L=get_column_letter(cc)
    c=ws.cell(row=tot,column=cc,value=f"=SUM({L}{first}:{L}{first+11})"); c.number_format='#,##0'; c.font=Font(bold=True,size=10); c.border=BOX
    c.fill=PatternFill("solid",fgColor=SAND)

r=tot+2
ws.cell(row=r,column=2,value="RESULTS").font=SUB; r+=1
res=[("Annual reliability (% of demand met)",f"=IF(M{tot}=0,0,L{tot}/M{tot})","0.0%"),
     ("Dry-season (Nov-May) reliability",f"=IF(SUM(L{first+10}:L{first+11})+SUM(L{first}:L{first+4})=0,0,(L{first+10}+L{first+11}+L{first}+L{first+1}+L{first+2}+L{first+3}+L{first+4})/(M{first+10}+M{first+11}+M{first}+M{first+1}+M{first+2}+M{first+3}+M{first+4}))","0.0%"),
     ("Dry-season days covered (of 243)","=(L{}+L{}+L{}+L{}+L{}+L{}+L{})/($D$8*$D$9)".format(first+10,first+11,first,first+1,first+2,first+3,first+4),"0"),
     ("Annual supply to tank (L)",f"=F{tot}","#,##0"),
     ("Annual demand (L)",f"=M{tot}","#,##0"),
     ("Supply / demand ratio",f"=IF(M{tot}=0,0,F{tot}/M{tot})","0.00"),
     ("Days of storage buffer (tank / daily demand)",f"=IF(($D$8*$D$9)=0,0,$D$7/($D$8*$D$9))","0"),
     ("Surplus available for MAR recharge (L/yr)",f"=I{tot}","#,##0"),
     ("VERDICT",f'=IF(I{tot}/M{tot}<0.9,"NOT FEASIBLE - catchment too small for this demand","Supply is adequate; storage size governs")',"General")]
rr=r
for lab,f,fmt in res:
    ws.cell(row=rr,column=2,value=lab).font=H2
    c=ws.cell(row=rr,column=4,value=f); c.number_format=fmt; c.font=Font(bold=True,size=11,color=NAVY)
    if lab=="VERDICT": ws.merge_cells(start_row=rr,start_column=4,end_row=rr,end_column=10); c.alignment=Alignment(horizontal="left")
    rr+=1
r=rr+1
ws.cell(row=r,column=2,value="HYDRAULIC CHECK").font=SUB; r+=1
for lab,f,fmt in [("Peak roof flow @180 mm/h design storm (L/s)",f"=$D$6*180*$D$10/3600","0.00"),
                  ("Minimum half-round gutter (mm) — 1:200 fall",f'=IF($D$6<=20,75,IF($D$6<=40,90,IF($D$6<=75,110,IF($D$6<=130,150,IF($D$6<=220,200,250)))))',"0"),
                  ("First-flush volume to discard (L)","="+str(FIRST_FLUSH_MM)+"*$D$6","0")]:
    ws.cell(row=r,column=2,value=lab).font=H2
    c=ws.cell(row=r,column=4,value=f); c.number_format=fmt; c.font=Font(bold=True,size=10); r+=1

# ============ 4. ZONE MATRIX ============
ws=wb.create_sheet("4. Zone Matrix"); widths(ws,[4,14,26,10,11,11,11,11,11,11,11,11,11,11,11])
ws["B2"]="BANGLADESH CLIMATE ZONES — DESIGN RAINFALL & REQUIRED STORAGE"; ws["B2"].font=TITLE
ws["B3"]="Monthly normals from BMD 30-year records. P80 design rainfall = 0.75 x normal."; ws["B3"].font=Font(size=9,italic=True,color="666666")
# Transposed block: rows = months, columns = zones  (INDEX/MATCH from Sheet 3)
hdr(ws,6,["","Month","A","B","C","D","E","","A","B","C","D","E"])
for i,m in enumerate(MONTHS):
    row=7+i
    ws.cell(row=row,column=2,value=m).font=Font(bold=True,size=10)
    for j,z in enumerate("ABCDE"):
        c=ws.cell(row=row,column=3+j,value=ZONES[z]["m"][i]); c.number_format='0'; c.border=BOX; c.font=Font(size=10)
row=19
ws.cell(row=row,column=2,value="ANNUAL NORMAL").font=Font(bold=True,size=10)
ws.cell(row=row+1,column=2,value="P80 DESIGN").font=Font(bold=True,size=10,color=TEAL)
for j,z in enumerate("ABCDE"):
    L=get_column_letter(3+j)
    for rr,mul in [(row,1),(row+1,0.75)]:
        c=ws.cell(row=rr,column=3+j,value=f"=SUM({L}7:{L}18)"+("" if mul==1 else "*0.75"))
        c.number_format='#,##0'; c.font=Font(bold=True,size=10,color=NAVY if mul==1 else TEAL); c.border=BOX
        c.fill=PatternFill("solid",fgColor=LIGHT if mul==1 else SAND)
# labels row 6 must hold codes for MATCH: fix row 6 to contain codes
for j,z in enumerate("ABCDE"):
    ws.cell(row=6,column=3+j,value=z).font=Font(bold=True,size=11,color="FFFFFF")
    ws.cell(row=6,column=3+j).fill=PatternFill("solid",fgColor=NAVY)
    ws.cell(row=6,column=3+j).alignment=Alignment(horizontal="center")
ws.cell(row=6,column=2,value="Month").font=Font(bold=True,color="FFFFFF"); ws.cell(row=6,column=2).fill=PatternFill("solid",fgColor=NAVY)

r=22
section(ws,r,"ZONE PROFILES",5); r+=1
hdr(ws,r,["","Zone","Name","Districts / areas","Design rainfall (mm)","Hazard driver","RWH implication"]); r+=1
prof={"A":("Southwest Coastal Belt","Khulna, Satkhira, Bagerhat, Barguna, Patuakhali, Pirojpur","Cyclone, storm surge, salinity intrusion","Low rainfall + saline groundwater; RWH is primary safe source"),
"B":("Southeast Coastal Belt","Cox's Bazar, Chattogram, Bhola, Noakhali, Feni","Cyclone landfall zone, salinity","Highest rainfall; smallest tank; wind anchorage is the design driver"),
"C":("Flood Plain & Haor","Kurigram, Gaibandha, Sirajganj, Jamalpur, Sunamganj, Netrokona","Annual monsoon inundation, flash flood","Tank must sit above flood line; tank full before flood = emergency reserve"),
"D":("Barind & Char (drought)","Rajshahi, Chapainawabganj, Naogaon, Pabna, char lands","Drought, arsenic, low rainfall","Lowest rainfall; maximum catchment and MAR recharge required"),
"E":("Central Plain","Dhaka, Mymensingh, Cumilla, Tangail, Faridpur","Urban flooding, arsenic","Moderate; standard design applies")}
for z,(n,dist,haz,imp) in prof.items():
    ws.cell(row=r,column=2,value=z).font=Font(bold=True); ws.cell(row=r,column=2).alignment=Alignment(horizontal="center")
    ws.cell(row=r,column=3,value=n).font=BODY
    ws.cell(row=r,column=4,value=dist).font=Font(size=9)
    ws.cell(row=r,column=5,value={"A":1221,"B":2644,"C":2177,"D":1157,"E":1610}[z]).font=Font(bold=True,size=10)
    ws.cell(row=r,column=6,value=haz).font=Font(size=9)
    ws.cell(row=r,column=7,value=imp).font=Font(size=9)
    for c in range(2,8): ws.cell(row=r,column=c).border=BOX; ws.cell(row=r,column=c).alignment=Alignment(wrap_text=True,vertical="top",horizontal="center" if c==2 else "left")
    ws.row_dimensions[r].height=34; r+=1

r+=1
section(ws,r,"REQUIRED STORAGE BY TIER AND ZONE (litres, for 90% annual reliability)",5); r+=1
hdr(ws,r,["","Tier / catchment","Service standard","Zone A","Zone B","Zone C","Zone D","Zone E"]); r+=1
from rwh_model import size_tank
matrix=[("T1 Household · 20 m2","6 users @ 5 lpcd",20,30),
        ("T1 Household · 30 m2","6 users @ 5 lpcd",30,30),
        ("T2 Cluster(10HH) · 160 m2","60 users @ 5 lpcd",160,300),
        ("T3 Institution · 600 m2","400 users @ 1,000 L/d",600,1000)]
for name,std,a,dmd in matrix:
    ws.cell(row=r,column=2,value=name).font=H2; ws.cell(row=r,column=3,value=std).font=Font(size=9)
    for j,z in enumerate("ABCDE"):
        v=size_tank([x*DESIGN_FACTOR for x in ZONES[z]["m"]],a,dmd,0.90)
        c=ws.cell(row=r,column=4+j,value=v if v else "not feasible")
        c.font=Font(bold=True,size=10); c.border=BOX
        c.alignment=Alignment(horizontal="center")
        c.fill=PatternFill("solid",fgColor="E8F5E9" if v else "FDE8E8")
    for c in (2,3): ws.cell(row=r,column=c).border=BOX
    r+=1
print("sheets 1-4 ok")
exec(open("build_xlsx_part2.py").read())
